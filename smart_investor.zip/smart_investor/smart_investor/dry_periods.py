"""Dry-period analytics: how long, how often and how deep has a fund or sector gone without making progress?

Four lenses on the same NAV/price series:
  1. Underwater episodes   - peak -> trough -> recovery (how long investors waited to get back to a previous high)
  2. Dry spells            - stretches where the trailing N-year return stayed below a threshold (0% = loss, or inflation)
  3. Relative dry spells   - stretches of underperformance against a benchmark
  4. Calendar-year returns - which individual years were bad, and how bad

History describes the past; it does not forecast the future. Short histories give unreliable dry-period statistics.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .fund_analytics import clean_nav, cagr, drawdown_series, rolling_returns

DAYS_PER_YEAR = 365.25
EPISODE_COLUMNS = ["peak_date", "trough_date", "recovery_date", "depth", "days_to_trough", "days_to_recover",
                   "underwater_days", "ongoing"]
SPELL_COLUMNS = ["start", "end", "days", "worst_value"]


def drawdown_episodes(nav: pd.Series, min_depth: float = 0.05) -> pd.DataFrame:
    """Every peak-to-recovery episode whose depth is at least `min_depth` (e.g. 0.05 = 5%).

    `underwater_days` runs from the peak to the recovery date (or to the last date when still ongoing).
    """
    s = clean_nav(nav)
    if len(s) < 2:
        return pd.DataFrame(columns=EPISODE_COLUMNS)
    vals, idx = s.to_numpy(), s.index
    peak = np.maximum.accumulate(vals)
    under = vals < peak
    rows, i, n = [], 0, len(s)
    while i < n:
        if not under[i]:
            i += 1
            continue
        j = i
        while j < n and under[j]:
            j += 1                                    # j = first day back at/above the peak (or n if never)
        seg = vals[i:j]
        trough = i + int(np.argmin(seg))
        peak_i = i - 1                                # the day nav last equalled its running maximum
        depth = float(seg.min() / peak[i] - 1)
        recovered = j < n
        end_date = idx[j] if recovered else idx[-1]
        rows.append({"peak_date": idx[peak_i], "trough_date": idx[trough],
                     "recovery_date": idx[j] if recovered else pd.NaT, "depth": depth,
                     "days_to_trough": (idx[trough] - idx[peak_i]).days,
                     "days_to_recover": (idx[j] - idx[trough]).days if recovered else np.nan,
                     "underwater_days": (end_date - idx[peak_i]).days, "ongoing": not recovered})
        i = j
    df = pd.DataFrame(rows, columns=EPISODE_COLUMNS)
    return df[df["depth"] <= -min_depth].reset_index(drop=True)


def underwater_summary(nav: pd.Series, min_depth: float = 0.05) -> dict:
    """Headline underwater statistics (longest wait for a new high, time spent below a prior peak, ...)."""
    s = clean_nav(nav)
    nan = float("nan")
    if len(s) < 2:
        return {"history_years": nan, "max_drawdown": nan, "longest_underwater_years": nan, "pct_time_underwater": nan,
                "pct_time_down_10": nan, "episodes": 0, "avg_recovery_years": nan, "current_drawdown": nan,
                "still_underwater": False, "years_since_high": nan}
    dd = drawdown_series(s)
    eps = drawdown_episodes(s, min_depth)
    rec = eps["days_to_recover"].dropna()
    last_high = s.index[(s == s.cummax()).to_numpy()][-1]
    return {
        "history_years": (s.index[-1] - s.index[0]).days / DAYS_PER_YEAR,
        "max_drawdown": float(dd.min()),
        "longest_underwater_years": float(eps["underwater_days"].max() / DAYS_PER_YEAR) if len(eps) else 0.0,
        "pct_time_underwater": float((dd < 0).mean()),
        "pct_time_down_10": float((dd <= -0.10).mean()),
        "episodes": int(len(eps)),
        "avg_recovery_years": float(rec.mean() / DAYS_PER_YEAR) if len(rec) else nan,
        "current_drawdown": float(dd.iloc[-1]),
        "still_underwater": bool(dd.iloc[-1] < 0),
        "years_since_high": (s.index[-1] - last_high).days / DAYS_PER_YEAR,
    }


def _spells(flag: pd.Series, values: pd.Series) -> pd.DataFrame:
    """Consecutive True runs in `flag` -> start, end, calendar days, worst value inside the run."""
    if flag.empty or not flag.any():
        return pd.DataFrame(columns=SPELL_COLUMNS)
    f = flag.to_numpy()
    idx = flag.index
    rows, i, n = [], 0, len(f)
    while i < n:
        if not f[i]:
            i += 1
            continue
        j = i
        while j < n and f[j]:
            j += 1
        rows.append({"start": idx[i], "end": idx[j - 1], "days": (idx[j - 1] - idx[i]).days,
                     "worst_value": float(values.iloc[i:j].min())})
        i = j
    return pd.DataFrame(rows, columns=SPELL_COLUMNS)


def dry_spells(nav: pd.Series, window_years: int = 1, threshold: float = 0.0) -> pd.DataFrame:
    """Stretches where the trailing `window_years` annualised return was below `threshold` (e.g. 0.0 or 0.06 = inflation)."""
    rr = rolling_returns(nav, window_years)
    if rr.empty:
        return pd.DataFrame(columns=SPELL_COLUMNS)
    return _spells(rr < threshold, rr)


def dry_spell_summary(nav: pd.Series, window_years: int = 1, threshold: float = 0.0) -> dict:
    rr = rolling_returns(nav, window_years)
    nan = float("nan")
    if rr.empty:
        return {"windows": 0, "pct_dry": nan, "longest_years": nan, "spells": 0, "worst_return": nan, "currently_dry": False}
    sp = _spells(rr < threshold, rr)
    return {"windows": int(len(rr)), "pct_dry": float((rr < threshold).mean()),
            "longest_years": float(sp["days"].max() / DAYS_PER_YEAR) if len(sp) else 0.0,
            "spells": int(len(sp)), "worst_return": float(rr.min()), "currently_dry": bool(rr.iloc[-1] < threshold)}


def relative_dry_spells(nav: pd.Series, benchmark: pd.Series, window_years: int = 1) -> pd.DataFrame:
    """Stretches where the trailing-return excess over the benchmark was negative (underperformance)."""
    a, b = rolling_returns(nav, window_years), rolling_returns(benchmark, window_years)
    excess = (a - b).dropna()
    if excess.empty:
        return pd.DataFrame(columns=SPELL_COLUMNS)
    return _spells(excess < 0, excess)


def relative_summary(nav: pd.Series, benchmark: pd.Series, window_years: int = 1) -> dict:
    a, b = rolling_returns(nav, window_years), rolling_returns(benchmark, window_years)
    excess = (a - b).dropna()
    nan = float("nan")
    if excess.empty:
        return {"pct_lagging": nan, "longest_lag_years": nan, "avg_excess": nan}
    sp = _spells(excess < 0, excess)
    return {"pct_lagging": float((excess < 0).mean()),
            "longest_lag_years": float(sp["days"].max() / DAYS_PER_YEAR) if len(sp) else 0.0,
            "avg_excess": float(excess.mean())}


def calendar_returns(navs: dict[str, pd.Series]) -> pd.DataFrame:
    """Year-end to year-end return per series (index = calendar year).

    The first calendar year is dropped (no prior year-end to measure from); the latest year is year-to-date.
    """
    cols = {}
    for name, s in navs.items():
        c = clean_nav(s)
        if len(c) < 2:
            continue
        year_end = c.groupby(c.index.year).last()
        cols[name] = year_end.pct_change().dropna()
    return pd.DataFrame(cols).sort_index()


def dry_profile(nav: pd.Series, benchmark: pd.Series | None = None, inflation: float = 0.06,
                min_depth: float = 0.10) -> dict:
    """All dry-period lenses for one series, as a flat dict (used by summaries, scorecards and reports)."""
    uw = underwater_summary(nav, min_depth)
    neg1 = dry_spell_summary(nav, 1, 0.0)
    infl3 = dry_spell_summary(nav, 3, inflation)
    cal = calendar_returns({"x": nav})
    out = {
        "history_years": uw["history_years"], "cagr": cagr(nav), "max_drawdown": uw["max_drawdown"],
        "longest_underwater_years": uw["longest_underwater_years"], "pct_time_underwater": uw["pct_time_underwater"],
        "pct_time_down_10": uw["pct_time_down_10"],
        "current_drawdown": uw["current_drawdown"], "still_underwater": uw["still_underwater"],
        "years_since_high": uw["years_since_high"], "episodes_ge_min": uw["episodes"],
        "pct_1y_negative": neg1["pct_dry"], "longest_negative_1y_years": neg1["longest_years"],
        "pct_3y_below_inflation": infl3["pct_dry"], "longest_3y_below_inflation_years": infl3["longest_years"],
        "worst_calendar_year": float(cal["x"].min()) if not cal.empty else float("nan"),
        "best_calendar_year": float(cal["x"].max()) if not cal.empty else float("nan"),
    }
    if benchmark is not None:
        rel = relative_summary(nav, benchmark, 1)
        out.update({"pct_1y_lagging": rel["pct_lagging"], "longest_lag_years": rel["longest_lag_years"]})
    return out
