"""Illustrative mutual-fund CATEGORIES (SEBI categories) for each risk profile, with example schemes to research.

IMPORTANT: this is educational. It is not a recommendation to buy any scheme. Example scheme names come from general
knowledge of well-known funds in each category and may have been renamed, merged or changed; always verify the current
category, plan type (Direct vs Regular), expense ratio, AUM, track record and risk label on the AMC factsheet, AMFI or
the Fund comparison tab (live NAVs) before relying on them.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from .allocation import Allocation
from .risk_engine import PROFILES

VERIFY_NOTE = ("Educational categories and example schemes to RESEARCH, not recommendations to buy. Example names are from general "
               "knowledge and may be outdated: verify the current scheme name, category, Direct/Regular plan, expense ratio, AUM, "
               "track record and risk label with the AMC factsheet or AMFI. Past performance does not guarantee future results.")


@dataclass(frozen=True)
class FundCategory:
    name: str
    sleeve: str                 # equity | debt | cash | hybrid
    role: str
    risk_note: str              # indicative only
    examples: tuple[str, ...]
    search: str                 # text to type in the live mfapi.in search


CATEGORIES: dict[str, FundCategory] = {
    "liquid": FundCategory("Liquid / Overnight fund", "cash", "Parking money for 0-3 months; liquidity buffer",
                           "Low", ("HDFC Liquid Fund", "ICICI Prudential Liquid Fund"), "liquid fund direct growth"),
    "short_duration": FundCategory("Short Duration / Low Duration debt fund", "debt", "Stability with modest income over 1-3 years",
                                   "Low to moderate", ("HDFC Short Term Debt Fund", "ICICI Prudential Short Term Fund"),
                                   "short duration fund direct growth"),
    "banking_psu": FundCategory("Banking & PSU debt fund", "debt", "High-quality credit for conservative debt allocation",
                                "Low to moderate", ("HDFC Banking and PSU Debt Fund", "Kotak Banking and PSU Debt Fund"),
                                "banking and psu debt direct growth"),
    "corporate_bond": FundCategory("Corporate Bond fund", "debt", "Core debt holding (mostly AA+ and above)",
                                   "Moderate", ("ICICI Prudential Corporate Bond Fund", "HDFC Corporate Bond Fund"),
                                   "corporate bond fund direct growth"),
    "gilt": FundCategory("Gilt fund", "debt", "Government securities: no credit risk, but interest-rate sensitive",
                         "Moderate to high (rate risk)", ("SBI Magnum Gilt Fund",), "gilt fund direct growth"),
    "nifty50": FundCategory("Large-cap / Nifty 50 index fund", "equity", "Core low-cost equity exposure",
                            "Very high", ("UTI Nifty 50 Index Fund", "HDFC Index Fund Nifty 50 Plan"), "nifty 50 index direct growth"),
    "flexi": FundCategory("Flexi Cap fund", "equity", "Diversified equity across market caps",
                          "Very high", ("Parag Parikh Flexi Cap Fund", "HDFC Flexi Cap Fund"), "flexi cap direct growth"),
    "large_mid": FundCategory("Large & Mid Cap fund", "equity", "Growth tilt with a large-cap anchor",
                              "Very high", ("Mirae Asset Large & Midcap Fund",), "large and midcap direct growth"),
    "midcap": FundCategory("Mid Cap fund / Nifty Midcap 150 index fund", "equity", "Higher growth, higher volatility",
                           "Very high", ("Motilal Oswal Midcap Fund", "Nifty Midcap 150 index funds"), "midcap direct growth"),
    "smallcap": FundCategory("Small Cap fund", "equity", "Highest growth potential and deepest drawdowns; keep a small share",
                             "Very high", ("Nippon India Small Cap Fund", "SBI Small Cap Fund"), "small cap direct growth"),
    "conservative_hybrid": FundCategory("Conservative Hybrid fund", "hybrid", "One-fund option: mostly debt, small equity",
                                        "Moderate", ("SBI Conservative Hybrid Fund",), "conservative hybrid direct growth"),
    "equity_savings": FundCategory("Equity Savings fund", "hybrid", "One-fund option: equity, arbitrage and debt mix",
                                   "Low to moderate", ("HDFC Equity Savings Fund",), "equity savings direct growth"),
    "balanced_advantage": FundCategory("Balanced Advantage / Dynamic Asset Allocation fund", "hybrid",
                                       "One-fund option: equity share adjusts with valuations", "Moderately high",
                                       ("ICICI Prudential Balanced Advantage Fund", "HDFC Balanced Advantage Fund"),
                                       "balanced advantage direct growth"),
    "aggressive_hybrid": FundCategory("Aggressive Hybrid fund", "hybrid", "One-fund option: 65-80% equity",
                                      "Very high", ("ICICI Prudential Equity & Debt Fund",), "aggressive hybrid direct growth"),
}

# How each sleeve of the allocation is split into categories (each sleeve's shares sum to 1).
PROFILE_MIX: dict[str, dict[str, list[tuple[str, float]]]] = {
    "Conservative": {"equity": [("nifty50", 1.0)],
                     "debt": [("short_duration", 0.4), ("banking_psu", 0.3), ("corporate_bond", 0.3)],
                     "cash": [("liquid", 1.0)]},
    "Moderately Conservative": {"equity": [("nifty50", 0.7), ("flexi", 0.3)],
                                "debt": [("short_duration", 0.35), ("corporate_bond", 0.35), ("gilt", 0.3)],
                                "cash": [("liquid", 1.0)]},
    "Moderate": {"equity": [("nifty50", 0.4), ("flexi", 0.3), ("large_mid", 0.2), ("midcap", 0.1)],
                 "debt": [("short_duration", 0.4), ("corporate_bond", 0.4), ("gilt", 0.2)],
                 "cash": [("liquid", 1.0)]},
    "Moderately Aggressive": {"equity": [("nifty50", 0.3), ("flexi", 0.3), ("large_mid", 0.15), ("midcap", 0.25)],
                              "debt": [("short_duration", 0.5), ("corporate_bond", 0.5)],
                              "cash": [("liquid", 1.0)]},
    "Aggressive": {"equity": [("nifty50", 0.25), ("flexi", 0.25), ("midcap", 0.3), ("smallcap", 0.2)],
                   "debt": [("short_duration", 0.5), ("corporate_bond", 0.5)],
                   "cash": [("liquid", 1.0)]},
}

# Single-fund (hybrid) alternatives for investors who prefer one scheme to a mix.
HYBRID_ALTERNATIVES: dict[str, list[str]] = {
    "Conservative": ["conservative_hybrid", "equity_savings"],
    "Moderately Conservative": ["conservative_hybrid", "balanced_advantage"],
    "Moderate": ["balanced_advantage", "aggressive_hybrid"],
    "Moderately Aggressive": ["aggressive_hybrid", "balanced_advantage"],
    "Aggressive": ["aggressive_hybrid"],
}

COLUMNS = ["Category", "Sleeve", "Portfolio weight", "Role", "Typical risk (indicative)", "Example schemes to research", "Live search term"]


def shortlist(profile: str, alloc: Allocation) -> pd.DataFrame:
    """Fund categories for a profile with their weight in the whole portfolio (sleeve weight x share within the sleeve)."""
    if profile not in PROFILE_MIX:
        raise ValueError(f"Unknown profile: {profile}")
    rows = []
    for sleeve, weight in (("equity", alloc.equity), ("debt", alloc.debt), ("cash", alloc.cash)):
        for key, share in PROFILE_MIX[profile][sleeve]:
            c = CATEGORIES[key]
            rows.append({"Category": c.name, "Sleeve": sleeve.title(), "Portfolio weight": weight * share, "Role": c.role,
                         "Typical risk (indicative)": c.risk_note, "Example schemes to research": "; ".join(c.examples),
                         "Live search term": c.search})
    df = pd.DataFrame(rows, columns=COLUMNS)
    return df[df["Portfolio weight"] > 1e-9].reset_index(drop=True)


def hybrid_alternatives(profile: str) -> pd.DataFrame:
    rows = []
    for key in HYBRID_ALTERNATIVES[profile]:
        c = CATEGORIES[key]
        rows.append({"Category": c.name, "Role": c.role, "Typical risk (indicative)": c.risk_note,
                     "Example schemes to research": "; ".join(c.examples), "Live search term": c.search})
    return pd.DataFrame(rows)


def profile_matrix() -> pd.DataFrame:
    """One row per profile: equity range and the main categories (independent of any investor)."""
    from .allocation import EQUITY_BANDS
    rows = []
    for p in PROFILES:
        lo, hi = EQUITY_BANDS[p]
        names = []
        for sleeve in ("equity", "debt", "cash"):
            names += [CATEGORIES[k].name for k, _ in PROFILE_MIX[p][sleeve]]
        rows.append({"Profile": p, "Equity range": f"{lo:.0%}-{hi:.0%}", "Categories to research": "; ".join(dict.fromkeys(names)),
                     "One-fund alternatives": "; ".join(CATEGORIES[k].name for k in HYBRID_ALTERNATIVES[p])})
    return pd.DataFrame(rows)
