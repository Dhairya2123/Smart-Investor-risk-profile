"""Hypothetical market-crash simulator, including the estimated impact on the investor's stated goal.

A scenario, NOT a forecast and NOT a maximum-loss estimate. Real drawdowns can be larger, and debt and cash can also
lose value in stress.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from .allocation import Allocation, DEFAULT_ASSUMPTIONS, portfolio_stats
from .risk_engine import future_value

DEFAULT_SHOCKS = (0.10, 0.20, 0.30, 0.40)


@dataclass
class CrashResult:
    equity_shock: float
    start_value: float
    end_value: float
    loss_amount: float
    loss_pct: float
    recovery_years: float | None   # at the portfolio's assumed return, no new money


def portfolio_loss_pct(alloc: Allocation, equity_shock: float, debt_shock: float = 0.0, cash_shock: float = 0.0) -> float:
    return alloc.equity * equity_shock + alloc.debt * debt_shock + alloc.cash * cash_shock


def simulate_crash(start_value: float, alloc: Allocation, equity_shock: float = 0.20,
                   debt_shock: float = 0.0, cash_shock: float = 0.0,
                   assumed_return: float | None = None) -> CrashResult:
    """Apply a one-off shock to each sleeve and report the portfolio effect (shocks are positive fractions of decline)."""
    if start_value <= 0:
        raise ValueError("start_value must be positive")
    for name, s in (("equity", equity_shock), ("debt", debt_shock), ("cash", cash_shock)):
        if not 0.0 <= s <= 1.0:
            raise ValueError(f"{name} shock must be between 0 and 1")

    end = start_value * (alloc.equity * (1 - equity_shock) + alloc.debt * (1 - debt_shock) + alloc.cash * (1 - cash_shock))
    loss = start_value - end
    loss_pct = loss / start_value

    if assumed_return is None:
        assumed_return, _ = portfolio_stats(alloc, DEFAULT_ASSUMPTIONS)
    recovery = None
    if loss_pct > 0 and assumed_return > 0:
        recovery = math.log(start_value / end) / math.log(1 + assumed_return)
    elif loss_pct == 0:
        recovery = 0.0
    return CrashResult(equity_shock, start_value, end, loss, loss_pct, recovery)


def crash_table(start_value: float, alloc: Allocation, shocks=DEFAULT_SHOCKS, debt_shock: float = 0.0) -> list[CrashResult]:
    return [simulate_crash(start_value, alloc, s, debt_shock) for s in shocks]


@dataclass
class GoalImpact:
    equity_shock: float
    shock_year: float
    loss_pct: float
    target: float
    value_no_shock: float
    value_with_shock: float
    met_no_shock: bool
    met_with_shock: bool
    value_lost: float            # difference at the goal date
    shortfall_with_shock: float


def goal_impact(current: float, monthly: float, years: float, alloc: Allocation, equity_shock: float, shock_year: float,
                target: float, assumptions: dict | None = None, debt_shock: float = 0.0) -> GoalImpact:
    """Estimated effect of a one-off shock at `shock_year` on the value reached at the goal date.

    Grows the portfolio at the assumed return, applies the shock to the sleeves, then keeps growing and contributing.
    """
    if years <= 0:
        raise ValueError("years must be positive")
    ret, _ = portfolio_stats(alloc, assumptions or DEFAULT_ASSUMPTIONS)
    total_m = int(round(years * 12))
    t_m = min(max(int(round(shock_year * 12)), 0), total_m)
    loss_pct = portfolio_loss_pct(alloc, equity_shock, debt_shock)

    no_shock = future_value(current, monthly, ret, years)
    before = future_value(current, monthly, ret, t_m / 12) if t_m > 0 else current
    after_shock = before * (1 - loss_pct)
    remaining = (total_m - t_m) / 12
    with_shock = future_value(after_shock, monthly, ret, remaining) if remaining > 0 else after_shock
    return GoalImpact(equity_shock, t_m / 12, loss_pct, target, no_shock, with_shock, no_shock >= target,
                      with_shock >= target, no_shock - with_shock, max(0.0, target - with_shock))


def comfort_warning(loss_pct: float, tolerable_decline: float) -> str | None:
    """Warn when a scenario loss exceeds the temporary decline the investor said (Q21) they could tolerate."""
    if loss_pct > tolerable_decline:
        return (f"A {loss_pct:.1%} fall is larger than the temporary decline you said you could tolerate "
                f"(about {tolerable_decline:.0%}).")
    return None
