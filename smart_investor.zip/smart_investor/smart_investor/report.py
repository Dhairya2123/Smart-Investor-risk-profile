"""Plain-language summary report (Markdown) following Section 8 of the questionnaire."""
from __future__ import annotations

from datetime import date

import pandas as pd

from .allocation import Allocation
from .crash import CrashResult, GoalImpact
from .funds_catalog import VERIFY_NOTE
from .goal import GoalFeasibility
from .risk_engine import RiskResult

DISCLAIMER = ("This report is for education only. It is not investment advice and does not recommend buying or selling any "
              "security. Scenarios and projections rest on stated assumptions, are not forecasts, and past performance does not "
              "guarantee future results. The scoring model must be validated before use in any real financial-advice process.")

LIMITATIONS = [
    "Scoring weights, thresholds and allocation bands are design choices, not regulatory standards, and have not been validated.",
    "Answers are self-reported and may be inconsistent; the profile is only as good as the answers.",
    "Projections use constant assumed returns; real returns vary by year, and sequence of returns matters.",
    "Only the main goal is modelled; tax, fees and other goals are not.",
    "Fund categories and example schemes are for research only and may be outdated.",
]


def _inr(x: float) -> str:
    return f"₹{x:,.0f}"


def md_table(df: pd.DataFrame) -> str:
    cols = list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    for _, row in df.iterrows():
        lines.append("| " + " | ".join(str(v).replace("|", "/") for v in row) + " |")
    return "\n".join(lines)


def build_report(risk: RiskResult, alloc: Allocation, feas: GoalFeasibility, crashes: list[CrashResult],
                 impacts: list[GoalImpact], assumptions_note: str, shortlist_df: pd.DataFrame | None = None,
                 fund_table: pd.DataFrame | None = None, data_note: str = "", investor_ref: str = "",
                 extra_sections: list[str] | None = None) -> str:
    L: list[str] = []
    L.append("# Smart Investor Risk Profile - Assessment")
    L.append(f"_Calculation date: {date.today():%d %b %Y}" + (f" · Reference: {investor_ref}" if investor_ref else "") + "_\n")
    if risk.provisional:
        L.append("> **PROVISIONAL**: see the reliability warnings below.\n")

    L.append("## Section 8 - Assessment")
    L.append("| Assessment | Result | Explanation |\n|---|---|---|")
    L.append(f"| Risk Tolerance | {risk.tolerance_level} ({risk.tolerance:.0f}/100) | {' '.join(risk.explanations['tolerance'][1:]) or '-'} |")
    L.append(f"| Risk Capacity | {risk.capacity_level} ({risk.capacity:.0f}/100) | {' '.join(risk.explanations['capacity'][1:]) or '-'} |")
    L.append(f"| Risk Required | {risk.required_level} ({risk.required:.0f}/100) | {' '.join(risk.explanations['required'])} |")
    L.append(f"| **Overall Risk Profile** | **{risk.profile}** | {risk.rule} |")
    L.append(f"| Goal Feasibility | {feas.label} | Base case {_inr(feas.base_value)} vs target {_inr(feas.target)} |")
    L.append(f"| Risk Mismatch | {'Potential mismatch' if risk.mismatch else 'None'} | See warnings |")

    if risk.warnings:
        L.append("\n## Warnings")
        L += [f"- {w}" for w in risk.warnings]

    L.append("\n## Goal feasibility")
    L.append(f"Target {_inr(feas.today_target)} in today's money ({_inr(feas.target)} at the goal date). "
             f"Scenario values at the goal date: pessimistic {_inr(feas.pessimistic_value)}, base {_inr(feas.base_value)}, "
             f"optimistic {_inr(feas.optimistic_value)}. Required return: "
             f"{'above 20% a year (unrealistic)' if feas.required_return is None else f'{feas.required_return:.1%} a year'}; "
             f"illustrative portfolio return: {feas.assumed_return:.1%}.")
    if feas.levers:
        L.append("\nAlternatives if the plan falls short (none is guaranteed):")
        L += [f"- {l}" for l in feas.levers]

    L.append("\n## Illustrative allocation (educational, not personalised instructions)")
    L.append(f"Equity {alloc.equity:.0%} | Debt {alloc.debt:.0%} | Cash {alloc.cash:.0%}")
    L.append(f"\nAssumptions: {assumptions_note}")

    if shortlist_df is not None and not shortlist_df.empty:
        L.append(f"\n## Fund categories to research for the {risk.profile} profile")
        t = shortlist_df.copy()
        t["Portfolio weight"] = t["Portfolio weight"].map(lambda x: f"{x:.1%}")
        L.append(md_table(t.drop(columns=["Live search term"])))
        L.append(f"\n_{VERIFY_NOTE}_")

    L.append("\n## Hypothetical downside scenarios")
    L.append("| Equity fall | Portfolio value after | Loss | Approx. recovery (years) |\n|---|---|---|---|")
    for c in crashes:
        rec = f"{c.recovery_years:.1f}" if c.recovery_years is not None else "n/a"
        L.append(f"| {c.equity_shock:.0%} | {_inr(c.end_value)} | {c.loss_pct:.1%} ({_inr(c.loss_amount)}) | {rec} |")
    if impacts:
        L.append("\nEstimated impact on your goal (shock at different times):")
        L.append("| Equity fall | Shock after (years) | Value at goal date | Value lost | Goal still met? |\n|---|---|---|---|---|")
        for g in impacts:
            L.append(f"| {g.equity_shock:.0%} | {g.shock_year:g} | {_inr(g.value_with_shock)} | {_inr(g.value_lost)} | "
                     f"{'Yes' if g.met_with_shock else 'No (shortfall ' + _inr(g.shortfall_with_shock) + ')'} |")
    L.append("\nThese are hypothetical scenarios, not forecasts or maximum-loss estimates.")

    if fund_table is not None and not fund_table.empty:
        L.append("\n## Fund comparison (shortlist)")
        t = fund_table.copy()
        for c in ("CAGR", "Volatility", "Max drawdown", "Expense ratio", "Top-10 holdings %"):
            if c in t:
                t[c] = t[c].map(lambda x: "" if pd.isna(x) else f"{x:.1%}")
        for c in ("Sharpe", "Beta"):
            if c in t:
                t[c] = t[c].map(lambda x: "" if pd.isna(x) else f"{x:.2f}")
        cols = [c for c in ("Category", "CAGR", "Volatility", "Sharpe", "Max drawdown", "Beta", "Expense ratio", "Top-10 holdings %") if c in t]
        L.append(md_table(t[cols].reset_index()))
        L.append("\nNo single metric is a complete assessment of a fund.")

    for sec in extra_sections or []:
        L.append("\n" + sec)

    L.append("\n## Data source, assumptions and limitations")
    L.append(f"- Questionnaire answers provided by the investor; fund data: {data_note or 'none loaded'}.")
    L.append(f"- Calculation date {date.today():%d %b %Y}; return and volatility assumptions as stated above.")
    L += [f"- {x}" for x in LIMITATIONS]
    L.append(f"\n---\n**Disclaimer:** {DISCLAIMER}")
    return "\n".join(L)


def sector_section(summary: pd.DataFrame, warnings: list[str], data_note: str) -> str:
    """Markdown section for the sector dry-period analysis."""
    cols = ["History (yrs)", "CAGR", "Max drawdown", "Longest underwater (yrs)", "% time >10% below peak",
            "Current drawdown", "Worst year", "Dry-period risk", "Trend"]
    t = summary[[c for c in cols if c in summary]].copy()
    for c in t.columns:
        if c in ("CAGR", "Max drawdown", "Current drawdown", "Worst year", "% time >10% below peak"):
            t[c] = t[c].map(lambda x: "" if pd.isna(x) else f"{x:.1%}")
        elif c in ("History (yrs)", "Longest underwater (yrs)"):
            t[c] = t[c].map(lambda x: "" if pd.isna(x) else f"{x:.1f}")
    L = ["## Sector dry-period analysis", f"Data: {data_note}. Each sector is measured over its own history; past dry periods do not forecast future ones.",
         md_table(t.reset_index())]
    if warnings:
        L.append("\nAgainst your horizon and tolerable decline:")
        L += [f"- {w}" for w in warnings]
    L.append("\nTrend labels are context only and are not part of any score.")
    return "\n".join(L)


def scorecard_section(scores: pd.DataFrame, flag_map: dict[str, list[str]], data_note: str) -> str:
    t = scores.copy()
    for c in t.columns:
        if c == "Data coverage":
            t[c] = t[c].map(lambda x: f"{x:.0%}")
        elif c == "Rank":
            t[c] = t[c].map(lambda x: "" if pd.isna(x) else f"{int(x)}")
        elif t[c].dtype.kind == "f":
            t[c] = t[c].map(lambda x: "" if pd.isna(x) else f"{x:.0f}")
    L = ["## Fund scorecard (within-peer ranking)", f"Data: {data_note}. Scores are percentile ranks among the funds compared; "
         "they are not recommendations.", md_table(t.reset_index())]
    if flag_map:
        L.append("\nCaveats:")
        L += [f"- {k}: {'; '.join(v)}" for k, v in flag_map.items()]
    return "\n".join(L)
