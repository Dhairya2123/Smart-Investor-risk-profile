"""Risk-scoring engine for the 53-question Smart Investor questionnaire.

Three dimensions are scored 0-100 and always shown separately:
  * tolerance - emotional willingness to accept volatility (Section 3, plus modest weight for experience)
  * capacity  - financial ability to absorb losses (Sections 1, 2, 4 and the time horizon)
  * required  - risk implied by the goal, from the return needed to reach it (Section 5)

Conflict rule (transparent, per the questionnaire's safety notes):
    OVERALL = the LOWER of capacity and tolerance, i.e. profile = min(capacity-based profile, tolerance-based profile).
    The three scores are NOT averaged, a high tolerance can never override low capacity, and the required risk
    never raises the profile: when the goal needs more risk than the investor can bear, a mismatch is flagged.

All thresholds are module constants so they can be documented, tested and reviewed.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .questionnaire import (CAPACITY_QUESTIONS, HORIZON_YEARS, INCOME_UPPER, NO_MAJOR, TOLERANCE_QUESTIONS,
                            GoalInputs, InvestorInputs, Question, validate)

PROFILES = ["Conservative", "Moderately Conservative", "Moderate", "Moderately Aggressive", "Aggressive"]
PROFILE_THRESHOLDS = [20, 40, 60, 80]      # upper bound (exclusive) of the first four profiles on the 0-100 overall score
LEVEL_THRESHOLDS = (35, 65)                # < 35 Low, < 65 Moderate, else High (Section 8 labels)

HORIZON_SCORE_WEIGHT = 0.25     # share of capacity driven by the time horizon
DIMENSION_GAP_WARNING = 25      # |capacity - tolerance| above this is flagged
REQUIRED_GAP_WARNING = 15       # required - overall above this is flagged

REQ_RETURN_LOW = 0.05           # required return at or below this -> required-risk score 0
REQ_RETURN_HIGH = 0.15          # at or above -> 100
MAX_PLAUSIBLE_RETURN = 0.20     # a goal needing more than this is treated as unreachable

# Hard caps on the capacity score: (question key, answer) -> maximum capacity
CAPACITY_CAPS: dict[tuple[str, str], int] = {
    ("emergency_fund", "No emergency savings"): 35,
    ("emergency_fund", "Less than 3 months"): 50,
    ("debt_burden", "More than 35%"): 40,
    ("debt_burden", "20–35%"): 60,
    ("loss_impact", "Severely affected"): 30,
    ("loss_impact", "Significantly affected"): 45,
    ("unexpected_withdrawal", "Likely"): 40,
}
# (horizon in years strictly below, cap): the effective horizon is the shorter of 'time to withdrawal' and 'goal horizon'
HORIZON_CAPS = [(1.0, 25), (3.0, 35), (5.0, 55)]


@dataclass
class RiskResult:
    capacity: float
    tolerance: float
    required: float
    overall: float
    profile: str
    profile_index: int
    capacity_profile: str
    tolerance_profile: str
    capacity_level: str
    tolerance_level: str
    required_level: str
    required_return: float | None        # annual, on the (inflation-adjusted) target; None if unreachable
    goal: GoalInputs
    liquidity_horizon: float             # effective horizon used for capacity caps (years)
    goal_reachable: bool
    mismatch: bool
    provisional: bool
    rule: str
    warnings: list[str] = field(default_factory=list)
    codes: list[str] = field(default_factory=list)
    explanations: dict[str, list[str]] = field(default_factory=dict)
    caps_applied: list[str] = field(default_factory=list)
    breakdown: dict[str, float] = field(default_factory=dict)

    @property
    def bearable(self) -> float:      # backwards-compatible alias
        return self.overall


# ------------------------------------------------------------------ scoring helpers
def level(score: float) -> str:
    lo, hi = LEVEL_THRESHOLDS
    return "Low" if score < lo else "Moderate" if score < hi else "High"


def classify(score: float) -> tuple[str, int]:
    for i, bound in enumerate(PROFILE_THRESHOLDS):
        if score < bound:
            return PROFILES[i], i
    return PROFILES[-1], len(PROFILES) - 1


def pressure_score(points: float) -> float:
    """Life-event pressure (sum of points) -> 0-100 (more upcoming events = less capacity)."""
    if points <= 0:
        return 90.0
    if points <= 0.5:
        return 75.0
    if points <= 1:
        return 65.0
    if points <= 2:
        return 40.0
    return 20.0


def breadth_score(n_products: int) -> float:
    return {0: 10.0, 1: 30.0, 2: 50.0, 3: 70.0, 4: 70.0}.get(n_products, 90.0)


def question_score(q: Question, answers: dict) -> float | None:
    """0-100 score for one answered question, or None when the answer is not scored (e.g. 'Prefer not to say')."""
    a = answers.get(q.key)
    if q.kind == "single":
        return q.options.get(a)
    if q.kind == "multi":
        picked = a or []
        if q.scorer == "pressure":
            return pressure_score(sum(q.options.get(x, 0) for x in picked if x != NO_MAJOR))
        if q.scorer == "breadth":
            return breadth_score(len([x for x in picked if x != "Other"]))
    return None


def _scored(questions: list[Question], answers: dict) -> list[tuple[Question, float]]:
    out = []
    for q in questions:
        s = question_score(q, answers)
        if s is not None:
            out.append((q, float(s)))
    return out


def _weighted(pairs: list[tuple[Question, float]]) -> float:
    tw = sum(q.weight for q, _ in pairs)
    return sum(q.weight * s for q, s in pairs) / tw


def horizon_score(years: float) -> float:
    """Longer horizon = more capacity to ride out losses (0-100)."""
    for bound, score in ((1, 0.0), (3, 15.0), (5, 40.0), (7, 60.0), (10, 80.0)):
        if years < bound:
            return score
    return 100.0


def liquidity_horizon(answers: dict, goal: GoalInputs) -> float:
    return min(HORIZON_YEARS[answers["withdrawal_horizon"]], goal.horizon_years)


def capacity_score(answers: dict, horizon_years: float) -> tuple[float, dict[str, float], list[str]]:
    pairs = _scored(CAPACITY_QUESTIONS, answers)
    parts = {q.key: s for q, s in pairs}
    h = horizon_score(horizon_years)
    parts["horizon"] = h
    score = (1 - HORIZON_SCORE_WEIGHT) * _weighted(pairs) + HORIZON_SCORE_WEIGHT * h
    caps: list[tuple[int, str]] = []
    for (key, ans), cap in CAPACITY_CAPS.items():
        if answers.get(key) == ans:
            caps.append((cap, f"Cap: {key.replace('_', ' ')} = '{ans}' limits capacity to {cap}."))
    for bound, cap in HORIZON_CAPS:
        if horizon_years < bound:
            caps.append((cap, f"Cap: a {horizon_years:g}-year horizon limits capacity to {cap}."))
            break
    if caps:
        tightest = min(c for c, _ in caps)
        score = min(score, tightest)
    return score, parts, [t for _, t in caps]


def tolerance_score(answers: dict) -> tuple[float, dict[str, float]]:
    pairs = _scored(TOLERANCE_QUESTIONS, answers)
    return _weighted(pairs), {q.key: s for q, s in pairs}


# ------------------------------------------------------------------ goal maths
def future_value(pv: float, monthly: float, annual_return: float, years: float) -> float:
    """Future value with monthly compounding and end-of-month contributions."""
    n = int(round(years * 12))
    r = (1 + annual_return) ** (1 / 12) - 1
    if abs(r) < 1e-12:
        return pv + monthly * n
    return pv * (1 + r) ** n + monthly * (((1 + r) ** n - 1) / r)


def required_return(goal: GoalInputs) -> float | None:
    """Annual return needed to reach the (inflation-adjusted) target; None if above MAX_PLAUSIBLE_RETURN.

    Returns 0.0 if the goal is already met without any growth.
    """
    target = goal.effective_target

    def fv(rate):
        return future_value(goal.current_investments, goal.monthly_contribution, rate, goal.horizon_years)

    if fv(0.0) >= target:
        return 0.0
    if fv(MAX_PLAUSIBLE_RETURN) < target:
        return None
    lo, hi = 0.0, MAX_PLAUSIBLE_RETURN
    for _ in range(80):
        mid = (lo + hi) / 2
        if fv(mid) < target:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def required_score(req_return: float | None) -> float:
    if req_return is None:
        return 100.0
    s = (req_return - REQ_RETURN_LOW) / (REQ_RETURN_HIGH - REQ_RETURN_LOW) * 100
    return max(0.0, min(100.0, s))


# ------------------------------------------------------------------ explanations and warnings
def _drivers(questions: list[Question], answers: dict) -> tuple[list[str], list[str]]:
    pairs = sorted(_scored(questions, answers), key=lambda p: p[1])

    def txt(q):
        a = answers[q.key]
        a = ", ".join(a) if isinstance(a, list) else a
        return f"{q.label} ({a})"
    limiting = [txt(q) for q, s in pairs if s < 50][:3]
    strengths = [txt(q) for q, s in reversed(pairs) if s >= 70][:3]
    return limiting, strengths


def _dimension_text(name: str, score: float, lvl: str, answers: dict, questions: list[Question]) -> list[str]:
    limiting, strengths = _drivers(questions, answers)
    out = [f"{name} score {score:.0f}/100 ({lvl})."]
    if limiting:
        out.append("Holding it back: " + "; ".join(limiting) + ".")
    if strengths:
        out.append("Supporting it: " + "; ".join(strengths) + ".")
    return out


def _money(x: float) -> str:
    return f"₹{x:,.0f}"


def assess(inputs: InvestorInputs) -> RiskResult:
    """Validate, score the three dimensions, apply the conflict rule, and generate warnings and explanations."""
    validate(inputs)
    a = inputs.answers
    goal = inputs.goal
    eff_h = liquidity_horizon(a, goal)

    cap, cap_parts, caps = capacity_score(a, eff_h)
    tol, tol_parts = tolerance_score(a)
    req_ret = required_return(goal)
    req = required_score(req_ret)

    overall = min(cap, tol)
    profile, idx = classify(overall)
    cap_profile, tol_profile = classify(cap)[0], classify(tol)[0]
    rule = (f"Overall profile = the LOWER of the capacity-based profile ({cap_profile}) and the tolerance-based profile "
            f"({tol_profile}), giving {profile}. The scores are not averaged, high tolerance cannot override low capacity, "
            "and the risk required by the goal never raises the profile.")

    warnings: list[str] = []
    codes: list[str] = []

    def warn(code: str, text: str):
        codes.append(code)
        warnings.append(text)

    # ---- warnings requested by the questionnaire: reserves, debt, near-term liquidity, mismatch
    ess = a.get("essential_expenses") or 0
    if a["emergency_fund"] in ("No emergency savings", "Less than 3 months"):
        extra = f" At your stated essential spending of {_money(ess)} a month, six months would be about {_money(6 * ess)}." if ess else ""
        warn("LOW_EMERGENCY_RESERVE", f"Your emergency fund ('{a['emergency_fund']}') is below the usual 3-6 months of essential "
             f"expenses, so a market fall or job loss could force you to sell at a bad time.{extra}")
    if a["debt_burden"] in ("20–35%", "More than 35%"):
        warn("HIGH_DEBT", f"EMIs and debt repayments take '{a['debt_burden']}' of your take-home income, which reduces your ability "
             "to absorb investment losses. Repaying costly debt may matter more than taking investment risk.")
    reasons = []
    if eff_h < 3:
        reasons.append(f"an effective horizon of about {eff_h:g} years")
    if a["obligations"] in ("Yes, within 1 year", "Yes, within 1–3 years"):
        reasons.append(f"a major obligation ({a['obligations'].lower()})")
    if a["unexpected_withdrawal"] in ("Possible", "Likely"):
        reasons.append("a possible need for large unexpected withdrawals")
    if reasons:
        warn("NEAR_TERM_LIQUIDITY", "Near-term liquidity need: " + ", ".join(reasons) + ". Money needed soon is poorly suited to "
             "volatile assets, so equity exposure is limited.")
    if a["insurance"] != "Adequate health / life / other cover as relevant":
        warn("INSURANCE_GAP", f"Insurance cover is '{a['insurance'].lower()}'. A protection gap can force you to liquidate "
             "investments after an unexpected event.")

    # ---- dimension conflict
    if abs(cap - tol) > DIMENSION_GAP_WARNING:
        if tol > cap:
            warn("TOLERANCE_ABOVE_CAPACITY", "Your willingness to take risk is notably higher than your financial ability to absorb "
                 "losses. The profile follows the lower figure (capacity); stronger reserves, lower debt or fewer near-term "
                 "obligations would raise capacity.")
        else:
            warn("CAPACITY_ABOVE_TOLERANCE", "Your financial capacity is notably higher than your comfort with volatility. The profile "
                 "follows the lower figure (tolerance); a portfolio you cannot stay invested in may do more harm than a calmer one.")

    # ---- goal mismatch
    goal_gap = req_ret is None or (req - overall > REQUIRED_GAP_WARNING)
    if req_ret is None:
        warn("GOAL_UNREALISTIC", f"The goal appears to need more than {MAX_PLAUSIBLE_RETURN:.0%} a year, which is not a realistic "
             "planning assumption. See the alternatives on the Goal tab.")
    elif goal_gap:
        extra = ""
        if a["goal_flexibility"].startswith("Non-negotiable"):
            extra = " Because the goal is non-negotiable, the gap deserves particular attention."
        warn("GOAL_RISK_GAP", f"Your goal needs roughly {req_ret:.1%} a year, which implies more risk than your profile supports "
             f"(required-risk score {req:.0f} vs overall {overall:.0f}). The profile has not been raised to close the gap.{extra}")

    # ---- reliability and consistency
    provisional = False
    if a["accepts_risk_return"] != "Yes, clearly":
        provisional = True
        warn("RISK_RETURN_NOT_UNDERSTOOD", "You indicated you only partly understand, or need an explanation of, the link between higher "
             "expected returns and larger losses. Treat this profile as provisional until that is explained.")
    if str(a["confirmed"]).startswith("No"):
        provisional = True
        warn("ANSWERS_NOT_CONFIRMED", "You asked to review your answers, so this profile is provisional.")
    if (a.get("other_goals") or "").strip():
        warn("MULTIPLE_GOALS", "You listed other goals. Only the main goal is modelled; other goals compete for the same money.")
    upper = INCOME_UPPER.get(a["income_band"])
    spend = (a.get("essential_expenses") or 0) + (a.get("discretionary_expenses") or 0) + a["monthly_contribution"]
    if upper and spend > upper:
        warn("INCONSISTENT_CASHFLOW", f"Stated spending plus planned monthly investment ({_money(spend)}) exceeds the top of your income "
             f"band ({_money(upper)}). Please re-check the amounts.")

    explanations = {
        "tolerance": _dimension_text("Risk tolerance", tol, level(tol), a, TOLERANCE_QUESTIONS),
        "capacity": _dimension_text("Risk capacity", cap, level(cap), a, CAPACITY_QUESTIONS) + caps,
        "required": ([f"Risk required {req:.0f}/100 ({level(req)}): the goal needs about {req_ret:.1%} a year "
                      f"on a target of {_money(goal.effective_target)}."] if req_ret is not None else
                     [f"Risk required 100/100 (High): the goal needs more than {MAX_PLAUSIBLE_RETURN:.0%} a year."]),
        "overall": [rule],
    }
    if goal.inflation_linked:
        explanations["required"].append(f"Target of {_money(goal.goal_amount)} in today's money is inflated at "
                                        f"{goal.inflation_rate:.1%} a year to {_money(goal.effective_target)}.")

    mismatch = goal_gap or ("TOLERANCE_ABOVE_CAPACITY" in codes) or ("CAPACITY_ABOVE_TOLERANCE" in codes)
    return RiskResult(
        capacity=cap, tolerance=tol, required=req, overall=overall, profile=profile, profile_index=idx,
        capacity_profile=cap_profile, tolerance_profile=tol_profile,
        capacity_level=level(cap), tolerance_level=level(tol), required_level=level(req),
        required_return=req_ret, goal=goal, liquidity_horizon=eff_h, goal_reachable=req_ret is not None,
        mismatch=mismatch, provisional=provisional, rule=rule, warnings=warnings, codes=codes,
        explanations=explanations, caps_applied=caps, breakdown={**cap_parts, **tol_parts})
