"""NAV data loading.

Real data: mfapi.in (free, community-run API wrapping AMFI NAVs).
Fallback: a clearly-labelled SYNTHETIC sample so the app runs offline and demo
datasets never contain real investor data. Synthetic data is for demonstration
only and must never be read as real fund performance.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

MFAPI_SEARCH = "https://api.mfapi.in/mf/search"
MFAPI_SCHEME = "https://api.mfapi.in/mf/{code}"
CACHE_DIR = Path(__file__).resolve().parent.parent / "data"


def search_schemes(query: str, timeout: int = 15) -> list[dict]:
    import requests
    r = requests.get(MFAPI_SEARCH, params={"q": query}, timeout=timeout)
    r.raise_for_status()
    return r.json()


def fetch_nav(scheme_code: int | str, timeout: int = 20, use_cache: bool = True) -> tuple[pd.Series, dict]:
    """Return (NAV series, meta). Caches the raw response as CSV in data/."""
    import requests
    cache = CACHE_DIR / f"nav_{scheme_code}.csv"
    meta_cache = CACHE_DIR / f"meta_{scheme_code}.txt"
    if use_cache and cache.exists():
        s = pd.read_csv(cache, index_col=0, parse_dates=True).iloc[:, 0]
        name = meta_cache.read_text().strip() if meta_cache.exists() else str(scheme_code)
        return s, {"name": name, "source": "mfapi.in (cached)", "last_updated": s.index[-1].date()}
    r = requests.get(MFAPI_SCHEME.format(code=scheme_code), timeout=timeout)
    r.raise_for_status()
    j = r.json()
    df = pd.DataFrame(j["data"])
    df["date"] = pd.to_datetime(df["date"], format="%d-%m-%Y")
    df["nav"] = pd.to_numeric(df["nav"], errors="coerce")
    s = df.dropna().drop_duplicates("date").set_index("date")["nav"].sort_index()
    CACHE_DIR.mkdir(exist_ok=True)
    s.to_csv(cache)
    meta_cache.write_text(j.get("meta", {}).get("scheme_name", str(scheme_code)))
    meta = {"name": j.get("meta", {}).get("scheme_name", str(scheme_code)),
            "category": j.get("meta", {}).get("scheme_category", ""),
            "source": "mfapi.in", "last_updated": s.index[-1].date()}
    return s, meta


def load_csv_nav(path_or_buffer) -> pd.Series:
    """Load a user CSV with columns date, nav (any case)."""
    df = pd.read_csv(path_or_buffer)
    df.columns = [c.strip().lower() for c in df.columns]
    if "date" not in df.columns or "nav" not in df.columns:
        raise ValueError("CSV needs 'date' and 'nav' columns.")
    df["date"] = pd.to_datetime(df["date"], dayfirst=True, errors="coerce")
    df["nav"] = pd.to_numeric(df["nav"], errors="coerce")
    return df.dropna().drop_duplicates("date").set_index("date")["nav"].sort_index()


def synthetic_nav(name: str, annual_return: float, annual_vol: float, years: float = 6,
                  seed: int = 0, end: str | None = None, market: pd.Series | None = None,
                  beta_to_market: float = 0.0) -> pd.Series:
    """Geometric-random-walk NAV on business days. DEMO DATA ONLY."""
    rng = np.random.default_rng(seed)
    end_ts = pd.Timestamp(end) if end else pd.Timestamp.today().normalize()
    idx = pd.bdate_range(end=end_ts, periods=int(years * 252))
    mu, sigma = annual_return / 252, annual_vol / np.sqrt(252)
    shocks = rng.normal(mu, sigma, len(idx))
    if market is not None:
        m = market.reindex(idx).pct_change().fillna(0).to_numpy()
        idiosync = np.sqrt(max(sigma ** 2 - (beta_to_market * (annual_vol / np.sqrt(252))) ** 2, 1e-12))
        shocks = mu + beta_to_market * (m - m.mean()) + rng.normal(0, idiosync * 0.6, len(idx))
    return pd.Series(100 * np.cumprod(1 + shocks), index=idx, name=name)


def sample_universe(end: str | None = None) -> tuple[dict[str, pd.Series], pd.Series, dict[str, dict]]:
    """Synthetic benchmark + five fictional funds across risk levels."""
    bench = synthetic_nav("Sample Benchmark", 0.12, 0.16, seed=1, end=end)
    specs = [
        ("Sample Large Cap Fund A", "Large Cap", 0.12, 0.15, 11, 0.95, 0.0105, 48),
        ("Sample Large Cap Fund B", "Large Cap", 0.11, 0.14, 12, 0.90, 0.0070, 52),
        ("Sample Flexi Cap Fund C", "Flexi Cap", 0.14, 0.18, 13, 1.05, 0.0120, 41),
        ("Sample Mid Cap Fund D", "Mid Cap", 0.17, 0.22, 14, 1.20, 0.0135, 33),
        ("Sample Balanced Advantage Fund E", "Balanced Advantage", 0.09, 0.09, 15, 0.55, 0.0110, 38),
    ]
    navs, meta = {}, {}
    for name, cat, r, v, seed, b, er, conc in specs:
        navs[name] = synthetic_nav(name, r, v, seed=seed, end=end, market=bench, beta_to_market=b)
        meta[name] = {"category": cat, "expense_ratio": er, "top10_concentration": conc / 100}
    return navs, bench, meta


# (sector, [(years, annual_drift, annual_vol), ...]) - hand-built regimes so the DEMO contains known dry periods.
_SECTOR_REGIMES = [
    ("Banks", [(3, .16, .22), (3, .00, .24), (2, -.05, .28), (4, .22, .22)]),
    ("IT", [(4, .25, .24), (2, .35, .28), (2, -.10, .28), (4, .03, .22)]),
    ("Pharma", [(2, .08, .18), (5, .00, .18), (5, .20, .20)]),
    ("FMCG", [(12, .11, .12)]),
    ("Metals", [(2, .30, .33), (3, -.08, .33), (3, .15, .33), (2, -.05, .33), (2, .20, .33)]),
    ("Realty", [(3, .02, .30), (4, -.04, .32), (3, .30, .34), (2, .05, .30)]),
]
_SECTOR_YEARS = 12
_MARKET_BETA = 0.5


def _market_returns(seed: int = 99) -> np.ndarray:
    return np.random.default_rng(seed).normal(.12 / 252, .16 / np.sqrt(252), int(_SECTOR_YEARS * 252))


def _regime_series(regimes, seed: int, end: pd.Timestamp, name: str, market: np.ndarray | None = None) -> pd.Series:
    """Regime-switching random walk; an optional shared market factor makes sectors move together to a realistic degree."""
    rng = np.random.default_rng(seed)
    idio = np.concatenate([rng.normal(mu / 252, vol / np.sqrt(252) * (0.85 if market is not None else 1.0), int(y * 252))
                           for y, mu, vol in regimes])
    rets = idio if market is None else idio + _MARKET_BETA * (market[:len(idio)] - market.mean())
    idx = pd.bdate_range(end=end, periods=len(rets))
    return pd.Series(100 * np.cumprod(1 + rets), index=idx, name=name)


def sample_sectors(end: str | None = None) -> tuple[dict[str, pd.Series], pd.Series, dict[str, dict]]:
    """SYNTHETIC sector series (12 years) with built-in dry spells, plus a broad-market benchmark. DEMO DATA ONLY."""
    end_ts = pd.Timestamp(end) if end else pd.Timestamp.today().normalize()
    mkt = _market_returns()
    navs = {f"Sample Sector: {n}": _regime_series(r, 100 + i, end_ts, f"Sample Sector: {n}", mkt)
            for i, (n, r) in enumerate(_SECTOR_REGIMES)}
    idx = pd.bdate_range(end=end_ts, periods=len(mkt))
    bench = pd.Series(100 * np.cumprod(1 + mkt), index=idx, name="Sample Broad Market")
    meta = {n: {"category": "Sector (synthetic)"} for n in navs}
    return navs, bench, meta


def sample_factsheet(names) -> pd.DataFrame:
    """SYNTHETIC factsheet values (made up) for the sample funds, so the scorecard can be demonstrated offline."""
    vals = {
        "Sample Large Cap Fund A": (0.0105, 18000, 7.0, 0.48, 24.0, 3.6, 0.15, 0.40),
        "Sample Large Cap Fund B": (0.0070, 9500, 4.5, 0.52, 22.0, 3.3, 0.16, 0.25),
        "Sample Flexi Cap Fund C": (0.0120, 6200, 9.0, 0.41, 27.0, 4.1, 0.14, 0.55),
        "Sample Mid Cap Fund D": (0.0135, 3100, 3.0, 0.33, 33.0, 5.2, 0.13, 0.70),
        "Sample Balanced Advantage Fund E": (0.0110, 11000, 6.0, 0.38, 21.0, 3.0, 0.15, 0.80),
    }
    rows = [{"fund": n, "category": "", "expense_ratio": v[0], "aum_cr": v[1], "manager_tenure_years": v[2],
             "top10_concentration": v[3], "pe_ratio": v[4], "pb_ratio": v[5], "roe": v[6], "turnover": v[7]}
            for n, v in vals.items() if n in set(names)]
    return pd.DataFrame(rows)
