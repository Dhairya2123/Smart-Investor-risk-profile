"""Sample investors for demos and tests (all fictional)."""
from __future__ import annotations

from .questionnaire import ALL_QUESTIONS, NO_MAJOR, QUESTIONS_BY_KEY

DEFAULT_NUMBERS = {"essential_expenses": 30_000.0, "discretionary_expenses": 10_000.0, "goal_amount": 2_000_000.0,
                   "invested": 500_000.0, "monthly_contribution": 20_000.0}

DEFAULT_CONTEXT = {
    "age": "36–45", "employment": "Salaried employee", "income_band": "₹1–2 lakh",
    "lifestyle_priority": "I balance saving with enjoying the present", "housing": "Renting",
    "objectives": ["Wealth creation"], "goal_horizon": "5–10 years", "goal_inflation": "Expected to rise with inflation",
    "goal_flexibility": "Moderately flexible", "shortfall_preference": "Increase monthly contributions",
    "past_loss": "No", "accepts_risk_return": "Yes, clearly", "confirmed": "Yes",
}


def _closest(q, target):
    scored = [(abs(s - target), label) for label, s in q.options.items() if s is not None]
    return min(scored)[1]


def uniform_answers(mode: str = "mid") -> dict:
    """Answers for every question. mode: 'min' (most cautious), 'max' (most risk-seeking/strongest), 'mid'."""
    a: dict = {}
    for q in ALL_QUESTIONS:
        if q.key in DEFAULT_NUMBERS:
            a[q.key] = DEFAULT_NUMBERS[q.key]
        elif q.key in DEFAULT_CONTEXT:
            a[q.key] = DEFAULT_CONTEXT[q.key]
        elif q.kind == "text":
            a[q.key] = ""
        elif q.kind == "multi":
            if q.key == "life_events":
                a[q.key] = {"min": ["Buying a home", "Marriage or starting a family", "Higher education"],
                            "mid": ["Buying a home"], "max": [NO_MAJOR]}[mode]
            elif q.key == "products_used":
                a[q.key] = {"min": [], "mid": ["Fixed deposits / recurring deposits", "Equity mutual funds"],
                            "max": ["Fixed deposits / recurring deposits", "Debt mutual funds", "Equity mutual funds",
                                    "Index funds / ETFs", "Direct stocks", "Bonds"]}[mode]
            else:
                a[q.key] = list(q.options)[:1]
        elif q.scored:
            scores = [s for s in q.options.values() if s is not None]
            target = {"min": min(scores), "max": max(scores), "mid": 55}[mode]
            a[q.key] = _closest(q, target)
        else:
            a[q.key] = list(q.options)[0]
    return a


def with_overrides(base: dict, **overrides) -> dict:
    out = dict(base)
    for k, v in overrides.items():
        q = QUESTIONS_BY_KEY[k]
        if q.kind == "single" and v not in q.options:
            raise KeyError(f"{k}: {v!r} is not an option")
        out[k] = v
    return out


def _persona(**overrides):
    return with_overrides(uniform_answers("mid"), **overrides)


PERSONAS_FULL: dict[str, dict] = {
    "Young salaried, long horizon, calm in a crash": _persona(
        age="25–35", income_stability="Very stable", dependants="None", savings_rate="20–30%", total_savings="₹5–15 lakh",
        spending_pattern="I regularly save a meaningful amount", spending_flexibility="Very flexible; I can reduce discretionary spending substantially",
        life_events=["Marriage or starting a family"], expense_predictability="Mostly predictable", family_support="No",
        insurance="Adequate health / life / other cover as relevant", unexpected_withdrawal="Unlikely",
        reaction_10pct="Stay invested without major concern", reaction_5_to_4_lakh="Continue investing as planned",
        tolerable_decline="15–25%", preferred_mix="Mostly equity mutual funds / index funds", uncertainty="I am comfortable with market fluctuations",
        underperformance="Stay invested if the reasons for investing remain valid", philosophy="I prioritize long-term wealth creation",
        crash_20pct="Continue planned contributions / SIPs", check_frequency="Monthly",
        emergency_fund="6–12 months", debt_burden="Less than 10%", financial_position="I save a significant amount",
        asset_share="10–25%", job_stability="Stable", withdrawal_horizon="More than 10 years", obligations="Yes, within 3–5 years",
        loss_impact="Minimally affected", liquidity="More than 75%",
        goal_amount=5_000_000.0, invested=400_000.0, monthly_contribution=25_000.0, goal_horizon="More than 10 years",
        investing_years="3–5 years", risk_understanding="Intermediate", products_used=["Equity mutual funds", "Index funds / ETFs"]),
    "Near-retirement, needs money soon": _persona(
        age="Above 55", employment="Retired", income_stability="Mostly stable", dependants="1–2", savings_rate="5–10%",
        total_savings="₹15–50 lakh", spending_pattern="I usually have a small surplus", spending_flexibility="Slightly flexible",
        life_events=["Retirement"], expense_predictability="Mostly predictable", insurance="Some cover, but may be insufficient",
        unexpected_withdrawal="Possible", reaction_10pct="Sell some investments", reaction_5_to_4_lakh="Sell a major portion",
        tolerable_decline="0–5%", preferred_mix="Mostly deposits / high-quality short-term debt", uncertainty="I prefer predictable returns",
        underperformance="Shift to safer investments", philosophy="Protecting capital is my top priority",
        crash_20pct="Reduce equity exposure", check_frequency="Daily", emergency_fund="3–6 months", debt_burden="No debt repayments",
        financial_position="Income and expenses are almost equal", asset_share="50–75%", job_stability="Moderately stable",
        withdrawal_horizon="1–3 years", obligations="Yes, within 1–3 years", loss_impact="Significantly affected", liquidity="50–75%",
        goal_amount=1_500_000.0, invested=1_200_000.0, monthly_contribution=0.0, goal_horizon="1–3 years",
        goal_inflation="Fixed amount", goal_flexibility="Non-negotiable; cannot be delayed or reduced",
        investing_years="More than 5 years", risk_understanding="Basic", products_used=["Fixed deposits / recurring deposits", "Debt mutual funds"]),
    "Brave but financially fragile": _persona(
        employment="Freelancer / gig worker", income_stability="Highly unpredictable", dependants="3–4", savings_rate="Below 5%",
        total_savings="Below ₹1 lakh", spending_pattern="I spend almost all my income", spending_flexibility="Not flexible; most expenses are essential",
        life_events=["Having or supporting children", "Higher education"], expense_predictability="Highly uncertain",
        family_support="Yes, a significant amount", insurance="No meaningful cover", unexpected_withdrawal="Likely",
        reaction_10pct="Consider investing more", reaction_5_to_4_lakh="Invest additional money", tolerable_decline="More than 25%",
        preferred_mix="Predominantly equity and other high-volatility assets", uncertainty="I actively seek higher-risk opportunities",
        underperformance="Consider investing more after reviewing the facts", philosophy="I accept substantial risk for higher potential returns",
        crash_20pct="Increase investments after reviewing my finances", check_frequency="Only during scheduled reviews",
        emergency_fund="No emergency savings", debt_burden="More than 35%", financial_position="Expenses exceed income",
        asset_share="More than 75%", job_stability="Very uncertain", withdrawal_horizon="1–3 years",
        obligations="Yes, within 1 year", loss_impact="Severely affected", liquidity="Almost none",
        goal_amount=2_000_000.0, invested=100_000.0, monthly_contribution=5_000.0, goal_horizon="3–5 years",
        investing_years="1–3 years", risk_understanding="Intermediate"),
    "Mid-career family, balanced": _persona(),
}
