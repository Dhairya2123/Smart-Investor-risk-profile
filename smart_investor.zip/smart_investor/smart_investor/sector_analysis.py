"""Sector analysis: dry periods, rotation, diversification and trend for a set of sector series.

A 'sector series' is the NAV/price history of a sector index fund, sector ETF or sectoral/thematic fund used as a
proxy for the sector. Proxies have tracking error, fees and short histories, so conclusions are indicative only.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import fund_analytics as fa
from .dry_periods import calendar_returns, dry_profile
from .technicals import trend_snapshot

# Search terms to find sector proxies on the Fund comparison / sector tabs (availability varies; verify each result).
SECTOR_PROXY_SEARCH: dict[str, str] = {
    "Banking": "nifty bank index direct growth", "IT / Technology": "nifty it index direct growth",
    "Pharma / Healthcare": "nifty pharma OR healthcare direct growth", "FMCG": "nifty fmcg direct growth",
    "Automobile": "nifty auto direct growth", "Infrastructure": "infrastructure fund direct growth",
    "Metals": "nifty metal direct growth", "Energy / Oil & Gas": "energy fund direct growth",
    "Realty": "nifty realty direct growth", "PSU": "psu equity fund direct growth",
    "Consumption": "consumption fund direct growth", "Financial services": "financial services fund direct growth",
}

# Dry-period risk label thresholds (years underwater, share of days below a prior peak)
DRY_HIGH = (5.0, 0.50)
DRY_MODERATE = (3.0, 0.30)


def dry_risk_label(longest_underwater_years: float, pct_time_down_10: float) -> str:
    """High if the longest wait for a new high (after a 10%+ fall) exceeded 5 years or the series spent over 50% of days more than 10%
    below a prior peak; Moderate at 3 years / 30%; otherwise Low."""
    if pd.isna(longest_underwater_years) or pd.isna(pct_time_down_10):
        return "n/a"
    if longest_underwater_years > DRY_HIGH[0] or pct_time_down_10 > DRY_HIGH[1]:
        return "High"
    if longest_underwater_years > DRY_MODERATE[0] or pct_time_down_10 > DRY_MODERATE[1]:
        return "Moderate"
    return "Low"


SUMMARY_COLUMNS = ["History (yrs)", "CAGR", "Volatility", "Max drawdown", "Longest underwater (yrs)", "% time >10% below peak",
                   "Current drawdown", "Years since high", "% 1Y windows negative", "Longest negative-1Y spell (yrs)",
                   "% 3Y windows below inflation", "Worst year", "Best year", "% 1Y windows lagging benchmark",
                   "Longest lag vs benchmark (yrs)", "Dry-period risk", "Trend"]


def sector_summary(navs: dict[str, pd.Series], benchmark: pd.Series | None = None, inflation: float = 0.06,
                   min_depth: float = 0.10) -> pd.DataFrame:
    """One row per sector with the dry-period lenses side by side (each sector measured over its own full history)."""
    rows = {}
    for name, s in navs.items():
        p = dry_profile(s, benchmark, inflation, min_depth)
        rows[name] = {
            "History (yrs)": p["history_years"], "CAGR": p["cagr"], "Volatility": fa.volatility(s),
            "Max drawdown": p["max_drawdown"], "Longest underwater (yrs)": p["longest_underwater_years"],
            "% time >10% below peak": p["pct_time_down_10"], "Current drawdown": p["current_drawdown"],
            "Years since high": p["years_since_high"], "% 1Y windows negative": p["pct_1y_negative"],
            "Longest negative-1Y spell (yrs)": p["longest_negative_1y_years"],
            "% 3Y windows below inflation": p["pct_3y_below_inflation"], "Worst year": p["worst_calendar_year"],
            "Best year": p["best_calendar_year"],
            "% 1Y windows lagging benchmark": p.get("pct_1y_lagging", float("nan")),
            "Longest lag vs benchmark (yrs)": p.get("longest_lag_years", float("nan")),
            "Dry-period risk": dry_risk_label(p["longest_underwater_years"], p["pct_time_down_10"]),
            "Trend": trend_snapshot(s)["trend"],
        }
    df = pd.DataFrame.from_dict(rows, orient="index", columns=SUMMARY_COLUMNS)
    df.index.name = "Sector"
    return df


def rotation_ranks(navs: dict[str, pd.Series]) -> pd.DataFrame:
    """Calendar-year rank of each sector (1 = best that year); shows leadership rotating between sectors."""
    cal = calendar_returns(navs)
    return cal.rank(axis=1, ascending=False, method="min").astype("Int64") if not cal.empty else cal


def rotation_summary(navs: dict[str, pd.Series], top_n: int = 2) -> pd.DataFrame:
    """How often each sector was among the best / worst `top_n` in a year, and how often it lost money."""
    cal = calendar_returns(navs)
    if cal.empty:
        return pd.DataFrame()
    ranks = cal.rank(axis=1, ascending=False, method="min")
    n = cal.shape[1]
    return pd.DataFrame({
        "Years measured": cal.notna().sum(),
        f"Years in top {top_n}": (ranks <= top_n).sum(),
        f"Years in bottom {top_n}": (ranks > n - top_n).sum(),
        "Loss-making years": (cal < 0).sum(),
        "Return spread (best - worst year)": cal.max() - cal.min(),
    })


def correlation_matrix(navs: dict[str, pd.Series]) -> pd.DataFrame:
    """Correlation of daily returns on overlapping dates. High values mean sectors tend to be dry at the same time."""
    rets = pd.concat({k: fa.daily_returns(v) for k, v in navs.items()}, axis=1, join="inner").dropna()
    return rets.corr() if len(rets) > 30 else pd.DataFrame()


def horizon_warnings(summary: pd.DataFrame, horizon_years: float, tolerable_decline: float | None = None) -> list[str]:
    """Compare each series' historical dry-period figures with the investor's own horizon and tolerable decline."""
    out = []
    for name, r in summary.iterrows():
        wait = r.get("Longest underwater (yrs)")
        if pd.notna(wait) and wait > horizon_years:
            out.append(f"{name}: it once took {wait:.1f} years to regain a previous high, longer than your {horizon_years:g}-year horizon.")
        dd = r.get("Max drawdown")
        if tolerable_decline is not None and pd.notna(dd) and -dd > tolerable_decline:
            out.append(f"{name}: its worst past fall ({dd:.0%}) exceeds the temporary decline you said you could tolerate (about {tolerable_decline:.0%}).")
        cur = r.get("Current drawdown")
        if pd.notna(cur) and cur <= -0.10:
            out.append(f"{name}: currently {cur:.0%} below its previous high.")
    return out
