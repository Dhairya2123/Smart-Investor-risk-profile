"""Optional run history in SQLite (standard library, no server needed).

Mirrors the `risk_assessment` table in schema.sql (PostgreSQL version). Stores scores and
the profile only: no names, contact details or ID numbers. Sessions are random UUIDs.
"""
from __future__ import annotations

import json
import sqlite3
import uuid
from pathlib import Path

import pandas as pd

from .risk_engine import RiskResult

DEFAULT_DB = Path(__file__).resolve().parent.parent / "data" / "runs.db"

DDL = """
CREATE TABLE IF NOT EXISTS risk_assessment (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    anon_session_id TEXT NOT NULL,
    capacity        REAL, tolerance REAL, required REAL, bearable REAL,
    profile         TEXT NOT NULL,
    required_return REAL,
    equity_weight   REAL,
    warnings        TEXT
);
"""


def connect(db_path: str | Path | None = None) -> sqlite3.Connection:
    path = Path(db_path) if db_path else DEFAULT_DB
    if str(path) != ":memory:":
        path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    conn.execute(DDL)
    return conn


def new_session_id() -> str:
    return str(uuid.uuid4())


def save_run(conn: sqlite3.Connection, session_id: str, risk: RiskResult, equity_weight: float) -> int:
    cur = conn.execute(
        "INSERT INTO risk_assessment (anon_session_id, capacity, tolerance, required, bearable, profile, "
        "required_return, equity_weight, warnings) VALUES (?,?,?,?,?,?,?,?,?)",
        (session_id, risk.capacity, risk.tolerance, risk.required, risk.bearable, risk.profile,
         risk.required_return, equity_weight, json.dumps(risk.warnings)))
    conn.commit()
    return int(cur.lastrowid)


def load_runs(conn: sqlite3.Connection, session_id: str | None = None, limit: int = 100) -> pd.DataFrame:
    q = ("SELECT id, created_at, capacity, tolerance, required, bearable, profile, required_return, "
         "equity_weight, warnings FROM risk_assessment")
    params: tuple = ()
    if session_id:
        q += " WHERE anon_session_id = ?"
        params = (session_id,)
    q += " ORDER BY id DESC LIMIT ?"
    df = pd.read_sql_query(q, conn, params=params + (limit,))
    if not df.empty:
        df["warnings"] = df["warnings"].map(lambda s: len(json.loads(s)) if s else 0)
        df = df.rename(columns={"warnings": "warning_count"})
    return df


def delete_all(conn: sqlite3.Connection) -> None:
    conn.execute("DELETE FROM risk_assessment")
    conn.commit()
