"""Power BI-ready exports: tidy CSV tables (and a zip bundle) that load directly into Power BI / Excel.

Tables are in 'long' format so Power BI can slice by fund, date or metric without reshaping.
"""
from __future__ import annotations

import io
import zipfile

import pandas as pd

from . import fund_analytics as fa
from .allocation import Allocation
from .crash import CrashResult, GoalImpact
from .goal import GoalFeasibility
from .risk_engine import RiskResult


def assessment_table(risk: RiskResult, feas: GoalFeasibility | None = None) -> pd.DataFrame:
    row = {
        "tolerance": risk.tolerance, "tolerance_level": risk.tolerance_level,
        "capacity": risk.capacity, "capacity_level": risk.capacity_level,
        "required": risk.required, "required_level": risk.required_level,
        "overall_score": risk.overall, "overall_profile": risk.profile,
        "required_return": risk.required_return, "goal_reachable": risk.goal_reachable,
        "risk_mismatch": "Potential mismatch" if risk.mismatch else "None",
        "provisional": risk.provisional, "warning_count": len(risk.warnings),
    }
    if feas is not None:
        row.update({"goal_feasibility": feas.label, "goal_target": feas.target, "goal_base_value": feas.base_value})
    return pd.DataFrame([row])


def warnings_table(risk: RiskResult) -> pd.DataFrame:
    return pd.DataFrame({"code": risk.codes, "warning": risk.warnings})


def allocation_table(alloc: Allocation) -> pd.DataFrame:
    return pd.DataFrame({"asset_class": ["Equity", "Debt", "Cash"], "weight": [alloc.equity, alloc.debt, alloc.cash]})


def crash_table_df(crashes: list[CrashResult]) -> pd.DataFrame:
    return pd.DataFrame([{"equity_shock": c.equity_shock, "start_value": c.start_value, "end_value": c.end_value,
                          "loss_amount": c.loss_amount, "loss_pct": c.loss_pct, "recovery_years": c.recovery_years}
                         for c in crashes])


def goal_impact_df(impacts: list[GoalImpact]) -> pd.DataFrame:
    return pd.DataFrame([{"equity_shock": g.equity_shock, "shock_year": g.shock_year, "target": g.target,
                          "value_no_shock": g.value_no_shock, "value_with_shock": g.value_with_shock,
                          "value_lost": g.value_lost, "goal_met_with_shock": g.met_with_shock} for g in impacts])


def fund_metrics_long(table: pd.DataFrame) -> pd.DataFrame:
    """Wide metrics table -> long (fund, metric, value) for Power BI."""
    if table is None or table.empty:
        return pd.DataFrame(columns=["fund", "metric", "value"])
    num = table.select_dtypes("number").drop(columns=["Observations"], errors="ignore")
    long = num.reset_index().melt(id_vars="Fund", var_name="metric", value_name="value")
    return long.rename(columns={"Fund": "fund"})


def nav_long(navs: dict[str, pd.Series], years: float | None = None) -> pd.DataFrame:
    """NAV, indexed growth (100 at window start) and drawdown per fund per date."""
    frames = []
    for name, s in navs.items():
        w = fa.slice_period(s, years)
        if w.empty:
            continue
        frames.append(pd.DataFrame({"fund": name, "date": w.index, "nav": w.to_numpy(),
                                    "growth_of_100": (w / w.iloc[0] * 100).to_numpy(),
                                    "drawdown": fa.drawdown_series(w).to_numpy()}))
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(
        columns=["fund", "date", "nav", "growth_of_100", "drawdown"])


def rolling_long(navs: dict[str, pd.Series], window_years: int = 3) -> pd.DataFrame:
    frames = []
    for name, s in navs.items():
        rr = fa.rolling_returns(s, window_years)
        if len(rr):
            frames.append(pd.DataFrame({"fund": name, "date": rr.index, "window_years": window_years,
                                        "rolling_return": rr.to_numpy()}))
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(
        columns=["fund", "date", "window_years", "rolling_return"])


README_TEXT = """Power BI import guide
=====================
1. Power BI Desktop > Get data > Text/CSV, import every CSV in this folder.
2. assessment.csv has one row (tolerance, capacity, required, overall profile, goal feasibility, mismatch).
   fund_shortlist.csv lists the fund CATEGORIES to research for the profile (educational, not recommendations).
3. Relationships: fund_metrics[fund] -> nav_history[fund] -> rolling_returns[fund] (many-to-many on fund, or add a Fund dimension).
4. Suggested visuals: gauge/cards for the three scores, donut for allocation, bar for crash_scenarios and goal_impact,
   line chart (nav_history: date x growth_of_100, legend = fund), drawdown area chart, matrix of fund_metrics.
5. Add a text box on every page: "Educational only. Not investment advice. Scenarios are not forecasts."
6. If data_source says SYNTHETIC, the funds are demo data and must not be presented as real performance.
"""


def build_bundle(risk: RiskResult, alloc: Allocation, crashes: list[CrashResult],
                 fund_table: pd.DataFrame | None, navs: dict[str, pd.Series] | None,
                 years: float | None, window_years: int, data_note: str,
                 feas: GoalFeasibility | None = None, impacts: list[GoalImpact] | None = None,
                 shortlist_df: pd.DataFrame | None = None,
                 extra_files: dict[str, pd.DataFrame] | None = None) -> bytes:
    """Return a zip (as bytes) of tidy CSVs plus an import guide."""
    files = {
        "assessment.csv": assessment_table(risk, feas),
        "warnings.csv": warnings_table(risk),
        "allocation.csv": allocation_table(alloc),
        "crash_scenarios.csv": crash_table_df(crashes),
        "goal_impact.csv": goal_impact_df(impacts or []),
        "fund_shortlist.csv": shortlist_df if shortlist_df is not None else pd.DataFrame(),
        "fund_metrics.csv": fund_metrics_long(fund_table),
        "nav_history.csv": nav_long(navs or {}, years),
        "rolling_returns.csv": rolling_long(navs or {}, window_years),
        "data_source.csv": pd.DataFrame({"note": [data_note or "No fund data loaded"]}),
    }
    for fname, df in (extra_files or {}).items():
        files[fname] = df
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for fname, df in files.items():
            z.writestr(fname, df.to_csv(index=False))
        z.writestr("README.txt", README_TEXT)
    return buf.getvalue()
