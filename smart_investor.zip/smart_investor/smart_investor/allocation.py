"""Illustrative asset-allocation scenarios and goal projections.

The return/volatility figures below are ILLUSTRATIVE planning assumptions, not
forecasts. They are editable in the app. Review before any real-world use.
"""
from __future__ import annotations

from dataclasses import dataclass

from .risk_engine import PROFILES, future_value

# Equity share range (min, max) per profile. Debt and cash fill the rest.
EQUITY_BANDS = {
    "Conservative": (0.10, 0.25),
    "Moderately Conservative": (0.25, 0.45),
    "Moderate": (0.45, 0.60),
    "Moderately Aggressive": (0.60, 0.80),
    "Aggressive": (0.80, 0.95),
}
# Minimum cash share per profile (liquidity buffer inside the portfolio).
MIN_CASH = {"Conservative": 0.10, "Moderately Conservative": 0.07, "Moderate": 0.05,
            "Moderately Aggressive": 0.03, "Aggressive": 0.02}

# Illustrative annual assumptions.
DEFAULT_ASSUMPTIONS = {
    "equity": {"return": 0.12, "vol": 0.17},
    "debt": {"return": 0.07, "vol": 0.03},
    "cash": {"return": 0.055, "vol": 0.005},
}


@dataclass(frozen=True)
class Allocation:
    equity: float
    debt: float
    cash: float

    def as_dict(self) -> dict[str, float]:
        return {"equity": self.equity, "debt": self.debt, "cash": self.cash}


def equity_cap_for_horizon(horizon_years: float) -> float:
    """Maximum equity share allowed by time horizon, regardless of profile."""
    if horizon_years < 1:
        return 0.10
    if horizon_years < 3:
        return 0.30
    if horizon_years < 5:
        return 0.55
    return 1.0


def allocation_for(profile: str, horizon_years: float, tilt: float = 0.5) -> Allocation:
    """Pick an allocation inside the profile's band.

    tilt: 0 = bottom of the equity band, 1 = top. The horizon cap always applies.
    """
    if profile not in EQUITY_BANDS:
        raise ValueError(f"Unknown profile: {profile}")
    if not 0.0 <= tilt <= 1.0:
        raise ValueError("tilt must be between 0 and 1")
    lo, hi = EQUITY_BANDS[profile]
    equity = lo + (hi - lo) * tilt
    equity = min(equity, equity_cap_for_horizon(horizon_years))
    cash = MIN_CASH[profile]
    equity = min(equity, 1.0 - cash)
    debt = 1.0 - equity - cash
    return Allocation(round(equity, 4), round(debt, 4), round(cash, 4))


def portfolio_stats(alloc: Allocation, assumptions: dict | None = None,
                    equity_debt_corr: float = 0.1) -> tuple[float, float]:
    """Expected return and volatility for the mix (cash treated as uncorrelated)."""
    a = assumptions or DEFAULT_ASSUMPTIONS
    ret = sum(getattr(alloc, k) * a[k]["return"] for k in ("equity", "debt", "cash"))
    e, d, c = alloc.equity, alloc.debt, alloc.cash
    var = ((e * a["equity"]["vol"]) ** 2 + (d * a["debt"]["vol"]) ** 2 + (c * a["cash"]["vol"]) ** 2
           + 2 * e * d * a["equity"]["vol"] * a["debt"]["vol"] * equity_debt_corr)
    return ret, var ** 0.5


def project_goal(alloc: Allocation, current: float, monthly: float, years: float,
                 assumptions: dict | None = None) -> dict[str, float]:
    """Illustrative end values under pessimistic / base / optimistic return cases.

    Pessimistic and optimistic shift the base return by one portfolio volatility.
    These are scenarios, not probabilities or guarantees.
    """
    ret, vol = portfolio_stats(alloc, assumptions)
    return {
        "pessimistic": future_value(current, monthly, max(ret - vol, -0.5), years),
        "base": future_value(current, monthly, ret, years),
        "optimistic": future_value(current, monthly, ret + vol, years),
    }
