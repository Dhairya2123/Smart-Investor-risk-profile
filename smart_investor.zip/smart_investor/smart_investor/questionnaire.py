"""The 53-question Smart Investor questionnaire (data-driven) plus validation.

Mirrors 'Smart_Investor_Risk_Profile_Complete_Questionnaire.docx'. Every question is data, so the scoring
blueprint can be audited and tested. Question kinds:

  single  - pick one option (option value = 0-100 score, or None if the answer is context only / not scored)
  multi   - pick several (scored only when `scorer` is set: 'pressure' or 'breadth')
  number  - rupee amount
  text    - free text (context only)

Dimensions: capacity, tolerance (scored); goal (feeds the goal model); context / review (never scored).
Per the questionnaire's safety notes, age, occupation and spending style are NOT used to infer risk preference.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

SECTIONS = {
    1: ("Personal & financial background", "These questions establish the investor's basic financial circumstances."),
    2: ("Lifestyle & financial commitments", "Lifestyle affects how much money is available to invest, how flexible you are, "
                                              "and whether a temporary loss could disrupt day-to-day life."),
    3: ("Risk tolerance", "Emotional willingness to accept volatility and temporary losses. "
                          "It is not the same as the financial ability to absorb a loss."),
    4: ("Risk capacity", "The financial ability to absorb losses without jeopardising essential expenses, obligations or goals."),
    5: ("Risk required & financial goals", "Risk required is calculated from your goal, current assets, contributions and time. "
                                           "You are not asked to guess a return."),
    6: ("Investment experience & knowledge", "Experience helps understanding of risk but does not prove you can afford risk."),
    7: ("Review & confirmation", "Please check your answers before calculating."),
}


@dataclass(frozen=True)
class Question:
    num: int
    key: str
    label: str            # short name used in explanations
    text: str
    section: int
    kind: str             # single | multi | number | text
    dimension: str        # capacity | tolerance | goal | context | review
    options: dict = field(default_factory=dict)
    weight: float = 1.0
    scorer: str = ""      # "" | "pressure" | "breadth" (multi questions only)
    required: bool = True
    help: str = ""

    @property
    def scored(self) -> bool:
        return self.dimension in ("capacity", "tolerance") and self.kind in ("single", "multi")


def _q(num, key, label, text, section, kind, dim, options=None, weight=1.0, scorer="", required=True, help=""):
    return Question(num, key, label, text, section, kind, dim, options or {}, weight, scorer, required, help)


def _ctx(*labels):
    """Context-only options (not scored)."""
    return {l: None for l in labels}


NO_MAJOR = "No major change expected"

ALL_QUESTIONS: list[Question] = [
    # ------------------------------------------------------------------ Section 1
    _q(1, "age", "Age", "What is your age?", 1, "single", "context",
       _ctx("Below 25", "25–35", "36–45", "46–55", "Above 55")),
    _q(2, "employment", "Employment", "What is your current employment status?", 1, "single", "context",
       _ctx("Salaried employee", "Self-employed", "Business owner", "Freelancer / gig worker", "Retired", "Student", "Other")),
    _q(3, "income_band", "Monthly income", "What is your approximate monthly take-home income?", 1, "single", "context",
       _ctx("Below ₹25,000", "₹25,000–₹50,000", "₹50,000–₹1 lakh", "₹1–2 lakh", "Above ₹2 lakh")),
    _q(4, "income_stability", "Income stability", "How stable is your primary income?", 1, "single", "capacity",
       {"Very stable": 95, "Mostly stable": 70, "Somewhat variable": 40, "Highly unpredictable": 10}, 0.6),
    _q(5, "dependants", "Dependants", "How many people financially depend on you?", 1, "single", "capacity",
       {"None": 95, "1–2": 60, "3–4": 35, "More than 4": 15}, 1.0),
    _q(6, "savings_rate", "Savings rate", "Approximately what percentage of monthly income do you save or invest?", 1, "single", "capacity",
       {"Below 5%": 10, "5–10%": 35, "10–20%": 60, "20–30%": 80, "Above 30%": 95}, 0.8),
    _q(7, "total_savings", "Total savings", "What is your approximate total value of current savings and investments "
       "(excluding your primary residence)?", 1, "single", "capacity",
       {"Below ₹1 lakh": 10, "₹1–5 lakh": 30, "₹5–15 lakh": 55, "₹15–50 lakh": 80, "Above ₹50 lakh": 95,
        "Prefer not to say": None}, 0.8),
    # ------------------------------------------------------------------ Section 2
    _q(8, "spending_pattern", "Spending pattern", "How would you describe your current monthly spending pattern?", 2, "single", "capacity",
       {"I spend almost all my income": 10, "I usually have a small surplus": 40,
        "I regularly save a meaningful amount": 75, "I have a large and consistent surplus": 95}, 0.6),
    _q(9, "essential_expenses", "Essential expenses", "Approximately how much do you spend each month on essential expenses "
       "(housing, food, utilities, transport, education, etc.)?", 2, "number", "context", required=False),
    _q(10, "discretionary_expenses", "Discretionary expenses", "Approximately how much do you spend each month on non-essential or "
       "discretionary expenses (travel, dining, shopping, entertainment, hobbies, etc.)?", 2, "number", "context", required=False),
    _q(11, "lifestyle_priority", "Lifestyle priority", "Which statement best describes your lifestyle priorities?", 2, "single", "context",
       _ctx("I prioritize security and predictable expenses", "I balance saving with enjoying the present",
            "I prioritize experiences and lifestyle spending", "I am willing to reduce spending to meet long-term goals"),
       help="Context only. Spending style is not used to infer risk preference."),
    _q(12, "spending_flexibility", "Spending flexibility", "How flexible would you be if you needed to reduce your spending for 6–12 months?",
       2, "single", "capacity",
       {"Not flexible; most expenses are essential": 10, "Slightly flexible": 35, "Moderately flexible": 65,
        "Very flexible; I can reduce discretionary spending substantially": 90}, 0.8),
    _q(13, "life_events", "Life events (5 yrs)", "Do you expect any major lifestyle change in the next five years? [Select all that apply]",
       2, "multi", "capacity",
       {"Buying a home": 1, "Marriage or starting a family": 1, "Having or supporting children": 1, "Higher education": 1,
        "Career change / relocation": 0.5, "Starting or expanding a business": 1, "Retirement": 1, NO_MAJOR: 0, "Other": 0.5},
       0.8, scorer="pressure"),
    _q(14, "expense_predictability", "Expense predictability", "How predictable are your major expenses over the next 1–3 years?",
       2, "single", "capacity", {"Very predictable": 90, "Mostly predictable": 65, "Somewhat uncertain": 35, "Highly uncertain": 10}, 0.8),
    _q(15, "family_support", "Family support", "Do you regularly provide financial support to family members beyond your household?",
       2, "single", "capacity", {"No": 90, "Yes, a small amount": 65, "Yes, a significant amount": 30, "The amount varies": 40}, 0.6),
    _q(16, "housing", "Housing", "How would you describe your housing situation?", 2, "single", "context",
       _ctx("Own home with no home loan", "Own home with a home loan", "Renting", "Living with family", "Other"),
       help="Context only; the cost of any home loan is captured in the debt question."),
    _q(17, "insurance", "Insurance cover", "Do you have insurance or other financial protection for major unexpected expenses?",
       2, "single", "capacity",
       {"Adequate health / life / other cover as relevant": 95, "Some cover, but may be insufficient": 50,
        "No meaningful cover": 10, "Not sure": 25}, 1.0),
    _q(18, "unexpected_withdrawal", "Chance of forced withdrawal", "How likely is your lifestyle or income to require a large withdrawal "
       "from investments unexpectedly?", 2, "single", "capacity",
       {"Very unlikely": 95, "Unlikely": 70, "Possible": 35, "Likely": 5}, 1.2),
    # ------------------------------------------------------------------ Section 3: tolerance
    _q(19, "reaction_10pct", "Reaction to a 10% fall", "How would you react if your investment portfolio declined by 10% in one month?",
       3, "single", "tolerance",
       {"Sell all investments immediately": 0, "Sell some investments": 25, "Feel uncomfortable but hold": 55,
        "Stay invested without major concern": 80, "Consider investing more": 100}, 1.5),
    _q(20, "reaction_5_to_4_lakh", "Reaction to ₹5L→₹4L", "Suppose you invested ₹5 lakh and its value dropped to ₹4 lakh. "
       "What would you most likely do?", 3, "single", "tolerance",
       {"Withdraw the remaining amount": 0, "Sell a major portion": 20, "Wait for recovery": 55,
        "Continue investing as planned": 80, "Invest additional money": 100}, 1.5),
    _q(21, "tolerable_decline", "Tolerable temporary decline", "What temporary decline in your overall investment portfolio could you "
       "emotionally tolerate?", 3, "single", "tolerance",
       {"0–5%": 5, "5–10%": 30, "10–15%": 50, "15–25%": 75, "More than 25%": 100}, 1.6),
    _q(22, "preferred_mix", "Comfortable investment mix", "Which investment mix would make you most comfortable?", 3, "single", "tolerance",
       {"Mostly deposits / high-quality short-term debt": 5, "Mostly debt with a small equity allocation": 30,
        "A balanced mix of debt and equity": 55, "Mostly equity mutual funds / index funds": 80,
        "Predominantly equity and other high-volatility assets": 100}, 1.3),
    _q(23, "uncertainty", "Attitude to uncertainty", "How do you feel about uncertainty in financial markets?", 3, "single", "tolerance",
       {"I strongly dislike uncertainty": 5, "I prefer predictable returns": 30, "I can accept some uncertainty": 55,
        "I am comfortable with market fluctuations": 80, "I actively seek higher-risk opportunities": 100}, 1.0),
    _q(24, "underperformance", "Reaction to 2 years of underperformance", "If your investment underperformed its benchmark for two "
       "consecutive years, what would you do?", 3, "single", "tolerance",
       {"Exit immediately": 5, "Shift to safer investments": 30, "Review the investment and wait": 55,
        "Stay invested if the reasons for investing remain valid": 80,
        "Consider investing more after reviewing the facts": 95}, 1.0),
    _q(25, "philosophy", "Investment philosophy", "Which statement best describes your investment philosophy?", 3, "single", "tolerance",
       {"Protecting capital is my top priority": 5, "I prefer stable returns with limited fluctuations": 30,
        "I balance growth and stability": 55, "I prioritize long-term wealth creation": 80,
        "I accept substantial risk for higher potential returns": 100}, 1.2),
    _q(26, "crash_20pct", "Reaction to a 20% crash", "If your portfolio declined by 20% during a market crash and your goal was still "
       "10 years away, what would you most likely do?", 3, "single", "tolerance",
       {"Exit the market": 0, "Reduce equity exposure": 25, "Hold investments": 55,
        "Continue planned contributions / SIPs": 80, "Increase investments after reviewing my finances": 100}, 1.6),
    _q(27, "check_frequency", "Portfolio-checking habit", "How often would you check your investment portfolio during a volatile market?",
       3, "single", "tolerance",
       {"Several times a day": 10, "Daily": 30, "Weekly": 55, "Monthly": 80, "Only during scheduled reviews": 95}, 0.6),
    # ------------------------------------------------------------------ Section 4: capacity
    _q(28, "emergency_fund", "Emergency fund", "How many months of essential living expenses do you have in an accessible emergency fund?",
       4, "single", "capacity",
       {"No emergency savings": 0, "Less than 3 months": 20, "3–6 months": 55, "6–12 months": 85, "More than 12 months": 100}, 1.5),
    _q(29, "debt_burden", "Debt burden", "Approximately what percentage of your monthly take-home income goes toward EMIs and debt repayments?",
       4, "single", "capacity",
       {"No debt repayments": 100, "Less than 10%": 85, "10–20%": 60, "20–35%": 30, "More than 35%": 5}, 1.3),
    _q(30, "financial_position", "Financial position", "Which statement best describes your current financial position?",
       4, "single", "capacity",
       {"Expenses exceed income": 0, "Income and expenses are almost equal": 20, "I save a small amount": 50,
        "I save a significant amount": 80, "I have substantial savings and investments": 100}, 0.8),
    _q(31, "asset_share", "Share of total assets at risk", "What proportion of your total financial assets would this investment represent?",
       4, "single", "capacity",
       {"More than 75%": 5, "50–75%": 25, "25–50%": 55, "10–25%": 80, "Less than 10%": 100}, 1.0),
    _q(32, "job_stability", "Employment stability", "How stable is your employment or primary source of income?",
       4, "single", "capacity",
       {"Very uncertain": 5, "Somewhat uncertain": 30, "Moderately stable": 55, "Stable": 80, "Highly stable": 100}, 0.8),
    _q(33, "withdrawal_horizon", "Time until withdrawal", "How soon might you need to withdraw this investment?", 4, "single", "capacity",
       {"Within 1 year": 0, "1–3 years": 20, "3–5 years": 45, "5–10 years": 80, "More than 10 years": 100}, 1.3),
    _q(34, "obligations", "Major obligations (5 yrs)", "Do you have major financial obligations expected in the next five years?",
       4, "single", "capacity",
       {"Yes, within 1 year": 5, "Yes, within 1–3 years": 25, "Yes, within 3–5 years": 55, "No major obligations": 95,
        "Not sure": 40}, 1.0),
    _q(35, "loss_impact", "Impact of a 25% fall", "If your investments declined by 25%, would your essential lifestyle or financial "
       "obligations be affected?", 4, "single", "capacity",
       {"Severely affected": 0, "Significantly affected": 20, "Somewhat affected": 50, "Minimally affected": 80,
        "Not affected": 100}, 1.5),
    _q(36, "liquidity", "Portfolio liquidity", "How much of your current investment portfolio is readily accessible without a "
       "significant penalty or loss?", 4, "single", "capacity",
       {"Almost none": 5, "Less than 25%": 25, "25–50%": 50, "50–75%": 75, "More than 75%": 95}, 1.0),
    # ------------------------------------------------------------------ Section 5: goal
    _q(37, "objectives", "Objectives", "What is your primary investment objective? [Select all that apply]", 5, "multi", "context",
       _ctx("Capital preservation", "Regular income generation", "Wealth creation", "Retirement planning", "Children's education",
            "House / property purchase", "Financial independence", "Other")),
    _q(38, "goal_amount", "Goal amount", "What is the target amount required for your main financial goal? (₹, in today's money)",
       5, "number", "goal"),
    _q(39, "invested", "Already invested for goal", "How much have you already invested toward this goal?", 5, "number", "goal"),
    _q(40, "monthly_contribution", "Monthly contribution", "How much can you invest toward this goal each month?", 5, "number", "goal"),
    _q(41, "goal_horizon", "Goal horizon", "When do you want to achieve this financial goal?", 5, "single", "goal",
       _ctx("Within 1 year", "1–3 years", "3–5 years", "5–10 years", "More than 10 years")),
    _q(42, "goal_inflation", "Goal vs inflation", "Is your target goal amount fixed or expected to rise with inflation?", 5, "single", "goal",
       _ctx("Fixed amount", "Expected to rise with inflation", "Not sure")),
    _q(43, "goal_flexibility", "Goal flexibility", "How flexible is this financial goal?", 5, "single", "goal",
       _ctx("Non-negotiable; cannot be delayed or reduced", "Slightly flexible", "Moderately flexible",
            "I can postpone the goal", "I can significantly revise the target")),
    _q(44, "shortfall_preference", "Preferred fix if plan falls short", "If your current plan appears insufficient to reach the goal, "
       "what would you prefer to consider first?", 5, "single", "goal",
       _ctx("Increase monthly contributions", "Extend the investment period", "Reduce or revise the target amount",
            "Review whether a different risk level is appropriate", "Reconsider the goal")),
    _q(45, "other_goals", "Other goals", "Do you have more than one major financial goal? If yes, list each goal, target amount and "
       "target date.", 5, "text", "context", required=False),
    # ------------------------------------------------------------------ Section 6: experience (modest weight in tolerance)
    _q(46, "investing_years", "Investing experience", "How long have you been investing?", 6, "single", "tolerance",
       {"I have never invested": 10, "Less than 1 year": 25, "1–3 years": 50, "3–5 years": 70, "More than 5 years": 90}, 0.5),
    _q(47, "products_used", "Products used", "Which investment products have you used? [Select all that apply]", 6, "multi", "tolerance",
       {"Fixed deposits / recurring deposits": None, "Debt mutual funds": None, "Equity mutual funds": None,
        "Index funds / ETFs": None, "Direct stocks": None, "Bonds": None, "Gold": None, "Derivatives": None, "Other": None},
       0.4, scorer="breadth", required=False),
    _q(48, "risk_understanding", "Understanding of risk", "How would you rate your understanding of investment risk?",
       6, "single", "tolerance",
       {"Beginner": 10, "Basic": 30, "Intermediate": 55, "Advanced": 80, "Expert": 95}, 0.5),
    _q(49, "past_loss", "Past loss", "Have you previously experienced a significant loss in your investments?", 6, "single", "context",
       _ctx("No", "Yes, less than 5%", "Yes, 5–10%", "Yes, 10–20%", "Yes, more than 20%")),
    _q(50, "accepts_risk_return", "Understands risk-return", "Do you understand that investments with higher expected returns can also "
       "experience larger losses, and that returns are not guaranteed?", 6, "single", "context",
       _ctx("Yes, clearly", "I understand partly", "No, I need an explanation")),
    # ------------------------------------------------------------------ Section 7
    _q(51, "other_circumstances", "Other circumstances", "Is there any important financial, family, career, or lifestyle circumstance "
       "that has not been covered above?", 7, "text", "review", required=False),
    _q(52, "confirmed", "Answers confirmed", "Are the answers provided a fair reflection of your current circumstances and expectations?",
       7, "single", "review", _ctx("Yes", "No — I would like to review my answers")),
    _q(53, "additional_info", "Additional information", "Would you like to add any other information that may help explain your "
       "investment preferences or financial goals?", 7, "text", "review", required=False),
]

QUESTIONS_BY_KEY: dict[str, Question] = {q.key: q for q in ALL_QUESTIONS}
CAPACITY_QUESTIONS = [q for q in ALL_QUESTIONS if q.dimension == "capacity" and q.scored]
TOLERANCE_QUESTIONS = [q for q in ALL_QUESTIONS if q.dimension == "tolerance" and q.scored]

# ------------------------------------------------------------------ lookups derived from answers
HORIZON_YEARS = {"Within 1 year": 0.75, "1–3 years": 2.0, "3–5 years": 4.0, "5–10 years": 7.5, "More than 10 years": 12.0}

# Mid-points of the 'temporary decline you could tolerate' bands (fraction of portfolio)
TOLERABLE_DECLINE = {"0–5%": 0.025, "5–10%": 0.075, "10–15%": 0.125, "15–25%": 0.20, "More than 25%": 0.30}

# Equity share range that matches each 'comfortable mix' answer (used only as a comparison note)
PREFERRED_EQUITY = {
    "Mostly deposits / high-quality short-term debt": (0.0, 0.10),
    "Mostly debt with a small equity allocation": (0.10, 0.30),
    "A balanced mix of debt and equity": (0.40, 0.60),
    "Mostly equity mutual funds / index funds": (0.70, 0.90),
    "Predominantly equity and other high-volatility assets": (0.90, 1.00),
}

# Upper bound of the take-home income band (None = open-ended) - used only for consistency checks
INCOME_UPPER = {"Below ₹25,000": 25_000, "₹25,000–₹50,000": 50_000, "₹50,000–₹1 lakh": 100_000,
                "₹1–2 lakh": 200_000, "Above ₹2 lakh": None}


@dataclass
class GoalInputs:
    goal_amount: float                  # in today's rupees
    current_investments: float
    monthly_contribution: float
    horizon_years: float
    inflation_linked: bool = False
    inflation_rate: float = 0.06

    @property
    def effective_target(self) -> float:
        """Target in future rupees (inflated when the goal rises with inflation)."""
        if self.inflation_linked:
            return self.goal_amount * (1 + self.inflation_rate) ** self.horizon_years
        return self.goal_amount


@dataclass
class InvestorInputs:
    answers: dict[str, Any] = field(default_factory=dict)
    inflation_rate: float = 0.06
    goal_horizon_override: float | None = None   # exact years, overrides the band when set

    @property
    def goal(self) -> GoalInputs | None:
        a = self.answers
        try:
            years = self.goal_horizon_override or HORIZON_YEARS[a["goal_horizon"]]
            linked = a.get("goal_inflation") in ("Expected to rise with inflation", "Not sure")
            return GoalInputs(float(a["goal_amount"]), float(a["invested"]), float(a["monthly_contribution"]),
                              float(years), linked, self.inflation_rate)
        except (KeyError, TypeError, ValueError):
            return None


class ValidationError(ValueError):
    pass


def missing_questions(inputs: InvestorInputs) -> list[Question]:
    """Required questions that are unanswered or invalid (for the UI progress display)."""
    out = []
    for q in ALL_QUESTIONS:
        if not q.required:
            continue
        v = inputs.answers.get(q.key)
        if q.kind == "single" and v not in q.options:
            out.append(q)
        elif q.kind == "multi" and not v:
            out.append(q)
        elif q.kind == "number" and v is None:
            out.append(q)
    return out


def validate(inputs: InvestorInputs) -> None:
    """Raise ValidationError with a readable message on missing or bad input."""
    miss = missing_questions(inputs)
    if miss:
        raise ValidationError("Unanswered: " + ", ".join(f"Q{q.num}" for q in miss) + ".")
    a = inputs.answers
    for q in ALL_QUESTIONS:
        v = a.get(q.key)
        if q.kind == "single" and v is not None and v not in q.options:
            raise ValidationError(f"Invalid option for Q{q.num}: {v!r}.")
        if q.kind == "multi":
            bad = [x for x in (v or []) if x not in q.options]
            if bad:
                raise ValidationError(f"Invalid option(s) for Q{q.num}: {bad}.")
        if q.kind == "number" and v is not None and v < 0:
            raise ValidationError(f"Q{q.num} cannot be negative.")
    events = a["life_events"]
    if NO_MAJOR in events and len(events) > 1:
        raise ValidationError(f"Q13: '{NO_MAJOR}' cannot be combined with other life events.")
    if a["goal_amount"] <= 0:
        raise ValidationError("Q38: the goal amount must be positive.")
    if a["invested"] == 0 and a["monthly_contribution"] == 0:
        raise ValidationError("Q39/Q40: enter an amount already invested or a monthly contribution.")
    g = inputs.goal
    if g is None or not (0.5 <= g.horizon_years <= 50):
        raise ValidationError("Goal horizon must be between 0.5 and 50 years.")
    if not (0 <= inputs.inflation_rate <= 0.20):
        raise ValidationError("Inflation assumption must be between 0% and 20%.")
