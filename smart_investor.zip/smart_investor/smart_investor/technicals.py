"""Technical (price-trend) indicators computed on NAV or index series.

These describe the CURRENT trend and momentum of a series. They are context only: they are not used in the
risk profile or in the fund scorecard score, they do not predict returns, and they are weak tools for choosing
long-term mutual funds. NAV series have no volume, so volume-based indicators are not available.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .fund_analytics import clean_nav

TRADING_DAYS = 252


def sma(nav: pd.Series, window: int) -> pd.Series:
    return clean_nav(nav).rolling(window).mean()


def rsi(nav: pd.Series, period: int = 14) -> pd.Series:
    """Wilder's relative strength index (0-100)."""
    s = clean_nav(nav)
    delta = s.diff()
    gain = delta.clip(lower=0).ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    rs = gain / loss.replace(0, np.nan)
    out = 100 - 100 / (1 + rs)
    out[(loss == 0) & (gain > 0)] = 100.0
    return out


def _ret(s: pd.Series, days: int) -> float:
    return float(s.iloc[-1] / s.iloc[-1 - days] - 1) if len(s) > days else float("nan")


def trend_label(above_200: bool | None, golden: bool | None) -> str:
    if above_200 is None or golden is None:
        return "Insufficient data"
    if above_200 and golden:
        return "Uptrend"
    if (not above_200) and (not golden):
        return "Downtrend"
    return "Mixed"


def trend_snapshot(nav: pd.Series) -> dict:
    """Latest trend reading for one series. Fields are NaN/None when there is not enough history."""
    s = clean_nav(nav)
    nan = float("nan")
    out = {"last": float(s.iloc[-1]) if len(s) else nan, "dma50": nan, "dma200": nan, "above_200dma": None,
           "golden_cross": None, "rsi14": nan, "ret_3m": nan, "ret_6m": nan, "ret_12m": nan, "momentum_12_1": nan,
           "pct_below_52w_high": nan, "vol_ratio": nan, "trend": "Insufficient data"}
    if len(s) < 60:
        return out
    out["dma50"] = float(s.rolling(50).mean().iloc[-1])
    if len(s) >= 200:
        out["dma200"] = float(s.rolling(200).mean().iloc[-1])
        out["above_200dma"] = bool(s.iloc[-1] > out["dma200"])
        out["golden_cross"] = bool(out["dma50"] > out["dma200"])
    r = rsi(s).iloc[-1]
    out["rsi14"] = float(r) if pd.notna(r) else nan
    out["ret_3m"], out["ret_6m"], out["ret_12m"] = _ret(s, 63), _ret(s, 126), _ret(s, TRADING_DAYS)
    if len(s) > TRADING_DAYS:
        out["momentum_12_1"] = float(s.iloc[-22] / s.iloc[-1 - TRADING_DAYS] - 1)   # skips the latest month
    win = s.iloc[-TRADING_DAYS:]
    out["pct_below_52w_high"] = float(s.iloc[-1] / win.max() - 1)
    rets = s.pct_change().dropna()
    if len(rets) > TRADING_DAYS:
        out["vol_ratio"] = float(rets.iloc[-21:].std() / rets.iloc[-TRADING_DAYS:].std())
    out["trend"] = trend_label(out["above_200dma"], out["golden_cross"])
    return out


def trend_table(navs: dict[str, pd.Series]) -> pd.DataFrame:
    rows = []
    for name, s in navs.items():
        t = trend_snapshot(s)
        rsi_v = t["rsi14"]
        zone = "n/a" if pd.isna(rsi_v) else "Overbought (>70)" if rsi_v > 70 else "Oversold (<30)" if rsi_v < 30 else "Neutral"
        rows.append({"Series": name, "Trend": t["trend"], "Above 200-DMA": t["above_200dma"], "50-DMA above 200-DMA": t["golden_cross"],
                     "RSI(14)": t["rsi14"], "RSI zone": zone, "3M": t["ret_3m"], "6M": t["ret_6m"], "12M": t["ret_12m"],
                     "12-1M momentum": t["momentum_12_1"], "vs 52w high": t["pct_below_52w_high"]})
    return pd.DataFrame(rows).set_index("Series") if rows else pd.DataFrame()
