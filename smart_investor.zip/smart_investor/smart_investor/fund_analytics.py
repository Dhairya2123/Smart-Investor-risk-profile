"""Mutual-fund analytics on NAV time series.

Inputs are pandas Series of NAV indexed by a DatetimeIndex. All metrics use
daily NAV returns annualised with 252 trading days unless stated otherwise.
Metrics that cannot be computed return NaN rather than a misleading number.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

TRADING_DAYS = 252
DEFAULT_RF = 0.065  # illustrative risk-free rate (annual); editable in the app


def clean_nav(nav: pd.Series) -> pd.Series:
    """Sort, drop duplicates, non-positive and missing values."""
    s = nav.copy()
    s.index = pd.to_datetime(s.index)
    s = s[~s.index.duplicated(keep="last")].sort_index()
    s = pd.to_numeric(s, errors="coerce")
    return s[s > 0].dropna()


def slice_period(nav: pd.Series, years: float | None) -> pd.Series:
    """Last `years` of data (None = full history). Use the same window for all funds."""
    nav = clean_nav(nav)
    if years is None or nav.empty:
        return nav
    start = nav.index[-1] - pd.DateOffset(years=int(years), months=int(round((years % 1) * 12)))
    return nav[nav.index >= start]


def cagr(nav: pd.Series) -> float:
    nav = clean_nav(nav)
    if len(nav) < 2:
        return float("nan")
    days = (nav.index[-1] - nav.index[0]).days
    if days < 30:
        return float("nan")
    return float((nav.iloc[-1] / nav.iloc[0]) ** (365.25 / days) - 1)


def daily_returns(nav: pd.Series) -> pd.Series:
    return clean_nav(nav).pct_change().dropna()


def volatility(nav: pd.Series) -> float:
    r = daily_returns(nav)
    return float(r.std(ddof=1) * np.sqrt(TRADING_DAYS)) if len(r) > 2 else float("nan")


def sharpe(nav: pd.Series, rf: float = DEFAULT_RF) -> float:
    vol = volatility(nav)
    g = cagr(nav)
    if np.isnan(vol) or np.isnan(g) or vol < 1e-8:  # ~zero volatility: ratio undefined
        return float("nan")
    return float((g - rf) / vol)


def max_drawdown(nav: pd.Series) -> float:
    """Largest peak-to-trough fall as a negative fraction (e.g. -0.34)."""
    nav = clean_nav(nav)
    if nav.empty:
        return float("nan")
    return float((nav / nav.cummax() - 1).min())


def drawdown_series(nav: pd.Series) -> pd.Series:
    nav = clean_nav(nav)
    return nav / nav.cummax() - 1


def beta(nav: pd.Series, benchmark_nav: pd.Series) -> float:
    """Beta vs a benchmark, using returns on overlapping dates only."""
    r = pd.concat([daily_returns(nav), daily_returns(benchmark_nav)], axis=1, join="inner").dropna()
    if len(r) < 30:
        return float("nan")
    var_b = r.iloc[:, 1].var(ddof=1)
    if var_b == 0:
        return float("nan")
    return float(r.iloc[:, 0].cov(r.iloc[:, 1]) / var_b)


def rolling_returns(nav: pd.Series, window_years: int = 3) -> pd.Series:
    """Annualised rolling return over `window_years`, evaluated each day.

    Uses calendar-date lookback (as-of) so gaps in NAV dates do not distort results.
    """
    nav = clean_nav(nav)
    if nav.empty:
        return pd.Series(dtype=float)
    start_ok = nav.index[0] + pd.DateOffset(years=window_years)
    idx = nav.index[nav.index >= start_ok]
    if len(idx) == 0:
        return pd.Series(dtype=float)
    past_dates = (idx - pd.DateOffset(years=window_years)).to_numpy()
    # As-of lookup: last NAV on or before each lookback date (robust to gaps and leap days).
    pos = np.searchsorted(nav.index.to_numpy(), past_dates, side="right") - 1
    past_vals = nav.to_numpy()[pos]
    out = (nav.loc[idx].to_numpy() / past_vals) ** (1 / window_years) - 1
    return pd.Series(out, index=idx, name=f"{window_years}Y rolling")


def rolling_summary(nav: pd.Series, window_years: int = 3) -> dict[str, float]:
    rr = rolling_returns(nav, window_years)
    if rr.empty:
        return {"min": float("nan"), "median": float("nan"), "max": float("nan"), "pct_negative": float("nan")}
    return {"min": float(rr.min()), "median": float(rr.median()), "max": float(rr.max()),
            "pct_negative": float((rr < 0).mean())}


def compare_funds(navs: dict[str, pd.Series], benchmark: pd.Series | None = None,
                  years: float | None = 3, rf: float = DEFAULT_RF,
                  metadata: dict[str, dict] | None = None) -> pd.DataFrame:
    """One row per fund, all metrics computed on the SAME evaluation window.

    metadata: optional {fund_name: {"expense_ratio": float, "category": str,
              "top10_concentration": float, ...}} supplied from factsheets.
    """
    if not navs:
        return pd.DataFrame()
    # Common window: end at the earliest last date so every fund is compared like-for-like.
    cleaned = {k: clean_nav(v) for k, v in navs.items()}
    end = min(s.index[-1] for s in cleaned.values() if len(s))
    rows = []
    for name, s in cleaned.items():
        s = s[s.index <= end]
        w = slice_period(s, years)
        bw = None
        if benchmark is not None:
            b = clean_nav(benchmark)
            bw = b[(b.index >= w.index[0]) & (b.index <= end)] if len(w) else None
        enough = len(w) > 30 and (years is None or (w.index[-1] - w.index[0]).days >= 0.9 * 365.25 * years)
        meta = (metadata or {}).get(name, {})
        rows.append({
            "Fund": name,
            "Category": meta.get("category", ""),
            "Start": w.index[0].date() if len(w) else None,
            "End": w.index[-1].date() if len(w) else None,
            "Observations": len(w),
            "Full window?": bool(enough),
            "CAGR": cagr(w),
            "Volatility": volatility(w),
            "Sharpe": sharpe(w, rf),
            "Max drawdown": max_drawdown(w),
            "Beta": beta(w, bw) if bw is not None else float("nan"),
            "Expense ratio": meta.get("expense_ratio", float("nan")),
            "Top-10 holdings %": meta.get("top10_concentration", float("nan")),
        })
    return pd.DataFrame(rows).set_index("Fund")


def category_warning(metadata: dict[str, dict] | None, names: list[str]) -> str | None:
    """Warn if compared funds are not in the same category."""
    cats = {(metadata or {}).get(n, {}).get("category", "") for n in names}
    cats.discard("")
    if len(cats) > 1:
        return "Funds are from different categories, so risk and return are not directly comparable."
    return None
