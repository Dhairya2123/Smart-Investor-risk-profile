"""Within-category fund scorecard: market-derived metrics (from NAVs) plus factsheet fundamentals (entered by the user).

How it works
  * Each metric is converted to a percentile rank WITHIN the funds being compared (best = 100, worst = 0).
  * Metrics are grouped into four themes; a theme score is the mean of its available metrics.
  * The overall score is the weighted mean of the themes that have data (weights renormalised); coverage shows how much was available.
  * Technical trend is shown separately as context and is NOT part of the score.

It is a research aid for comparing funds of the SAME category and plan type. It is not a recommendation: a high score means
'ranked well on these metrics against these peers over this history', nothing more. With few funds, ranks swing widely.
"""
from __future__ import annotations

import io

import numpy as np
import pandas as pd

from . import fund_analytics as fa
from .dry_periods import dry_profile, dry_spell_summary
from .technicals import trend_snapshot

# metric key -> (theme, +1 higher is better / -1 lower is better, label)
METRICS: dict[str, tuple[str, int, str]] = {
    "median_roll3y": ("returns", +1, "Median 3Y rolling return"),
    "pct_3y_below_inflation": ("returns", -1, "% of 3Y windows below inflation"),
    "pct_1y_lagging": ("returns", -1, "% of 1Y windows lagging benchmark"),
    "sharpe": ("risk", +1, "Sharpe ratio"),
    "max_drawdown": ("risk", +1, "Max drawdown (less negative is better)"),
    "longest_underwater_years": ("risk", -1, "Longest wait for a new high (yrs)"),
    "pct_time_down_10": ("risk", -1, "% of time >10% below peak"),
    "volatility": ("risk", -1, "Volatility"),
    "expense_ratio": ("cost", -1, "Expense ratio"),
    "turnover": ("cost", -1, "Portfolio turnover"),
    "top10_concentration": ("cost", -1, "Top-10 holdings concentration"),
    "roe": ("quality", +1, "Portfolio ROE"),
    "pe_ratio": ("quality", -1, "Portfolio P/E"),
    "pb_ratio": ("quality", -1, "Portfolio P/B"),
    "manager_tenure_years": ("quality", +1, "Fund-manager tenure (yrs)"),
    "ytm": ("quality", +1, "Yield to maturity (debt)"),
    "mod_duration": ("quality", -1, "Modified duration (debt)"),
    "aaa_share": ("quality", +1, "Share in AAA / sovereign (debt)"),
}
THEMES = {"returns": "Return consistency", "risk": "Risk & dry periods", "cost": "Cost & structure", "quality": "Portfolio quality"}
DEFAULT_WEIGHTS = {"returns": 0.30, "risk": 0.30, "cost": 0.20, "quality": 0.20}
FACTSHEET_COLUMNS = ["fund", "category", "expense_ratio", "aum_cr", "manager_tenure_years", "top10_concentration", "pe_ratio",
                     "pb_ratio", "roe", "turnover", "ytm", "mod_duration", "aaa_share"]
MIN_AUM_CR = 500.0   # below this, a flag (not a score input) is shown

FACTSHEET_TEMPLATE = (
    "fund,category,expense_ratio,aum_cr,manager_tenure_years,top10_concentration,pe_ratio,pb_ratio,roe,turnover,ytm,mod_duration,aaa_share\n"
    "Fund name exactly as loaded,Large Cap,0.0070,12000,6.5,0.52,23.1,3.4,0.16,0.35,,,\n"
    "# fractions: 0.0070 = 0.70%, 0.52 = 52%; leave debt columns blank for equity funds and vice versa. Delete this comment row.,,,,,,,,,,,,\n"
)


def nav_metrics(nav: pd.Series, benchmark: pd.Series | None = None, inflation: float = 0.06, rf: float = fa.DEFAULT_RF) -> dict:
    """Market-derived metrics for one fund over its own full history."""
    p = dry_profile(nav, benchmark, inflation, min_depth=0.10)
    rr = fa.rolling_returns(nav, 3)
    return {
        "median_roll3y": float(rr.median()) if len(rr) else float("nan"),
        "pct_3y_below_inflation": p["pct_3y_below_inflation"], "pct_1y_lagging": p.get("pct_1y_lagging", float("nan")),
        "sharpe": fa.sharpe(nav, rf), "max_drawdown": p["max_drawdown"],
        "longest_underwater_years": p["longest_underwater_years"], "pct_time_down_10": p["pct_time_down_10"],
        "volatility": fa.volatility(nav), "history_years": p["history_years"], "cagr": p["cagr"],
        "still_underwater": p["still_underwater"], "current_drawdown": p["current_drawdown"],
    }


def percentile_scores(values: pd.Series, direction: int) -> pd.Series:
    """0-100 rank within the group (100 = best). Ties share the average rank. NaN stays NaN. Needs >= 2 non-null values."""
    v = values.astype(float)
    n = v.notna().sum()
    if n < 2:
        return pd.Series(np.nan, index=v.index)
    r = v.rank(method="average", ascending=(direction > 0))   # higher is better -> ascending rank gives best the top rank
    return ((r - 1) / (n - 1) * 100).where(v.notna())


def build_table(navs: dict[str, pd.Series], factsheet: pd.DataFrame | None = None, benchmark: pd.Series | None = None,
                inflation: float = 0.06, rf: float = fa.DEFAULT_RF) -> pd.DataFrame:
    """Raw metric table (one row per fund): NAV-derived metrics joined with factsheet inputs."""
    rows = {name: nav_metrics(s, benchmark, inflation, rf) for name, s in navs.items()}
    df = pd.DataFrame.from_dict(rows, orient="index")
    df.index.name = "fund"
    if factsheet is not None and not factsheet.empty:
        fs = factsheet.copy()
        fs.columns = [c.strip().lower() for c in fs.columns]
        fs = fs[fs["fund"].isin(df.index)].drop_duplicates("fund").set_index("fund")
        for c in FACTSHEET_COLUMNS[1:]:
            if c in fs.columns and c not in df.columns:
                df[c] = pd.to_numeric(fs[c], errors="coerce") if c != "category" else fs[c]
    for k in METRICS:
        if k not in df.columns:
            df[k] = np.nan
    return df


def score_funds(table: pd.DataFrame, weights: dict[str, float] | None = None) -> pd.DataFrame:
    """Theme scores, overall score (0-100), data coverage and rank. Needs at least two funds."""
    if len(table) < 2:
        raise ValueError("Compare at least two funds of the same category to score them.")
    w = {**DEFAULT_WEIGHTS, **(weights or {})}
    if any(v < 0 for v in w.values()) or sum(w.values()) <= 0:
        raise ValueError("Weights must be non-negative and not all zero.")
    pct = pd.DataFrame({k: percentile_scores(table[k], d) for k, (_, d, _) in METRICS.items()}, index=table.index)
    out = pd.DataFrame(index=table.index)
    for theme, label in THEMES.items():
        keys = [k for k, (t, _, _) in METRICS.items() if t == theme]
        out[label] = pct[keys].mean(axis=1, skipna=True)
    wt = pd.Series({THEMES[t]: w[t] for t in THEMES})
    avail = out.notna()
    out["Overall score"] = (out[list(THEMES.values())].fillna(0) * wt).sum(axis=1) / (avail * wt).sum(axis=1).replace(0, np.nan)
    present = pd.DataFrame({k: table[k].notna() for k in METRICS}).sum(axis=1)
    out["Data coverage"] = present / len(METRICS)
    out["Rank"] = out["Overall score"].rank(ascending=False, method="min")
    return out.sort_values("Rank")


def flags(table: pd.DataFrame) -> dict[str, list[str]]:
    """Caveats per fund: short history, still below a peak, missing cost data, small AUM."""
    out: dict[str, list[str]] = {}
    for name, r in table.iterrows():
        f = []
        if pd.notna(r.get("history_years")) and r["history_years"] < 3:
            f.append("under 3 years of history (rolling metrics unavailable)")
        elif pd.notna(r.get("history_years")) and r["history_years"] < 5:
            f.append("under 5 years of history")
        if r.get("still_underwater") is True and pd.notna(r.get("current_drawdown")) and r["current_drawdown"] < -0.10:
            f.append(f"currently {r['current_drawdown']:.0%} below its peak")
        if pd.isna(r.get("expense_ratio")):
            f.append("expense ratio not entered")
        if pd.notna(r.get("aum_cr")) and r["aum_cr"] < MIN_AUM_CR:
            f.append(f"small fund (AUM below Rs {MIN_AUM_CR:,.0f} crore)")
        if f:
            out[name] = f
    return out


def trend_context(navs: dict[str, pd.Series]) -> pd.Series:
    return pd.Series({k: trend_snapshot(v)["trend"] for k, v in navs.items()}, name="Trend (context, not scored)")


def parse_factsheet_csv(buffer) -> pd.DataFrame:
    """Load a factsheet CSV; drops comment rows (starting with '#') and normalises column names."""
    text = buffer.read() if hasattr(buffer, "read") else open(buffer).read()
    if isinstance(text, bytes):
        text = text.decode("utf-8", errors="replace")
    lines = [ln for ln in text.splitlines() if ln.strip() and not ln.lstrip().startswith("#")]
    df = pd.read_csv(io.StringIO("\n".join(lines)))
    df.columns = [c.strip().lower() for c in df.columns]
    if "fund" not in df.columns:
        raise ValueError("Factsheet CSV needs a 'fund' column.")
    return df
