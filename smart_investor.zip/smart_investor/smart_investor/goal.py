"""Goal feasibility: can the stated goal be reached, and what could close a gap?

Uses target amount (inflation-adjusted when the goal rises with inflation), current investment, monthly
contribution, time horizon and the illustrative portfolio return. Output is educational, not a forecast.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .allocation import Allocation, DEFAULT_ASSUMPTIONS, portfolio_stats, project_goal
from .risk_engine import RiskResult, future_value


@dataclass
class GoalFeasibility:
    feasible: bool                    # base-case projection reaches the effective target
    label: str                        # "Feasible" | "Needs adjustment"
    target: float                     # effective (future-rupee) target
    today_target: float
    base_value: float
    pessimistic_value: float
    optimistic_value: float
    shortfall: float                  # max(0, target - base_value)
    assumed_return: float
    required_return: float | None
    needed_monthly: float | None      # monthly contribution that reaches the target at the assumed return
    extra_monthly: float | None
    needed_years: float | None        # horizon that reaches the target at the current contribution
    achievable_today_value: float     # base-case value expressed in today's money
    levers: list[str] = field(default_factory=list)


def needed_monthly(pv: float, years: float, rate: float, target: float) -> float:
    """Monthly contribution needed to reach `target` (0 if already reached by the lump sum alone)."""
    n = int(round(years * 12))
    r = (1 + rate) ** (1 / 12) - 1
    grown = pv * (1 + r) ** n
    if grown >= target:
        return 0.0
    annuity = n if abs(r) < 1e-12 else ((1 + r) ** n - 1) / r
    return (target - grown) / annuity if annuity > 0 else float("inf")


def needed_years(pv: float, monthly: float, rate: float, target: float, max_years: float = 50.0) -> float | None:
    for months in range(1, int(max_years * 12) + 1):
        if future_value(pv, monthly, rate, months / 12) >= target:
            return months / 12
    return None


def _inr(x: float) -> str:
    return f"₹{x:,.0f}"


def assess_goal(risk: RiskResult, alloc: Allocation, assumptions: dict | None = None,
                shortfall_preference: str | None = None) -> GoalFeasibility:
    g = risk.goal
    ass = assumptions or DEFAULT_ASSUMPTIONS
    ret, _ = portfolio_stats(alloc, ass)
    proj = project_goal(alloc, g.current_investments, g.monthly_contribution, g.horizon_years, ass)
    target = g.effective_target
    feasible = proj["base"] >= target
    infl = (1 + g.inflation_rate) ** g.horizon_years if g.inflation_linked else 1.0

    nm = needed_monthly(g.current_investments, g.horizon_years, ret, target)
    ny = needed_years(g.current_investments, g.monthly_contribution, ret, target)
    f = GoalFeasibility(
        feasible=feasible, label="Feasible" if feasible else "Needs adjustment", target=target, today_target=g.goal_amount,
        base_value=proj["base"], pessimistic_value=proj["pessimistic"], optimistic_value=proj["optimistic"],
        shortfall=max(0.0, target - proj["base"]), assumed_return=ret, required_return=risk.required_return,
        needed_monthly=nm, extra_monthly=max(0.0, nm - g.monthly_contribution), needed_years=ny,
        achievable_today_value=proj["base"] / infl)

    if not feasible:
        levers = {
            "Increase monthly contributions": (f"Increase contributions: about {_inr(nm)} a month (vs {_inr(g.monthly_contribution)} now) "
                                               f"would reach the target at the assumed {ret:.1%} return."),
            "Extend the investment period": (f"Extend the period: about {ny:.1f} years (vs {g.horizon_years:g}) at your current contribution."
                                             if ny else "Extending the period alone does not reach the target within 50 years."),
            "Reduce or revise the target amount": (f"Revise the target: the base case supports about {_inr(f.achievable_today_value)} "
                                                   f"in today's money (vs {_inr(g.goal_amount)})."),
            "Review whether a different risk level is appropriate": (f"Review risk: moving to a higher-risk portfolio is NOT automatic, because "
                                                                     f"your profile is limited by {'capacity' if risk.capacity <= risk.tolerance else 'tolerance'}. "
                                                                     "Raise capacity first (emergency fund, lower debt, longer horizon)."),
            "Reconsider the goal": "Reconsider the goal: a smaller, later or phased goal can reduce the pressure on returns.",
        }
        order = list(levers)
        if shortfall_preference in levers:
            order.remove(shortfall_preference)
            order.insert(0, shortfall_preference)
        f.levers = [levers[k] for k in order]
    return f
