import pytest

from smart_investor.questionnaire import (ALL_QUESTIONS, CAPACITY_QUESTIONS, QUESTIONS_BY_KEY, SECTIONS, TOLERANCE_QUESTIONS,
                                          GoalInputs, InvestorInputs, ValidationError, missing_questions, validate)
from smart_investor.samples import PERSONAS_FULL, uniform_answers, with_overrides


def test_has_all_53_questions_in_order():
    assert [q.num for q in ALL_QUESTIONS] == list(range(1, 54))
    assert len({q.key for q in ALL_QUESTIONS}) == 53
    assert set(q.section for q in ALL_QUESTIONS) == set(SECTIONS)


def test_scored_questions_are_in_expected_sections():
    assert {q.section for q in TOLERANCE_QUESTIONS} <= {3, 6}
    assert len(CAPACITY_QUESTIONS) >= 15 and len(TOLERANCE_QUESTIONS) >= 9


def test_option_scores_within_range_and_options_present():
    for q in ALL_QUESTIONS:
        if q.kind in ("single", "multi") and q.dimension != "context":
            assert len(q.options) >= 2, q.key
        for s in q.options.values():
            assert s is None or 0 <= s <= 100 or q.scorer == "pressure", q.key


def test_context_questions_are_never_scored():
    # age, employment, lifestyle style and housing must not feed risk scores (questionnaire safety notes)
    for key in ("age", "employment", "income_band", "lifestyle_priority", "housing", "past_loss", "objectives"):
        assert not QUESTIONS_BY_KEY[key].scored, key


def test_uniform_answers_validate():
    for mode in ("min", "mid", "max"):
        validate(InvestorInputs(uniform_answers(mode)))


def test_missing_questions_reports_unanswered():
    a = uniform_answers("mid")
    a["emergency_fund"] = None
    a["goal_amount"] = None
    miss = {q.key for q in missing_questions(InvestorInputs(a))}
    assert miss == {"emergency_fund", "goal_amount"}
    with pytest.raises(ValidationError, match="Q28"):
        validate(InvestorInputs(a))


def test_optional_questions_may_be_blank():
    a = uniform_answers("mid")
    a["essential_expenses"] = None
    a["products_used"] = []
    assert not missing_questions(InvestorInputs(a))


def test_validation_errors():
    good = uniform_answers("mid")
    with pytest.raises(ValidationError):
        validate(InvestorInputs(with_overrides(good, goal_amount=-5)))
    with pytest.raises(ValidationError, match="Q38"):
        validate(InvestorInputs(with_overrides(good, goal_amount=0)))
    with pytest.raises(ValidationError):
        validate(InvestorInputs(with_overrides(good, invested=0, monthly_contribution=0)))
    with pytest.raises(ValidationError, match="Q13"):
        validate(InvestorInputs(with_overrides(good, life_events=["Buying a home", "No major change expected"])))
    bad = dict(good, debt_burden="nonsense")
    with pytest.raises(ValidationError):
        validate(InvestorInputs(bad))
    with pytest.raises(ValidationError):
        validate(InvestorInputs(good, goal_horizon_override=100))
    with pytest.raises(ValidationError):
        validate(InvestorInputs(good, inflation_rate=0.5))


def test_goal_effective_target_inflation():
    g = GoalInputs(1_000_000, 0, 10_000, 10, inflation_linked=True, inflation_rate=0.06)
    assert g.effective_target == pytest.approx(1_000_000 * 1.06 ** 10)
    assert GoalInputs(1_000_000, 0, 10_000, 10).effective_target == 1_000_000


def test_goal_horizon_override_and_inflation_flag():
    a = with_overrides(uniform_answers("mid"), goal_inflation="Fixed amount")
    g = InvestorInputs(a, goal_horizon_override=6.5).goal
    assert g.horizon_years == 6.5 and not g.inflation_linked
    assert InvestorInputs(with_overrides(a, goal_inflation="Not sure")).goal.inflation_linked  # conservative default


def test_personas_are_complete():
    for name, ans in PERSONAS_FULL.items():
        assert not missing_questions(InvestorInputs(ans)), name
