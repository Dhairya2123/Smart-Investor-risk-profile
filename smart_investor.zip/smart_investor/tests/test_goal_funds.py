import pytest

from smart_investor.allocation import allocation_for
from smart_investor.crash import GoalImpact, comfort_warning, goal_impact
from smart_investor.funds_catalog import (CATEGORIES, HYBRID_ALTERNATIVES, PROFILE_MIX, VERIFY_NOTE, hybrid_alternatives,
                                          profile_matrix, shortlist)
from smart_investor.goal import assess_goal, needed_monthly, needed_years
from smart_investor.questionnaire import InvestorInputs
from smart_investor.risk_engine import PROFILES, assess, future_value
from smart_investor.samples import PERSONAS_FULL, uniform_answers, with_overrides


def risk_for(**ov):
    return assess(InvestorInputs(with_overrides(uniform_answers("mid"), **ov)))


# ------------------------------------------------------------------ goal feasibility
def test_needed_monthly_hits_target():
    m = needed_monthly(100_000, 10, 0.10, 3_000_000)
    assert future_value(100_000, m, 0.10, 10) == pytest.approx(3_000_000, rel=1e-4)


def test_needed_monthly_zero_when_lump_sum_enough():
    assert needed_monthly(1_000_000, 10, 0.10, 1_500_000) == 0.0


def test_needed_years_and_unreachable():
    y = needed_years(100_000, 10_000, 0.10, 3_000_000)
    assert future_value(100_000, 10_000, 0.10, y) >= 3_000_000 > future_value(100_000, 10_000, 0.10, y - 1 / 12)
    assert needed_years(1_000, 10, 0.05, 10 ** 12) is None


def test_feasible_goal_has_no_levers():
    r = risk_for(goal_amount=800_000.0)
    f = assess_goal(r, allocation_for(r.profile, r.liquidity_horizon))
    assert f.feasible and f.label == "Feasible" and f.levers == [] and f.shortfall == 0


def test_infeasible_goal_needs_adjustment_with_preferred_lever_first():
    r = risk_for(goal_amount=6_000_000.0, shortfall_preference="Extend the investment period")
    f = assess_goal(r, allocation_for(r.profile, r.liquidity_horizon), shortfall_preference="Extend the investment period")
    assert not f.feasible and f.label == "Needs adjustment" and f.shortfall > 0
    assert len(f.levers) == 5 and f.levers[0].startswith("Extend the period")
    assert f.needed_monthly > r.goal.monthly_contribution and f.extra_monthly > 0


def test_risk_lever_does_not_push_for_more_risk():
    r = risk_for(goal_amount=6_000_000.0)
    f = assess_goal(r, allocation_for(r.profile, r.liquidity_horizon),
                    shortfall_preference="Review whether a different risk level is appropriate")
    assert "NOT automatic" in f.levers[0]


def test_inflation_linked_target_is_higher():
    fixed = assess_goal(risk_for(goal_inflation="Fixed amount"), allocation_for("Moderate", 7.5))
    linked = assess_goal(risk_for(goal_inflation="Expected to rise with inflation"), allocation_for("Moderate", 7.5))
    assert linked.target > fixed.target and linked.achievable_today_value < linked.base_value


def test_scenarios_ordered():
    r = risk_for()
    f = assess_goal(r, allocation_for(r.profile, 7.5))
    assert f.pessimistic_value < f.base_value < f.optimistic_value


# ------------------------------------------------------------------ crash impact on goal
def test_goal_impact_no_shock_equals_baseline():
    a = allocation_for("Moderate", 10)
    g = goal_impact(500_000, 20_000, 10, a, 0.0, 3, 5_000_000)
    assert g.value_lost == pytest.approx(0, abs=1e-6) and g.value_with_shock == pytest.approx(g.value_no_shock)


def test_goal_impact_larger_shock_loses_more_and_can_break_goal():
    a = allocation_for("Aggressive", 10)
    base = goal_impact(500_000, 20_000, 10, a, 0.0, 0, 1)
    target = base.value_no_shock * 0.99                 # just reachable without a shock
    mild = goal_impact(500_000, 20_000, 10, a, 0.10, 5, target)
    severe = goal_impact(500_000, 20_000, 10, a, 0.40, 5, target)
    assert severe.value_lost > mild.value_lost > 0
    assert severe.value_with_shock < mild.value_with_shock
    assert severe.met_no_shock and not severe.met_with_shock and severe.shortfall_with_shock > 0


def test_goal_impact_timing_extremes_and_validation():
    a = allocation_for("Moderate", 10)
    end = goal_impact(500_000, 20_000, 10, a, 0.3, 10, 1)       # shock at the very end
    assert end.value_with_shock == pytest.approx(end.value_no_shock * (1 - end.loss_pct))
    now = goal_impact(500_000, 20_000, 10, a, 0.3, 0, 1)
    assert now.value_lost < end.value_lost                       # early shock has time to recover
    with pytest.raises(ValueError):
        goal_impact(1, 1, 0, a, 0.1, 0, 1)


def test_comfort_warning_uses_stated_tolerable_decline():
    assert comfort_warning(0.15, 0.075) is not None
    assert comfort_warning(0.05, 0.075) is None


# ------------------------------------------------------------------ fund categories
def test_mix_shares_sum_to_one_and_categories_exist():
    for p, sleeves in PROFILE_MIX.items():
        assert set(sleeves) == {"equity", "debt", "cash"}
        for s, items in sleeves.items():
            assert sum(sh for _, sh in items) == pytest.approx(1.0), (p, s)
            assert all(k in CATEGORIES for k, _ in items)
    assert set(PROFILE_MIX) == set(PROFILES) == set(HYBRID_ALTERNATIVES)


@pytest.mark.parametrize("profile", PROFILES)
def test_shortlist_weights_sum_to_one_and_match_sleeves(profile):
    a = allocation_for(profile, 12)
    df = shortlist(profile, a)
    assert df["Portfolio weight"].sum() == pytest.approx(1.0)
    by = df.groupby("Sleeve")["Portfolio weight"].sum()
    assert by["Equity"] == pytest.approx(a.equity) and by["Debt"] == pytest.approx(a.debt) and by["Cash"] == pytest.approx(a.cash)
    assert (df["Example schemes to research"].str.len() > 0).all()
    assert len(hybrid_alternatives(profile)) >= 1


def test_riskier_profiles_hold_riskier_categories():
    low = shortlist("Conservative", allocation_for("Conservative", 12))["Category"].tolist()
    high = shortlist("Aggressive", allocation_for("Aggressive", 12))["Category"].tolist()
    assert not any("Small Cap" in c or "Mid Cap" in c for c in low)
    assert any("Small Cap" in c for c in high) and any("Mid Cap" in c for c in high)


def test_conservative_has_more_debt_and_cash_than_aggressive():
    c = shortlist("Conservative", allocation_for("Conservative", 12)).groupby("Sleeve")["Portfolio weight"].sum()
    g = shortlist("Aggressive", allocation_for("Aggressive", 12)).groupby("Sleeve")["Portfolio weight"].sum()
    assert c["Equity"] < g["Equity"] and c["Debt"] + c["Cash"] > g["Debt"] + g["Cash"]


def test_short_horizon_pushes_weight_out_of_equity_categories():
    short = shortlist("Aggressive", allocation_for("Aggressive", 2)).groupby("Sleeve")["Portfolio weight"].sum()
    assert short["Equity"] <= 0.30 + 1e-9


def test_unknown_profile_and_matrix_and_disclaimer():
    with pytest.raises(ValueError):
        shortlist("Reckless", allocation_for("Moderate", 5))
    assert len(profile_matrix()) == 5
    assert "not recommendations" in VERIFY_NOTE.lower() and "verify" in VERIFY_NOTE.lower()
