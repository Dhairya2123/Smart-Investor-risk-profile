from smart_investor.allocation import allocation_for
from smart_investor.crash import crash_table, goal_impact
from smart_investor.data_loader import sample_universe
from smart_investor.fund_analytics import compare_funds
from smart_investor.funds_catalog import shortlist
from smart_investor.goal import assess_goal
from smart_investor.questionnaire import InvestorInputs
from smart_investor.report import DISCLAIMER, build_report
from smart_investor.risk_engine import assess
from smart_investor.samples import PERSONAS_FULL


def make_report(persona="Mid-career family, balanced", with_funds=True):
    risk = assess(InvestorInputs(PERSONAS_FULL[persona]))
    a = allocation_for(risk.profile, risk.liquidity_horizon)
    feas = assess_goal(risk, a)
    g = risk.goal
    impacts = [goal_impact(g.current_investments, g.monthly_contribution, g.horizon_years, a, 0.2, t, feas.target)
               for t in (0, g.horizon_years / 2)]
    table = None
    if with_funds:
        navs, bench, meta = sample_universe(end="2026-11-20")
        table = compare_funds(navs, bench, 3, metadata=meta)
    return risk, build_report(risk, a, feas, crash_table(500_000, a), impacts, "illustrative assumptions",
                              shortlist(risk.profile, a), table, "SYNTHETIC demo data", "REF-001")


def test_report_has_section8_rows_rule_and_disclaimer():
    risk, md = make_report()
    for text in ("Section 8", "Risk Tolerance", "Risk Capacity", "Risk Required", "Overall Risk Profile", "Goal Feasibility",
                 "Risk Mismatch", risk.profile, "LOWER", "Fund categories to research", "Hypothetical downside",
                 "Estimated impact on your goal", "Data source, assumptions and limitations", "SYNTHETIC", "REF-001",
                 DISCLAIMER, "not forecasts"):
        assert text in md, text
    assert "Calculation date" in md


def test_report_lists_warnings_for_fragile_persona_and_marks_provisional_when_needed():
    _, md = make_report("Brave but financially fragile", with_funds=False)
    assert "## Warnings" in md and "emergency fund" in md.lower()
    risk = assess(InvestorInputs(dict(PERSONAS_FULL["Mid-career family, balanced"], accepts_risk_return="No, I need an explanation")))
    assert risk.provisional


def test_report_has_no_buy_instructions():
    _, md = make_report()
    lowered = md.lower()
    assert "you should buy" not in lowered and "we recommend buying" not in lowered
    assert "not recommendations" in lowered or "not a recommendation" in lowered or "does not recommend" in lowered
