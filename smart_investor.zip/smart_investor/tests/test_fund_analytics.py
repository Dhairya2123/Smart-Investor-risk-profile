import numpy as np
import pandas as pd
import pytest

from smart_investor import fund_analytics as fa
from smart_investor.data_loader import load_csv_nav, sample_universe


def nav_series(values, start="2020-01-01", freq="B"):
    return pd.Series(values, index=pd.bdate_range(start, periods=len(values), freq=freq))


def test_cagr_exact_doubling_in_one_year():
    idx = pd.to_datetime(["2020-01-01", "2021-01-01"])
    s = pd.Series([100.0, 200.0], index=idx)
    assert fa.cagr(s) == pytest.approx(2 ** (365.25 / 366) - 1, rel=1e-6)


def test_cagr_too_short_is_nan():
    assert np.isnan(fa.cagr(nav_series([100, 101, 102])))


def test_max_drawdown_known():
    s = nav_series([100, 120, 90, 110, 130, 65])
    assert fa.max_drawdown(s) == pytest.approx(65 / 130 - 1)


def test_max_drawdown_monotonic_rising_is_zero():
    assert fa.max_drawdown(nav_series([100, 101, 102, 103])) == 0


def test_volatility_zero_for_constant_growth():
    s = nav_series(100 * 1.001 ** np.arange(300))
    assert fa.volatility(s) == pytest.approx(0, abs=1e-9)
    assert np.isnan(fa.sharpe(s))  # zero vol -> undefined, not infinity


def test_volatility_matches_manual():
    rng = np.random.default_rng(0)
    s = nav_series(100 * np.cumprod(1 + rng.normal(0.0004, 0.01, 500)))
    manual = s.pct_change().dropna().std(ddof=1) * np.sqrt(252)
    assert fa.volatility(s) == pytest.approx(manual)


def test_beta_of_benchmark_with_itself_is_one():
    rng = np.random.default_rng(1)
    b = nav_series(100 * np.cumprod(1 + rng.normal(0, 0.01, 400)))
    assert fa.beta(b, b) == pytest.approx(1.0)


def test_beta_of_leveraged_series_is_two():
    rng = np.random.default_rng(2)
    r = rng.normal(0, 0.01, 400)
    b = nav_series(100 * np.cumprod(1 + r))
    f = nav_series(100 * np.cumprod(1 + 2 * r))
    assert fa.beta(f, b) == pytest.approx(2.0, rel=1e-6)


def test_beta_insufficient_overlap_is_nan():
    assert np.isnan(fa.beta(nav_series([100, 101, 102]), nav_series([100, 101, 103])))


def test_clean_nav_handles_dupes_unsorted_and_bad_values():
    idx = pd.to_datetime(["2020-01-03", "2020-01-01", "2020-01-02", "2020-01-02", "2020-01-04"])
    s = pd.Series([102, 100, 101, 101, -5], index=idx)
    c = fa.clean_nav(s)
    assert c.index.is_monotonic_increasing and c.index.is_unique
    assert (c > 0).all() and len(c) == 3


def test_rolling_returns_constant_growth():
    # Constant daily growth => every rolling annualised return is (1+g)^(days/yr)-1 and nearly constant
    s = nav_series(100 * 1.0004 ** np.arange(1500))
    rr = fa.rolling_returns(s, 3)
    assert len(rr) > 0
    assert rr.std() < 0.005
    assert rr.min() > 0


def test_rolling_returns_short_history_empty():
    assert fa.rolling_returns(nav_series(100 * 1.001 ** np.arange(200)), 3).empty
    assert np.isnan(fa.rolling_summary(nav_series([100, 101]), 3)["median"])


def test_rolling_returns_no_duplicate_date_bug():
    # regression: leap-day lookbacks once produced mismatched array lengths
    navs, _, _ = sample_universe(end="2026-11-20")
    s = navs["Sample Mid Cap Fund D"]
    rr = fa.rolling_returns(s, 3)
    assert len(rr) == (s.index >= s.index[0] + pd.DateOffset(years=3)).sum()


def test_compare_funds_like_for_like_window():
    navs, bench, meta = sample_universe(end="2026-11-20")
    short = navs["Sample Large Cap Fund A"].iloc[:-10]  # fund with older last NAV date
    navs = {**navs, "Sample Large Cap Fund A": short}
    t = fa.compare_funds(navs, bench, years=3, metadata=meta)
    assert t["End"].nunique() == 1            # all evaluated to the same end date
    assert set(t.columns) >= {"CAGR", "Volatility", "Sharpe", "Max drawdown", "Beta", "Expense ratio"}
    assert (t["Max drawdown"] <= 0).all()
    assert t["Full window?"].all()


def test_compare_funds_flags_short_history():
    navs, bench, meta = sample_universe(end="2026-11-20")
    t = fa.compare_funds(navs, bench, years=10, metadata=meta)
    assert not t["Full window?"].any()


def test_category_warning():
    meta = {"A": {"category": "Large Cap"}, "B": {"category": "Mid Cap"}, "C": {"category": "Large Cap"}}
    assert fa.category_warning(meta, ["A", "B"]) is not None
    assert fa.category_warning(meta, ["A", "C"]) is None


def test_load_csv_nav(tmp_path):
    p = tmp_path / "f.csv"
    p.write_text("Date,NAV\n02-01-2024,100\n03-01-2024,101\n03-01-2024,101\n04-01-2024,abc\n")
    s = load_csv_nav(p)
    assert len(s) == 2 and s.iloc[0] == 100
    bad = tmp_path / "bad.csv"
    bad.write_text("x,y\n1,2\n")
    with pytest.raises(ValueError):
        load_csv_nav(bad)


def test_sample_data_is_labelled_synthetic():
    navs, _, _ = sample_universe()
    assert all(n.startswith("Sample") for n in navs)
