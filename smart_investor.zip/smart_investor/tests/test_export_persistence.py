import io
import zipfile

import pandas as pd
import pytest

from smart_investor import persistence as db
from smart_investor.allocation import allocation_for
from smart_investor.crash import crash_table
from smart_investor.data_loader import sample_universe
from smart_investor.export import build_bundle, fund_metrics_long, nav_long, rolling_long
from smart_investor.fund_analytics import compare_funds
from smart_investor.crash import goal_impact
from smart_investor.funds_catalog import shortlist
from smart_investor.goal import assess_goal
from smart_investor.questionnaire import InvestorInputs
from smart_investor.risk_engine import assess
from smart_investor.samples import PERSONAS_FULL


@pytest.fixture
def risk():
    return assess(InvestorInputs(PERSONAS_FULL["Mid-career family, balanced"]))


def test_bundle_contains_expected_csvs(risk):
    navs, bench, meta = sample_universe(end="2026-11-20")
    table = compare_funds(navs, bench, 3, metadata=meta)
    a = allocation_for(risk.profile, 10)
    feas = assess_goal(risk, a)
    impacts = [goal_impact(500_000, 20_000, 7.5, a, 0.2, 2, feas.target)]
    z = zipfile.ZipFile(io.BytesIO(build_bundle(risk, a, crash_table(500_000, a), table, navs, 3, 3, "SYNTHETIC",
                                                feas, impacts, shortlist(risk.profile, a))))
    names = set(z.namelist())
    assert {"assessment.csv", "warnings.csv", "allocation.csv", "crash_scenarios.csv", "goal_impact.csv", "fund_shortlist.csv",
            "fund_metrics.csv", "nav_history.csv", "rolling_returns.csv", "data_source.csv", "README.txt"} <= names
    ass = pd.read_csv(z.open("assessment.csv")).iloc[0]
    assert ass["overall_profile"] == risk.profile and ass["goal_feasibility"] == feas.label and ass["tolerance_level"] in ("Low", "Moderate", "High")
    sl = pd.read_csv(z.open("fund_shortlist.csv"))
    assert sl["Portfolio weight"].sum() == pytest.approx(1.0)
    nav = pd.read_csv(z.open("nav_history.csv"))
    assert set(nav.columns) == {"fund", "date", "nav", "growth_of_100", "drawdown"}
    assert nav.groupby("fund")["growth_of_100"].first().round(6).eq(100).all()
    assert (nav["drawdown"] <= 0).all()
    assert pd.read_csv(z.open("data_source.csv")).iloc[0, 0] == "SYNTHETIC"


def test_bundle_without_fund_data_still_valid(risk):
    a = allocation_for(risk.profile, 10)
    z = zipfile.ZipFile(io.BytesIO(build_bundle(risk, a, crash_table(100_000, a), None, None, 3, 3, "")))
    assert len(pd.read_csv(z.open("assessment.csv"))) == 1
    assert len(pd.read_csv(z.open("nav_history.csv"))) == 0
    assert "No fund data" in pd.read_csv(z.open("data_source.csv")).iloc[0, 0]


def test_fund_metrics_long_shape():
    navs, bench, meta = sample_universe(end="2026-11-20")
    t = compare_funds(navs, bench, 3, metadata=meta)
    long = fund_metrics_long(t)
    assert set(long.columns) == {"fund", "metric", "value"}
    assert "CAGR" in set(long["metric"]) and "Observations" not in set(long["metric"])
    assert set(long["fund"]) == set(navs)


def test_rolling_long_and_nav_long_empty_inputs():
    assert rolling_long({}).empty and nav_long({}).empty


def test_persistence_roundtrip(risk):
    conn = db.connect(":memory:")
    sid = db.new_session_id()
    db.save_run(conn, sid, risk, 0.6)
    db.save_run(conn, db.new_session_id(), risk, 0.4)
    mine = db.load_runs(conn, sid)
    assert len(mine) == 1 and mine.iloc[0]["profile"] == risk.profile
    assert len(db.load_runs(conn)) == 2
    assert "warning_count" in mine.columns
    db.delete_all(conn)
    assert db.load_runs(conn).empty


def test_persistence_stores_no_personal_fields():
    conn = db.connect(":memory:")
    cols = {r[1] for r in conn.execute("PRAGMA table_info(risk_assessment)")}
    assert not cols & {"name", "email", "phone", "pan", "aadhaar"}
