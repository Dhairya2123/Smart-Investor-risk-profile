import pytest

from smart_investor.allocation import (Allocation, EQUITY_BANDS, allocation_for, equity_cap_for_horizon,
                                       portfolio_stats, project_goal)
from smart_investor.crash import comfort_warning, portfolio_loss_pct, simulate_crash
from smart_investor.risk_engine import PROFILES


@pytest.mark.parametrize("profile", PROFILES)
@pytest.mark.parametrize("tilt", [0, 0.5, 1])
def test_allocation_sums_to_one_and_in_band(profile, tilt):
    a = allocation_for(profile, 10, tilt)
    assert a.equity + a.debt + a.cash == pytest.approx(1.0)
    lo, hi = EQUITY_BANDS[profile]
    assert lo - 1e-9 <= a.equity <= hi + 1e-9
    assert min(a.equity, a.debt, a.cash) >= 0


def test_horizon_caps_equity():
    a = allocation_for("Aggressive", 2, 1.0)
    assert a.equity <= equity_cap_for_horizon(2) == 0.30
    assert allocation_for("Aggressive", 2).debt > 0


def test_more_aggressive_profile_has_more_equity():
    eq = [allocation_for(p, 15).equity for p in PROFILES]
    assert eq == sorted(eq)


def test_bad_inputs():
    with pytest.raises(ValueError):
        allocation_for("Reckless", 5)
    with pytest.raises(ValueError):
        allocation_for("Moderate", 5, tilt=1.5)


def test_portfolio_stats_all_cash():
    ret, vol = portfolio_stats(Allocation(0, 0, 1))
    assert ret == pytest.approx(0.055)
    assert vol == pytest.approx(0.005)


def test_projection_ordering():
    p = project_goal(allocation_for("Moderate", 10), 100_000, 10_000, 10)
    assert p["pessimistic"] < p["base"] < p["optimistic"]


def test_crash_20pct_hand_check():
    # 60% equity, 35% debt, 5% cash; 20% equity fall => loss 12% of portfolio
    r = simulate_crash(1_000_000, Allocation(0.60, 0.35, 0.05), 0.20)
    assert r.end_value == pytest.approx(880_000)
    assert r.loss_amount == pytest.approx(120_000)
    assert r.loss_pct == pytest.approx(0.12)
    assert r.recovery_years > 0


def test_crash_all_equity_and_zero_equity():
    assert simulate_crash(100, Allocation(1, 0, 0), 0.2).loss_pct == pytest.approx(0.2)
    z = simulate_crash(100, Allocation(0, 0.9, 0.1), 0.2)
    assert z.loss_pct == 0 and z.recovery_years == 0.0


def test_crash_with_debt_shock():
    r = simulate_crash(100, Allocation(0.5, 0.5, 0), 0.2, debt_shock=0.04)
    assert r.loss_pct == pytest.approx(0.5 * 0.2 + 0.5 * 0.04)


def test_crash_validation():
    with pytest.raises(ValueError):
        simulate_crash(0, Allocation(1, 0, 0))
    with pytest.raises(ValueError):
        simulate_crash(100, Allocation(1, 0, 0), 1.5)


def test_comfort_warning_against_stated_tolerable_decline():
    assert comfort_warning(0.30, 0.025) is not None
    assert comfort_warning(0.01, 0.075) is None


def test_portfolio_loss_pct():
    assert portfolio_loss_pct(Allocation(0.6, 0.35, 0.05), 0.20) == pytest.approx(0.12)
