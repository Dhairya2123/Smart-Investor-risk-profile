import numpy as np
import pandas as pd
import pytest

from smart_investor import dry_periods as dp
from smart_investor import data_loader as dl
from smart_investor import scorecard as sc
from smart_investor import sector_analysis as sa
from smart_investor import technicals as tech
from smart_investor.report import build_report, scorecard_section, sector_section


def series(vals, start="2015-01-01", freq="D"):
    return pd.Series(vals, index=pd.date_range(start, periods=len(vals), freq=freq), dtype=float)


def test_single_episode_depth_and_recovery():
    s = series([100, 110, 100, 80, 55, 70, 100, 110, 120])
    ep = dp.drawdown_episodes(s, 0.05)
    assert len(ep) == 1
    r = ep.iloc[0]
    assert r["depth"] == pytest.approx(-0.5)            # 55 / 110 - 1
    assert r["peak_date"] == s.index[1] and r["trough_date"] == s.index[4] and r["recovery_date"] == s.index[7]
    assert r["days_to_trough"] == 3 and r["days_to_recover"] == 3 and r["underwater_days"] == 6
    assert not r["ongoing"]


def test_ongoing_episode_and_min_depth_filter():
    s = series([100, 120, 90, 95, 100])
    ep = dp.drawdown_episodes(s, 0.05)
    assert len(ep) == 1 and ep.iloc[0]["ongoing"] and pd.isna(ep.iloc[0]["recovery_date"])
    assert ep.iloc[0]["underwater_days"] == 3
    assert dp.drawdown_episodes(s, 0.30).empty


def test_no_episodes_for_rising_series():
    s = series(np.arange(100, 130))
    assert dp.drawdown_episodes(s).empty
    u = dp.underwater_summary(s)
    assert u["longest_underwater_years"] == 0 and u["max_drawdown"] == 0 and not u["still_underwater"]


def test_underwater_summary_fields():
    s = series([100, 110, 100, 80, 55, 70, 100, 110, 120])
    u = dp.underwater_summary(s)
    assert u["max_drawdown"] == pytest.approx(-0.5)
    assert u["episodes"] == 1 and not u["still_underwater"]
    assert u["pct_time_down_10"] == pytest.approx(3 / 9)   # 80, 55, 70 are >10% below 110... 100 is -9.1%


def test_spells_runs():
    flag = pd.Series([False, True, True, False, True], index=pd.date_range("2020-01-01", periods=5))
    vals = pd.Series([0, -1, -3, 0, -2.0], index=flag.index)
    sp = dp._spells(flag, vals)
    assert len(sp) == 2 and list(sp["days"]) == [1, 0] and list(sp["worst_value"]) == [-3, -2]


def test_dry_spells_flat_then_rising_series():
    idx = pd.bdate_range("2010-01-01", periods=252 * 5)
    flat = np.full(252 * 3, 100.0)
    up = 100 * 1.001 ** np.arange(1, 252 * 2 + 1)
    s = pd.Series(np.concatenate([flat, up]), index=idx)
    summ = dp.dry_spell_summary(s, 1, 0.05)
    assert summ["spells"] >= 1 and summ["pct_dry"] > 0 and summ["longest_years"] > 1
    assert not summ["currently_dry"]


def test_calendar_returns_exact():
    idx = pd.to_datetime(["2020-06-01", "2020-12-31", "2021-12-31", "2022-12-30"])
    cal = dp.calendar_returns({"x": pd.Series([90, 100, 120, 90.0], index=idx)})
    assert list(cal.index) == [2021, 2022]
    assert cal["x"].iloc[0] == pytest.approx(0.2) and cal["x"].iloc[1] == pytest.approx(-0.25)


def test_relative_dry_spells_vs_benchmark():
    idx = pd.bdate_range("2015-01-01", periods=252 * 4)
    bench = pd.Series(100 * 1.0004 ** np.arange(len(idx)), index=idx)
    lag = pd.Series(100 * 1.0001 ** np.arange(len(idx)), index=idx)
    assert dp.relative_summary(lag, bench, 1)["pct_lagging"] == pytest.approx(1.0)
    assert dp.relative_summary(bench, bench, 1)["pct_lagging"] == 0


def test_technicals():
    up = series(100 * 1.002 ** np.arange(300))
    snap = tech.trend_snapshot(up)
    assert snap["trend"] == "Uptrend" and snap["rsi14"] == pytest.approx(100)
    down = series(100 * 0.998 ** np.arange(300))
    assert tech.trend_snapshot(down)["trend"] == "Downtrend"
    assert tech.trend_snapshot(series([1, 2, 3]))["trend"] == "Insufficient data"
    assert tech.trend_label(True, False) == "Mixed" and tech.trend_label(None, True) == "Insufficient data"
    assert tech.sma(series([1, 2, 3, 4]), 2).iloc[-1] == 3.5


def test_dry_risk_label_thresholds():
    assert sa.dry_risk_label(6, 0.1) == "High" and sa.dry_risk_label(1, 0.6) == "High"
    assert sa.dry_risk_label(4, 0.1) == "Moderate" and sa.dry_risk_label(1, 0.35) == "Moderate"
    assert sa.dry_risk_label(1, 0.1) == "Low" and sa.dry_risk_label(float("nan"), 0.1) == "n/a"


def test_sample_sectors_have_dry_periods_and_labels():
    navs, bench, _ = dl.sample_sectors(end="2025-12-31")
    summ = sa.sector_summary(navs, bench)
    assert list(summ.columns) == sa.SUMMARY_COLUMNS and len(summ) == 6
    assert summ.loc["Sample Sector: FMCG", "Dry-period risk"] == "Low"
    assert summ.loc["Sample Sector: Metals", "Dry-period risk"] == "High"
    assert (summ["Max drawdown"] <= 0).all()
    cm = sa.correlation_matrix(navs)
    assert cm.shape == (6, 6) and np.allclose(np.diag(cm), 1)
    assert len(sa.rotation_summary(navs)) == 6


def test_horizon_warnings():
    summ = pd.DataFrame({"Longest underwater (yrs)": [6.0, 1.0], "Max drawdown": [-0.5, -0.1],
                         "Current drawdown": [-0.2, 0.0]}, index=["A", "B"])
    w = sa.horizon_warnings(summ, horizon_years=5, tolerable_decline=0.2)
    assert any("A" in x and "6.0 years" in x for x in w)
    assert any("A" in x and "-50%" in x for x in w)
    assert any("A" in x and "-20%" in x for x in w)
    assert not any(x.startswith("B") for x in w)


def test_percentile_scores_directions_and_ties():
    v = pd.Series([1.0, 2.0, 3.0], index=list("abc"))
    assert list(sc.percentile_scores(v, +1)) == [0, 50, 100]
    assert list(sc.percentile_scores(v, -1)) == [100, 50, 0]
    assert sc.percentile_scores(pd.Series([1.0, np.nan]), +1).isna().all()


def test_scorecard_ranking_weights_and_coverage():
    navs, bench, _ = dl.sample_universe(end="2025-12-31")
    names = [n for n in navs if "Large Cap" in n]
    tab = sc.build_table({n: navs[n] for n in names}, dl.sample_factsheet(names), bench)
    out = sc.score_funds(tab)
    assert set(out["Rank"]) == {1.0, 2.0} and out["Overall score"].between(0, 100).all()
    assert (out["Data coverage"] <= 1).all()
    cost_only = sc.score_funds(tab, {"returns": 0, "risk": 0, "cost": 1, "quality": 0})
    cheaper = tab["expense_ratio"].idxmin()
    assert cost_only.loc[cheaper, "Overall score"] > cost_only.drop(cheaper)["Overall score"].iloc[0] - 1e-9
    with pytest.raises(ValueError):
        sc.score_funds(tab.iloc[:1])
    with pytest.raises(ValueError):
        sc.score_funds(tab, {"returns": -1})


def test_scorecard_missing_fundamentals_renormalises():
    navs, bench, _ = dl.sample_universe(end="2025-12-31")
    names = list(navs)[:3]
    tab = sc.build_table({n: navs[n] for n in names}, None, bench)
    out = sc.score_funds(tab)
    assert out["Overall score"].notna().all()          # still scored from NAV-only themes
    assert "expense ratio not entered" in sc.flags(tab)[names[0]]


def test_factsheet_parser_drops_comments():
    import io
    f = io.StringIO(sc.FACTSHEET_TEMPLATE)
    df = sc.parse_factsheet_csv(f)
    assert list(df["fund"]) == ["Fund name exactly as loaded"]
    with pytest.raises(ValueError):
        sc.parse_factsheet_csv(io.StringIO("a,b\n1,2\n"))


def test_report_sections_render():
    navs, bench, _ = dl.sample_sectors(end="2025-12-31")
    summ = sa.sector_summary(navs, bench)
    md = sector_section(summ, ["x warning"], "SYNTHETIC")
    assert "Sector dry-period analysis" in md and "x warning" in md and "SYNTHETIC" in md
    fnavs, fb, _ = dl.sample_universe(end="2025-12-31")
    names = list(fnavs)[:3]
    tab = sc.build_table({n: fnavs[n] for n in names}, dl.sample_factsheet(names), fb)
    assert "within-peer" in scorecard_section(sc.score_funds(tab), sc.flags(tab), "SYNTHETIC")


def test_bundle_accepts_extra_files():
    import io, zipfile
    from smart_investor.export import build_bundle
    from smart_investor.allocation import allocation_for
    from smart_investor.risk_engine import assess
    from smart_investor.samples import PERSONAS_FULL
    from smart_investor.questionnaire import InvestorInputs
    risk = assess(InvestorInputs(next(iter(PERSONAS_FULL.values()))))
    alloc = allocation_for(risk.profile, risk.liquidity_horizon)
    z = zipfile.ZipFile(io.BytesIO(build_bundle(risk, alloc, [], None, None, None, 3, "n", extra_files={"x.csv": pd.DataFrame({"a": [1]})})))
    assert "x.csv" in z.namelist()
