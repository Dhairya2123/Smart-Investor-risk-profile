"""Persona and sensitivity tests: do outputs match common-sense expectations?"""
import pytest

from smart_investor import risk_engine as re_
from smart_investor.questionnaire import InvestorInputs
from smart_investor.risk_engine import assess
from smart_investor.samples import PERSONAS_FULL

EXPECTED = {
    "Young salaried, long horizon, calm in a crash": {"Moderately Aggressive", "Aggressive"},
    "Near-retirement, needs money soon": {"Conservative", "Moderately Conservative"},
    "Brave but financially fragile": {"Conservative", "Moderately Conservative"},
    "Mid-career family, balanced": {"Moderate", "Moderately Conservative", "Moderately Aggressive"},
}


@pytest.mark.parametrize("name", PERSONAS_FULL)
def test_persona_profile_is_sensible(name):
    assert assess(InvestorInputs(PERSONAS_FULL[name])).profile in EXPECTED[name]


def test_fragile_persona_is_flagged_on_every_requested_warning():
    r = assess(InvestorInputs(PERSONAS_FULL["Brave but financially fragile"]))
    assert r.tolerance > 80 and r.capacity < 20 and r.profile == "Conservative"
    for c in ("LOW_EMERGENCY_RESERVE", "HIGH_DEBT", "NEAR_TERM_LIQUIDITY", "TOLERANCE_ABOVE_CAPACITY"):
        assert c in r.codes


def test_retiree_is_flagged_for_liquidity_and_goal_gap():
    r = assess(InvestorInputs(PERSONAS_FULL["Near-retirement, needs money soon"]))
    assert "NEAR_TERM_LIQUIDITY" in r.codes and r.mismatch


def test_sensitivity_horizon_weight_changes_few_personas(monkeypatch):
    """Shifting the horizon weight in capacity by +/-20% should not flip a persona by more than one profile level."""
    base = {n: assess(InvestorInputs(a)).profile_index for n, a in PERSONAS_FULL.items()}
    for w in (re_.HORIZON_SCORE_WEIGHT * 0.8, re_.HORIZON_SCORE_WEIGHT * 1.2):
        monkeypatch.setattr(re_, "HORIZON_SCORE_WEIGHT", w)
        for n, a in PERSONAS_FULL.items():
            assert abs(assess(InvestorInputs(a)).profile_index - base[n]) <= 1, (n, w)


def test_sensitivity_profile_thresholds(monkeypatch):
    """Moving every cut-off by 3 points should change very few personas."""
    base = {n: assess(InvestorInputs(a)).profile_index for n, a in PERSONAS_FULL.items()}
    for d in (-3, 3):
        monkeypatch.setattr(re_, "PROFILE_THRESHOLDS", [t + d for t in (20, 40, 60, 80)])
        changed = sum(assess(InvestorInputs(a)).profile_index != base[n] for n, a in PERSONAS_FULL.items())
        assert changed <= 1
