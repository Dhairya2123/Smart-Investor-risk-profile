import pytest

from smart_investor import risk_engine as re_
from smart_investor.questionnaire import ALL_QUESTIONS, GoalInputs, InvestorInputs
from smart_investor.risk_engine import (assess, breadth_score, classify, future_value, horizon_score, level, pressure_score,
                                        required_return, required_score)
from smart_investor.samples import uniform_answers, with_overrides


def run(mode="mid", **ov):
    return assess(InvestorInputs(with_overrides(uniform_answers(mode), **ov)))


def test_future_value_zero_return():
    assert future_value(1000, 100, 0.0, 1) == pytest.approx(2200)


def test_future_value_lump_sum_only():
    assert future_value(1000, 0, 0.10, 2) == pytest.approx(1210, rel=1e-6)


def test_required_return_roundtrip():
    g = GoalInputs(1_000_000, 100_000, 5_000, 10)
    r = required_return(g)
    assert future_value(100_000, 5_000, r, 10) == pytest.approx(1_000_000, rel=1e-4)


def test_required_return_uses_inflation_adjusted_target():
    flat = required_return(GoalInputs(2_000_000, 200_000, 10_000, 10))
    infl = required_return(GoalInputs(2_000_000, 200_000, 10_000, 10, inflation_linked=True, inflation_rate=0.06))
    assert infl > flat


def test_required_return_goal_met_and_unreachable():
    assert required_return(GoalInputs(100_000, 200_000, 0, 5)) == 0.0
    assert required_return(GoalInputs(100_000_000, 1000, 100, 2)) is None


def test_required_score_bounds():
    assert required_score(0.0) == 0 and required_score(0.30) == 100 and required_score(None) == 100
    assert required_score(0.10) == pytest.approx(50)


@pytest.mark.parametrize("score,expected", [(0, "Conservative"), (19.9, "Conservative"), (20, "Moderately Conservative"),
                                             (45, "Moderate"), (65, "Moderately Aggressive"), (80, "Aggressive"), (100, "Aggressive")])
def test_classify_boundaries(score, expected):
    assert classify(score)[0] == expected


def test_levels():
    assert (level(10), level(35), level(64.9), level(65)) == ("Low", "Moderate", "Moderate", "High")


def test_helper_scores_monotonic():
    assert horizon_score(0.5) < horizon_score(2) < horizon_score(4) < horizon_score(8) < horizon_score(12)
    assert pressure_score(0) > pressure_score(1) > pressure_score(2) > pressure_score(3)
    assert breadth_score(0) < breadth_score(2) < breadth_score(6)


def test_most_cautious_is_conservative_and_strongest_is_aggressive():
    assert run("min").profile == "Conservative"
    assert run("max", goal_horizon="More than 10 years").profile == "Aggressive"


# ------------------------------------------------------------------ conflict rule from the questionnaire
def test_overall_is_the_lower_of_capacity_and_tolerance_not_an_average():
    for mode in ("min", "mid", "max"):
        r = run(mode)
        assert r.overall == pytest.approx(min(r.capacity, r.tolerance))
        assert r.profile == min(r.capacity_profile, r.tolerance_profile, key=re_.PROFILES.index)


def test_high_tolerance_cannot_override_low_capacity():
    r = run("mid", reaction_10pct="Consider investing more", reaction_5_to_4_lakh="Invest additional money",
            tolerable_decline="More than 25%", preferred_mix="Predominantly equity and other high-volatility assets",
            uncertainty="I actively seek higher-risk opportunities", underperformance="Consider investing more after reviewing the facts",
            philosophy="I accept substantial risk for higher potential returns", crash_20pct="Increase investments after reviewing my finances",
            emergency_fund="No emergency savings", loss_impact="Severely affected", debt_burden="More than 35%")
    assert r.tolerance > 80 and r.capacity <= 30
    assert r.profile in ("Conservative", "Moderately Conservative")
    assert "TOLERANCE_ABOVE_CAPACITY" in r.codes and r.mismatch


def test_high_capacity_low_tolerance_follows_tolerance():
    base = uniform_answers("max")
    ans = with_overrides(base, reaction_10pct="Sell all investments immediately", reaction_5_to_4_lakh="Withdraw the remaining amount",
                         tolerable_decline="0–5%", preferred_mix="Mostly deposits / high-quality short-term debt",
                         uncertainty="I strongly dislike uncertainty", underperformance="Exit immediately",
                         philosophy="Protecting capital is my top priority", crash_20pct="Exit the market", check_frequency="Several times a day")
    r = assess(InvestorInputs(ans))
    assert r.capacity > 70 and r.tolerance < 20 and r.profile == "Conservative"
    assert "CAPACITY_ABOVE_TOLERANCE" in r.codes


def test_required_risk_never_raises_profile_but_flags_mismatch():
    easy = run("min", goal_amount=400_000.0, invested=300_000.0, monthly_contribution=5_000.0)
    hard = run("min", goal_amount=20_000_000.0, invested=300_000.0, monthly_contribution=5_000.0)
    assert hard.profile == easy.profile and hard.overall == easy.overall
    assert hard.required > easy.required
    assert hard.mismatch and "GOAL_UNREALISTIC" in hard.codes
    assert not any(c in easy.codes for c in ("GOAL_RISK_GAP", "GOAL_UNREALISTIC"))


def test_non_negotiable_goal_adds_emphasis():
    r = run("min", goal_amount=3_500_000.0, goal_flexibility="Non-negotiable; cannot be delayed or reduced", goal_inflation="Fixed amount")
    assert "GOAL_RISK_GAP" in r.codes and any("non-negotiable" in w for w in r.warnings)


# ------------------------------------------------------------------ capacity caps and warnings
@pytest.mark.parametrize("key,ans,cap", [("emergency_fund", "No emergency savings", 35), ("emergency_fund", "Less than 3 months", 50),
                                          ("debt_burden", "More than 35%", 40), ("loss_impact", "Severely affected", 30),
                                          ("unexpected_withdrawal", "Likely", 40)])
def test_capacity_caps(key, ans, cap):
    r = run("max", goal_horizon="More than 10 years", **{key: ans})
    assert r.capacity <= cap + 1e-9
    assert r.caps_applied


def test_short_horizon_caps_capacity():
    r = run("max", withdrawal_horizon="1–3 years")
    assert r.capacity <= 35 and "NEAR_TERM_LIQUIDITY" in r.codes
    assert r.liquidity_horizon == 2.0


def test_effective_horizon_is_the_shorter_of_withdrawal_and_goal():
    assert run("max", withdrawal_horizon="More than 10 years", goal_horizon="1–3 years").liquidity_horizon == 2.0
    assert run("max", withdrawal_horizon="3–5 years", goal_horizon="More than 10 years").liquidity_horizon == 4.0


def test_required_warnings_present():
    r = run("mid", emergency_fund="Less than 3 months", debt_burden="20–35%", insurance="No meaningful cover", essential_expenses=40_000.0)
    for c in ("LOW_EMERGENCY_RESERVE", "HIGH_DEBT", "INSURANCE_GAP"):
        assert c in r.codes
    assert any("240,000" in w for w in r.warnings)   # 6 x essential spend is quoted


def test_clean_profile_has_no_warnings():
    r = run("max", goal_horizon="More than 10 years", goal_amount=1_500_000.0, goal_inflation="Fixed amount")
    assert r.warnings == [] and not r.mismatch and not r.provisional


def test_reliability_flags():
    assert run("mid", accepts_risk_return="No, I need an explanation").provisional
    assert "ANSWERS_NOT_CONFIRMED" in run("mid", confirmed="No — I would like to review my answers").codes
    assert "MULTIPLE_GOALS" in run("mid", other_goals="Child's education, ₹30 lakh, 2040").codes


def test_inconsistent_cashflow_flag():
    r = run("mid", income_band="Below ₹25,000", essential_expenses=20_000.0, discretionary_expenses=8_000.0, monthly_contribution=10_000.0)
    assert "INCONSISTENT_CASHFLOW" in r.codes


def test_prefer_not_to_say_savings_is_neutral():
    a = run("mid", total_savings="Prefer not to say")
    assert "total_savings" not in a.breakdown


# ------------------------------------------------------------------ monotonic behaviour and explanations
def _extreme_labels(q):
    scored = {k: v for k, v in q.options.items() if v is not None}
    return min(scored, key=scored.get), max(scored, key=scored.get)


def test_more_cautious_answer_never_raises_scores():
    base = uniform_answers("mid")
    r0 = assess(InvestorInputs(base))
    for q in ALL_QUESTIONS:
        if q.kind != "single" or not q.scored:
            continue
        worst, _ = _extreme_labels(q)
        r = assess(InvestorInputs(dict(base, **{q.key: worst})))
        assert r.overall <= r0.overall + 1e-9, q.key
        if q.dimension == "capacity":
            assert r.capacity <= r0.capacity + 1e-9, q.key
        else:
            assert r.tolerance <= r0.tolerance + 1e-9, q.key


def test_context_answers_do_not_change_scores():
    r0 = run("mid")
    for key, alt in (("age", "Above 55"), ("employment", "Freelancer / gig worker"), ("lifestyle_priority", "I prioritize experiences and lifestyle spending"),
                     ("housing", "Own home with a home loan"), ("past_loss", "Yes, more than 20%")):
        r = run("mid", **{key: alt})
        assert (r.capacity, r.tolerance) == (r0.capacity, r0.tolerance), key


def test_explanations_present_for_every_dimension_and_rule():
    r = run("mid")
    assert set(r.explanations) == {"tolerance", "capacity", "required", "overall"}
    assert "LOWER" in r.rule and "not averaged" in r.rule


def test_scores_in_range():
    for mode in ("min", "mid", "max"):
        r = run(mode)
        for s in (r.capacity, r.tolerance, r.required, r.overall):
            assert 0 <= s <= 100
