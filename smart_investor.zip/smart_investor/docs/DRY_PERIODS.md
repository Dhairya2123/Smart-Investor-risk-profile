# Dry-period, sector and scorecard analysis

Educational research aids. Not advice. History does not forecast the future.

## What is a "dry period"?
A stretch where an investment made no progress. Four lenses are used on the same price/NAV series:

| Lens | Definition | Reads as |
|---|---|---|
| Underwater episode | Peak → trough → date a previous high was regained | "How long did investors wait to get back to even?" |
| Dry spell | Trailing N-year annualised return below 0% (loss) or below inflation | "How often/long was the return below zero or inflation?" |
| Relative dry spell | Trailing return minus benchmark return below 0 | "How long did it lag the broad market?" |
| Calendar-year return | Year-end to year-end change | "Which individual years were bad, and how bad?" |

Episodes shown are falls of 10% or more. `% time >10% below peak` is the share of days the series sat more than 10% under its running high.

## Dry-period risk label (sector table)
* **High**: longest wait for a new high > 5 years, or > 50% of days more than 10% below a prior peak.
* **Moderate**: > 3 years, or > 30% of days.
* **Low**: otherwise. Thresholds are judgement calls, not standards.

## Compared with the investor
The Sectors tab uses the questionnaire's investment horizon and the Q21 tolerable decline. A note appears when a sector's longest past wait exceeds the horizon, its worst past fall exceeds the tolerable decline, or it is currently 10%+ below a high. These notes never change the risk profile.

## Rotation and diversification
Calendar-year ranks show leadership moving between sectors. The correlation matrix (daily returns, overlapping dates) shows whether sectors tend to be dry together. Sectors are measured through proxies (index funds, ETFs); tracking error, fees and short histories limit conclusions.

## Technical indicators (context only)
50/200-day moving averages, Wilder RSI(14), 3/6/12-month and 12-1 momentum, distance from 52-week high. They describe the current trend; they are **not** part of the risk profile or any score and do not predict returns. NAVs have no volume, so volume indicators are unavailable.

## Fund scorecard
* Compare funds of the **same category and plan type** only.
* Each metric becomes a percentile rank among the funds compared (100 best, 0 worst; direction set per metric).
* Four themes: Return consistency 30%, Risk & dry periods 30%, Cost & structure 20%, Portfolio quality 20% (editable).
* Theme = mean of available metrics; overall = weighted mean of themes with data, weights rescaled; `Data coverage` shows how much was available.
* Market metrics come from NAVs. Fundamentals (expense ratio, AUM, manager tenure, top-10 concentration, P/E, P/B, ROE, turnover, YTM, duration, AAA share) are **entered by the user from factsheets**; the app does not fetch them.
* Caveats flagged separately: under 3/5 years of history, currently 10%+ below peak, expense ratio missing, AUM under ₹500 crore.
* With two or three funds, ranks swing widely. A high score means "ranked well on these metrics versus these peers", nothing more.

## Data and validation
Sample sectors and the sample factsheet are **synthetic** (built-in regimes, made-up values). Live data via mfapi.in could not be tested in the build environment, so real-sector behaviour is unvalidated.
