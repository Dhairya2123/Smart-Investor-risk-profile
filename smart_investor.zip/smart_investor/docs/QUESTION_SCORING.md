# Question scoring reference

_Generated from the code by `scripts/generate_docs.py`. Scores are 0-100; higher = more tolerance / capacity for risk. 'Context' questions are never scored (age, occupation and spending style are not used to infer risk preference). Weights are relative within the dimension._

## Section 1 - Personal & financial background

**Q1. Age** - Context only
- Below 25; 25–35; 36–45; 46–55; Above 55

**Q2. Employment** - Context only
- Salaried employee; Self-employed; Business owner; Freelancer / gig worker; Retired; Student; Other

**Q3. Monthly income** - Context only
- Below ₹25,000; ₹25,000–₹50,000; ₹50,000–₹1 lakh; ₹1–2 lakh; Above ₹2 lakh

**Q4. Income stability** - Capacity, weight 0.6
- Very stable = 95; Mostly stable = 70; Somewhat variable = 40; Highly unpredictable = 10

**Q5. Dependants** - Capacity, weight 1
- None = 95; 1–2 = 60; 3–4 = 35; More than 4 = 15

**Q6. Savings rate** - Capacity, weight 0.8
- Below 5% = 10; 5–10% = 35; 10–20% = 60; 20–30% = 80; Above 30% = 95

**Q7. Total savings** - Capacity, weight 0.8
- Below ₹1 lakh = 10; ₹1–5 lakh = 30; ₹5–15 lakh = 55; ₹15–50 lakh = 80; Above ₹50 lakh = 95; Prefer not to say

## Section 2 - Lifestyle & financial commitments

**Q8. Spending pattern** - Capacity, weight 0.6
- I spend almost all my income = 10; I usually have a small surplus = 40; I regularly save a meaningful amount = 75; I have a large and consistent surplus = 95

**Q9. Essential expenses** - Context only
- Amount in rupees

**Q10. Discretionary expenses** - Context only
- Amount in rupees

**Q11. Lifestyle priority** - Context only
- I prioritize security and predictable expenses; I balance saving with enjoying the present; I prioritize experiences and lifestyle spending; I am willing to reduce spending to meet long-term goals

**Q12. Spending flexibility** - Capacity, weight 0.8
- Not flexible; most expenses are essential = 10; Slightly flexible = 35; Moderately flexible = 65; Very flexible; I can reduce discretionary spending substantially = 90

**Q13. Life events (5 yrs)** - Capacity, weight 0.8 (scorer: pressure)
- Buying a home = 1 pts; Marriage or starting a family = 1 pts; Having or supporting children = 1 pts; Higher education = 1 pts; Career change / relocation = 0.5 pts; Starting or expanding a business = 1 pts; Retirement = 1 pts; No major change expected = 0 pts; Other = 0.5 pts

**Q14. Expense predictability** - Capacity, weight 0.8
- Very predictable = 90; Mostly predictable = 65; Somewhat uncertain = 35; Highly uncertain = 10

**Q15. Family support** - Capacity, weight 0.6
- No = 90; Yes, a small amount = 65; Yes, a significant amount = 30; The amount varies = 40

**Q16. Housing** - Context only
- Own home with no home loan; Own home with a home loan; Renting; Living with family; Other

**Q17. Insurance cover** - Capacity, weight 1
- Adequate health / life / other cover as relevant = 95; Some cover, but may be insufficient = 50; No meaningful cover = 10; Not sure = 25

**Q18. Chance of forced withdrawal** - Capacity, weight 1.2
- Very unlikely = 95; Unlikely = 70; Possible = 35; Likely = 5

## Section 3 - Risk tolerance

**Q19. Reaction to a 10% fall** - Tolerance, weight 1.5
- Sell all investments immediately = 0; Sell some investments = 25; Feel uncomfortable but hold = 55; Stay invested without major concern = 80; Consider investing more = 100

**Q20. Reaction to ₹5L→₹4L** - Tolerance, weight 1.5
- Withdraw the remaining amount = 0; Sell a major portion = 20; Wait for recovery = 55; Continue investing as planned = 80; Invest additional money = 100

**Q21. Tolerable temporary decline** - Tolerance, weight 1.6
- 0–5% = 5; 5–10% = 30; 10–15% = 50; 15–25% = 75; More than 25% = 100

**Q22. Comfortable investment mix** - Tolerance, weight 1.3
- Mostly deposits / high-quality short-term debt = 5; Mostly debt with a small equity allocation = 30; A balanced mix of debt and equity = 55; Mostly equity mutual funds / index funds = 80; Predominantly equity and other high-volatility assets = 100

**Q23. Attitude to uncertainty** - Tolerance, weight 1
- I strongly dislike uncertainty = 5; I prefer predictable returns = 30; I can accept some uncertainty = 55; I am comfortable with market fluctuations = 80; I actively seek higher-risk opportunities = 100

**Q24. Reaction to 2 years of underperformance** - Tolerance, weight 1
- Exit immediately = 5; Shift to safer investments = 30; Review the investment and wait = 55; Stay invested if the reasons for investing remain valid = 80; Consider investing more after reviewing the facts = 95

**Q25. Investment philosophy** - Tolerance, weight 1.2
- Protecting capital is my top priority = 5; I prefer stable returns with limited fluctuations = 30; I balance growth and stability = 55; I prioritize long-term wealth creation = 80; I accept substantial risk for higher potential returns = 100

**Q26. Reaction to a 20% crash** - Tolerance, weight 1.6
- Exit the market = 0; Reduce equity exposure = 25; Hold investments = 55; Continue planned contributions / SIPs = 80; Increase investments after reviewing my finances = 100

**Q27. Portfolio-checking habit** - Tolerance, weight 0.6
- Several times a day = 10; Daily = 30; Weekly = 55; Monthly = 80; Only during scheduled reviews = 95

## Section 4 - Risk capacity

**Q28. Emergency fund** - Capacity, weight 1.5
- No emergency savings = 0; Less than 3 months = 20; 3–6 months = 55; 6–12 months = 85; More than 12 months = 100

**Q29. Debt burden** - Capacity, weight 1.3
- No debt repayments = 100; Less than 10% = 85; 10–20% = 60; 20–35% = 30; More than 35% = 5

**Q30. Financial position** - Capacity, weight 0.8
- Expenses exceed income = 0; Income and expenses are almost equal = 20; I save a small amount = 50; I save a significant amount = 80; I have substantial savings and investments = 100

**Q31. Share of total assets at risk** - Capacity, weight 1
- More than 75% = 5; 50–75% = 25; 25–50% = 55; 10–25% = 80; Less than 10% = 100

**Q32. Employment stability** - Capacity, weight 0.8
- Very uncertain = 5; Somewhat uncertain = 30; Moderately stable = 55; Stable = 80; Highly stable = 100

**Q33. Time until withdrawal** - Capacity, weight 1.3
- Within 1 year = 0; 1–3 years = 20; 3–5 years = 45; 5–10 years = 80; More than 10 years = 100

**Q34. Major obligations (5 yrs)** - Capacity, weight 1
- Yes, within 1 year = 5; Yes, within 1–3 years = 25; Yes, within 3–5 years = 55; No major obligations = 95; Not sure = 40

**Q35. Impact of a 25% fall** - Capacity, weight 1.5
- Severely affected = 0; Significantly affected = 20; Somewhat affected = 50; Minimally affected = 80; Not affected = 100

**Q36. Portfolio liquidity** - Capacity, weight 1
- Almost none = 5; Less than 25% = 25; 25–50% = 50; 50–75% = 75; More than 75% = 95

## Section 5 - Risk required & financial goals

**Q37. Objectives** - Context only
- Capital preservation; Regular income generation; Wealth creation; Retirement planning; Children's education; House / property purchase; Financial independence; Other

**Q38. Goal amount** - Goal model
- Amount in rupees

**Q39. Already invested for goal** - Goal model
- Amount in rupees

**Q40. Monthly contribution** - Goal model
- Amount in rupees

**Q41. Goal horizon** - Goal model
- Within 1 year; 1–3 years; 3–5 years; 5–10 years; More than 10 years

**Q42. Goal vs inflation** - Goal model
- Fixed amount; Expected to rise with inflation; Not sure

**Q43. Goal flexibility** - Goal model
- Non-negotiable; cannot be delayed or reduced; Slightly flexible; Moderately flexible; I can postpone the goal; I can significantly revise the target

**Q44. Preferred fix if plan falls short** - Goal model
- Increase monthly contributions; Extend the investment period; Reduce or revise the target amount; Review whether a different risk level is appropriate; Reconsider the goal

**Q45. Other goals** - Context only
- Free text

## Section 6 - Investment experience & knowledge

**Q46. Investing experience** - Tolerance, weight 0.5
- I have never invested = 10; Less than 1 year = 25; 1–3 years = 50; 3–5 years = 70; More than 5 years = 90

**Q47. Products used** - Tolerance, weight 0.4 (scorer: breadth)
- Fixed deposits / recurring deposits; Debt mutual funds; Equity mutual funds; Index funds / ETFs; Direct stocks; Bonds; Gold; Derivatives; Other

**Q48. Understanding of risk** - Tolerance, weight 0.5
- Beginner = 10; Basic = 30; Intermediate = 55; Advanced = 80; Expert = 95

**Q49. Past loss** - Context only
- No; Yes, less than 5%; Yes, 5–10%; Yes, 10–20%; Yes, more than 20%

**Q50. Understands risk-return** - Context only
- Yes, clearly; I understand partly; No, I need an explanation

## Section 7 - Review & confirmation

**Q51. Other circumstances** - Review
- Free text

**Q52. Answers confirmed** - Review
- Yes; No — I would like to review my answers

**Q53. Additional information** - Review
- Free text

## Caps and thresholds

| Rule | Value |
|---|---|
| Capacity cap: emergency_fund = 'No emergency savings' | 35 |
| Capacity cap: emergency_fund = 'Less than 3 months' | 50 |
| Capacity cap: debt_burden = 'More than 35%' | 40 |
| Capacity cap: debt_burden = '20–35%' | 60 |
| Capacity cap: loss_impact = 'Severely affected' | 30 |
| Capacity cap: loss_impact = 'Significantly affected' | 45 |
| Capacity cap: unexpected_withdrawal = 'Likely' | 40 |
| Capacity cap: effective horizon < 1 years | 25 |
| Capacity cap: effective horizon < 3 years | 35 |
| Capacity cap: effective horizon < 5 years | 55 |
| Profile cut-offs on overall score | [20, 40, 60, 80] |
| Low / Moderate / High cut-offs | (35, 65) |
| Capacity vs tolerance gap warning | 25 points |
| Required vs overall gap warning | 15 points |
| Required return mapped to 0 / 100 | 5% / 15% |
| Unrealistic required return | above 20% a year |
