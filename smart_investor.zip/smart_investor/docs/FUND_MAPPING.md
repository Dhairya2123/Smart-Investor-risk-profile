# Which fund categories fit which risk profile

> Educational categories and example schemes to RESEARCH, not recommendations to buy. Example names are from general knowledge and may be outdated: verify the current scheme name, category, Direct/Regular plan, expense ratio, AUM, track record and risk label with the AMC factsheet or AMFI. Past performance does not guarantee future results.

The app first sets an illustrative equity / debt / cash split from the profile (and caps equity for short horizons), then spreads each sleeve across the categories below. 'Share' is the share within the sleeve.

## Conservative

Equity 10%-25%; minimum cash 10%; the rest in debt.

| Sleeve | Category | Share in sleeve | Typical risk (indicative) | Example schemes to research |
|---|---|---|---|---|
| Equity | Large-cap / Nifty 50 index fund | 100% | Very high | UTI Nifty 50 Index Fund; HDFC Index Fund Nifty 50 Plan |
| Debt | Short Duration / Low Duration debt fund | 40% | Low to moderate | HDFC Short Term Debt Fund; ICICI Prudential Short Term Fund |
| Debt | Banking & PSU debt fund | 30% | Low to moderate | HDFC Banking and PSU Debt Fund; Kotak Banking and PSU Debt Fund |
| Debt | Corporate Bond fund | 30% | Moderate | ICICI Prudential Corporate Bond Fund; HDFC Corporate Bond Fund |
| Cash | Liquid / Overnight fund | 100% | Low | HDFC Liquid Fund; ICICI Prudential Liquid Fund |

One-fund alternatives: Conservative Hybrid fund (e.g. SBI Conservative Hybrid Fund); Equity Savings fund (e.g. HDFC Equity Savings Fund)

## Moderately Conservative

Equity 25%-45%; minimum cash 7%; the rest in debt.

| Sleeve | Category | Share in sleeve | Typical risk (indicative) | Example schemes to research |
|---|---|---|---|---|
| Equity | Large-cap / Nifty 50 index fund | 70% | Very high | UTI Nifty 50 Index Fund; HDFC Index Fund Nifty 50 Plan |
| Equity | Flexi Cap fund | 30% | Very high | Parag Parikh Flexi Cap Fund; HDFC Flexi Cap Fund |
| Debt | Short Duration / Low Duration debt fund | 35% | Low to moderate | HDFC Short Term Debt Fund; ICICI Prudential Short Term Fund |
| Debt | Corporate Bond fund | 35% | Moderate | ICICI Prudential Corporate Bond Fund; HDFC Corporate Bond Fund |
| Debt | Gilt fund | 30% | Moderate to high (rate risk) | SBI Magnum Gilt Fund |
| Cash | Liquid / Overnight fund | 100% | Low | HDFC Liquid Fund; ICICI Prudential Liquid Fund |

One-fund alternatives: Conservative Hybrid fund (e.g. SBI Conservative Hybrid Fund); Balanced Advantage / Dynamic Asset Allocation fund (e.g. ICICI Prudential Balanced Advantage Fund)

## Moderate

Equity 45%-60%; minimum cash 5%; the rest in debt.

| Sleeve | Category | Share in sleeve | Typical risk (indicative) | Example schemes to research |
|---|---|---|---|---|
| Equity | Large-cap / Nifty 50 index fund | 40% | Very high | UTI Nifty 50 Index Fund; HDFC Index Fund Nifty 50 Plan |
| Equity | Flexi Cap fund | 30% | Very high | Parag Parikh Flexi Cap Fund; HDFC Flexi Cap Fund |
| Equity | Large & Mid Cap fund | 20% | Very high | Mirae Asset Large & Midcap Fund |
| Equity | Mid Cap fund / Nifty Midcap 150 index fund | 10% | Very high | Motilal Oswal Midcap Fund; Nifty Midcap 150 index funds |
| Debt | Short Duration / Low Duration debt fund | 40% | Low to moderate | HDFC Short Term Debt Fund; ICICI Prudential Short Term Fund |
| Debt | Corporate Bond fund | 40% | Moderate | ICICI Prudential Corporate Bond Fund; HDFC Corporate Bond Fund |
| Debt | Gilt fund | 20% | Moderate to high (rate risk) | SBI Magnum Gilt Fund |
| Cash | Liquid / Overnight fund | 100% | Low | HDFC Liquid Fund; ICICI Prudential Liquid Fund |

One-fund alternatives: Balanced Advantage / Dynamic Asset Allocation fund (e.g. ICICI Prudential Balanced Advantage Fund); Aggressive Hybrid fund (e.g. ICICI Prudential Equity & Debt Fund)

## Moderately Aggressive

Equity 60%-80%; minimum cash 3%; the rest in debt.

| Sleeve | Category | Share in sleeve | Typical risk (indicative) | Example schemes to research |
|---|---|---|---|---|
| Equity | Large-cap / Nifty 50 index fund | 30% | Very high | UTI Nifty 50 Index Fund; HDFC Index Fund Nifty 50 Plan |
| Equity | Flexi Cap fund | 30% | Very high | Parag Parikh Flexi Cap Fund; HDFC Flexi Cap Fund |
| Equity | Large & Mid Cap fund | 15% | Very high | Mirae Asset Large & Midcap Fund |
| Equity | Mid Cap fund / Nifty Midcap 150 index fund | 25% | Very high | Motilal Oswal Midcap Fund; Nifty Midcap 150 index funds |
| Debt | Short Duration / Low Duration debt fund | 50% | Low to moderate | HDFC Short Term Debt Fund; ICICI Prudential Short Term Fund |
| Debt | Corporate Bond fund | 50% | Moderate | ICICI Prudential Corporate Bond Fund; HDFC Corporate Bond Fund |
| Cash | Liquid / Overnight fund | 100% | Low | HDFC Liquid Fund; ICICI Prudential Liquid Fund |

One-fund alternatives: Aggressive Hybrid fund (e.g. ICICI Prudential Equity & Debt Fund); Balanced Advantage / Dynamic Asset Allocation fund (e.g. ICICI Prudential Balanced Advantage Fund)

## Aggressive

Equity 80%-95%; minimum cash 2%; the rest in debt.

| Sleeve | Category | Share in sleeve | Typical risk (indicative) | Example schemes to research |
|---|---|---|---|---|
| Equity | Large-cap / Nifty 50 index fund | 25% | Very high | UTI Nifty 50 Index Fund; HDFC Index Fund Nifty 50 Plan |
| Equity | Flexi Cap fund | 25% | Very high | Parag Parikh Flexi Cap Fund; HDFC Flexi Cap Fund |
| Equity | Mid Cap fund / Nifty Midcap 150 index fund | 30% | Very high | Motilal Oswal Midcap Fund; Nifty Midcap 150 index funds |
| Equity | Small Cap fund | 20% | Very high | Nippon India Small Cap Fund; SBI Small Cap Fund |
| Debt | Short Duration / Low Duration debt fund | 50% | Low to moderate | HDFC Short Term Debt Fund; ICICI Prudential Short Term Fund |
| Debt | Corporate Bond fund | 50% | Moderate | ICICI Prudential Corporate Bond Fund; HDFC Corporate Bond Fund |
| Cash | Liquid / Overnight fund | 100% | Low | HDFC Liquid Fund; ICICI Prudential Liquid Fund |

One-fund alternatives: Aggressive Hybrid fund (e.g. ICICI Prudential Equity & Debt Fund)

## How to shortlist within a category

1. Compare only funds of the same SEBI category and the same plan type (Direct-Growth with Direct-Growth).
2. Look at 3- and 5-year rolling returns, maximum drawdown and volatility, not just the latest return.
3. Check expense ratio, AUM, fund-manager tenure and portfolio concentration on the AMC factsheet.
4. Use the app's Fund comparison tab (live mfapi.in NAVs) with the 'Live search term' for each category.
5. Fix the emergency fund, high-cost debt and near-term obligations before adding equity funds.
