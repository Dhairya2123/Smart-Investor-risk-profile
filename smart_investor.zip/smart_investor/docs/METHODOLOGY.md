# Methodology Note - Smart Investor Risk Profile

**Purpose:** explain *why* each rule, weight and threshold exists, what it assumes, and where it is weak.
This is an educational tool built from the 53-question "Complete Investor Questionnaire". Nothing here is a regulatory
standard or investment advice; every number is a design choice that should be reviewed by a qualified professional,
tested with users, and checked for regulatory and data-protection compliance before any live use.

Question-by-question scores and weights are in `QUESTION_SCORING.md` (generated from the code). The fund-category mapping is in `FUND_MAPPING.md`.

## 1. Design principles (taken from the questionnaire's safety notes)

1. **Three separate questions.** Risk *tolerance* (can you stomach losses?), *capacity* (can you afford them?) and *required* risk
   (what does your goal demand?) are scored and shown separately, each with an explanation.
2. **Do not average.** The overall profile is the **lower** of the capacity-based and tolerance-based profiles. A high tolerance score can
   never override low financial capacity.
3. **The goal never raises the profile.** Required risk is calculated from the goal data, not guessed, and is used only to flag a gap and
   offer alternatives (more contributions, a longer horizon, a revised goal).
4. **No stereotyping.** Age, occupation, income band, housing and lifestyle style are context only; they are not scored. Lifestyle information
   enters through cash-flow resilience (savings rate, spending flexibility, predictability of expenses, obligations).
5. **Be explicit about uncertainty.** Projections and crash results are scenarios under stated assumptions, not forecasts.

## 2. Structure of the questionnaire and how each part is used

| Section | Questions | Use |
|---|---|---|
| 1 Background | Q1-Q7 | Q4-Q7 feed capacity; Q1-Q3 are context (Q3 is only used to sanity-check stated spending) |
| 2 Lifestyle & commitments | Q8-Q18 | Q8, Q12-Q15, Q17, Q18 feed capacity; Q9-Q10 give essential spending for the emergency-fund warning; Q11, Q16 are context |
| 3 Risk tolerance | Q19-Q27 | All feed tolerance; Q21 also sets the "tolerable decline" used in crash warnings |
| 4 Risk capacity | Q28-Q36 | All feed capacity; some also act as caps (below) |
| 5 Goal | Q37-Q45 | Q38-Q42 define the goal model; Q43 sharpens the mismatch warning; Q44 orders the suggested alternatives; Q37, Q45 are context |
| 6 Experience | Q46-Q50 | Q46-Q48 add a small weight to tolerance; Q49 is context; Q50 is a reliability check |
| 7 Review | Q51-Q53 | Free text; Q52 marks the profile provisional if the investor asks to review answers |

## 3. Scoring

Each answer maps to 0-100. A dimension score is the weighted average of its answered questions ("Prefer not to say" is skipped, not treated as zero).
Weights reflect how directly a question measures the dimension: the largest weights go to behaviour in a loss (Q21, Q26, Q19, Q20), the emergency fund (Q28),
the impact of a 25% fall (Q35), the debt burden (Q29) and the chance of forced withdrawal (Q18). Experience questions carry weight 0.4-0.5 because experience
helps understanding but does not prove tolerance.

**Capacity** = 75% weighted financial answers + 25% horizon score, then hard caps (the tightest applicable cap wins):

| Trigger | Cap |
|---|---|
| No emergency savings / under 3 months | 35 / 50 |
| EMIs above 35% / 20-35% of take-home | 40 / 60 |
| 25% fall would severely / significantly affect lifestyle | 30 / 45 |
| Large unexpected withdrawal "Likely" | 40 |
| Effective horizon under 1 / 3 / 5 years | 25 / 35 / 55 |

*Why caps:* a good average must not hide a single dangerous weakness. The effective horizon is the shorter of Q33 (time to withdrawal) and Q41 (goal date).

**Tolerance** = weighted behavioural answers (Section 3) plus modest experience and understanding weights (Q46-Q48).

**Multi-select scoring.** Q13 (life events): events add pressure points (home, family, children, education, business, retirement = 1 each; career change or other = 0.5);
0 points scores 90, up to 0.5 scores 75, up to 1 scores 65, up to 2 scores 40, more scores 20. Q47 (products used) scores breadth: 0 products 10, 1 scores 30, 2 scores 50, 3-4 scores 70, 5+ scores 90.

## 4. Risk required and goal feasibility

The investor enters the goal, the amount already invested, the monthly contribution and the horizon. The **required return** is solved by bisection (monthly compounding,
end-of-month contributions). If the goal rises with inflation (or the investor is "not sure", treated conservatively as inflation-linked) the target is inflated at the
assumed rate (default 6%, editable). The required return maps linearly to a 0-100 score (5% = 0, 15% = 100). Above 20% a year is treated as unrealistic.

**Goal feasibility** compares the base-case value of the illustrative portfolio with the inflation-adjusted target. "Needs adjustment" triggers a list of alternatives with
numbers (contribution needed, years needed, achievable target in today's money). The investor's preferred fix (Q44) is listed first. The "different risk level" option explicitly says a
higher-risk portfolio is not automatic because the profile is limited by capacity or tolerance.

## 5. Overall profile, levels and mismatch

`overall = min(capacity, tolerance)`; profile cut-offs 20 / 40 / 60 / 80 on the overall score; Low / Moderate / High at 35 / 65 for each dimension (Section 8 labels).

**Risk mismatch = "Potential mismatch"** when (a) required minus overall exceeds 15 points (or the goal is unrealistic), or (b) capacity and tolerance differ by more than 25 points.

**Warnings** (each with a code): low emergency reserve (quotes six months of the stated essential spending), high debt commitments, near-term liquidity needs (short effective horizon,
obligations within 3 years, possible forced withdrawal), insurance gap, tolerance above or below capacity, goal-risk gap or unrealistic goal, risk-return not understood (Q50), answers not confirmed (Q52),
other goals not modelled (Q45), and inconsistent cash flow (spending plus contribution above the income band).

## 6. Allocation, crash scenarios and goal impact

Equity ranges: Conservative 10-25%, Moderately Conservative 25-45%, Moderate 45-60%, Moderately Aggressive 60-80%, Aggressive 80-95%; minimum cash 10% falling to 2%.
Horizon caps equity (under 1 year 10%, under 3 years 30%, under 5 years 55%). Assumptions (editable): equity 12% return / 17% volatility, debt 7% / 3%, cash 5.5% / 0.5%.
Pessimistic and optimistic cases shift the return by one portfolio volatility; this ignores sequence risk and fat tails, so the pessimistic case is **not** a worst case.

The crash simulator applies a one-off shock (default equity -20%) and reports the loss, approximate recovery time and a warning if the loss exceeds the temporary decline stated in Q21.
**Goal impact** applies the shock now, half-way, or one year before the goal date, then keeps growing and contributing, and reports the value at the goal date and whether the goal is still met.

## 7. Fund categories

Each profile's equity, debt and cash sleeves are spread over SEBI mutual-fund categories (see `FUND_MAPPING.md`). The app lists category, role, indicative risk and **example schemes to research**,
all flagged as educational and unverified. Selecting actual funds requires current data (the Fund comparison tab loads live NAVs) and professional judgement.

## 8. Fund analytics

CAGR on calendar days; volatility = daily standard deviation x sqrt(252); Sharpe = (CAGR - risk-free) / volatility (risk-free default 6.5%, editable; NaN when volatility is about zero);
max drawdown peak-to-trough; beta vs a chosen benchmark on overlapping dates (NaN under 30 observations); rolling returns with as-of lookbacks. All funds are compared over the same window ending on
the same date; short histories and mixed categories are flagged. Expense ratio and top-10 concentration come from factsheets.

## 9. Data and privacy

NAVs come from mfapi.in (community wrapper around AMFI data, no uptime or accuracy guarantee) or user CSVs; built-in sample funds are synthetic. The app stores nothing unless "Save this run" is pressed, and then only scores,
profile, equity weight and a random session id (no name, contact or ID numbers). The optional investor reference appears on the report only and is not stored.

## 10. Known limitations

1. Weights, caps and thresholds are judgement-based and un-validated; no psychometric testing has been done.
2. Answers are self-reported and can be inconsistent; the validation catches only obvious conflicts.
3. Projections use constant assumptions; real returns vary with regime and sequence.
4. Only the main goal is modelled; tax, portfolio fees and other goals are not.
5. Example fund names are from general knowledge and may be out of date.
6. Not suitable as advice without review by a licensed professional.

## 11. Validation that exists, and what is next

Automated tests cover the 53-question structure, monotonic scoring (a more cautious answer never raises a score), the conflict rule, every cap and warning, goal maths, crash impact, fund mapping, persona expectations and sensitivity
(moving the horizon weight by 20% or cut-offs by 3 points changes few personas). Next: expert review of cut-offs, user testing of question wording, and a data-protection and regulatory review.


## Dry-period, sector and scorecard analysis
See DRY_PERIODS.md. These are research context; they do not change the risk profile (min of capacity and tolerance).
